"""Design 13: photo-guided dimensional interpretation, not manufacturing CAD.
Run: blender -b --threads 4 --python model_design13.py
All design parameters below are millimetres, geometry authored in mm.
"""
import bpy, math, json, os
from mathutils import Vector
from collections import Counter
OUT=os.path.dirname(os.path.abspath(__file__))
SOURCE=os.path.join(OUT,'design13_source_reference.jpg')
P={'assumed_inner_diameter_mm':18.0,'band_radial_thickness_mm':1.8,'band_bottom_width_mm':2.8,'band_shoulder_width_mm':4.6,'flower_nominal_diameter_mm':29.0,'crown_center_z_mm':14.2,'crown_edge_drop_mm':2.6,'outer_petals':20,'middle_petals':12,'inner_petals':6,'bead_diameter_mm':0.29,'rim_wire_diameter_mm':0.40}
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in list(bpy.data.collections):
    if d.name != 'Collection' and d.users==0: bpy.data.collections.remove(d)
scene=bpy.context.scene
scene.unit_settings.system='METRIC'; scene.unit_settings.length_unit='MILLIMETERS';scene.unit_settings.scale_length=.001
# Isolated, named editable construction layers.
COL={}
for name in ['01_Complete_Ring_Shank','02_Raised_Under_Gallery','03_Outer_20_Marquise_Petals','04_Middle_12_Marquise_Petals','05_Inner_6_Petals_and_Rosette','06_Reference_Image','07_Studio']:
    c=bpy.data.collections.new(name);scene.collection.children.link(c);COL[name]=c
GOLD=bpy.data.materials.new('Polished warm yellow gold');GOLD.diffuse_color=(.83,.58,.19,1);GOLD.use_nodes=True
bs=GOLD.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.83,.59,.20,1);bs.inputs['Metallic'].default_value=1;bs.inputs['Roughness'].default_value=.22
GOLD2=bpy.data.materials.new('Softer gold bead rims');GOLD2.diffuse_color=(.72,.49,.13,1);GOLD2.use_nodes=True
bs=GOLD2.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.76,.52,.16,1);bs.inputs['Metallic'].default_value=1;bs.inputs['Roughness'].default_value=.26

def mesh_obj(name,verts,faces,col,mat=GOLD):
    me=bpy.data.meshes.new(name+'_mesh');me.from_pydata(verts,[],faces);me.update();ob=bpy.data.objects.new(name,me);COL[col].objects.link(ob);ob.data.materials.append(mat)
    for p in me.polygons:p.use_smooth=True
    return ob

def tube(name,path,radius,col,cyclic=False,sides=10,mat=GOLD):
    verts=[];faces=[];n=len(path)
    for i,p in enumerate(path):
        p=Vector(p);t=(Vector(path[(i+1)%n])-Vector(path[(i-1)%n])).normalized() if cyclic else (Vector(path[min(i+1,n-1)])-Vector(path[max(0,i-1)])).normalized()
        seed=Vector((0,0,1)) if abs(t.z)<.85 else Vector((0,1,0));a=t.cross(seed).normalized();b=t.cross(a).normalized()
        for j in range(sides):
            q=p+radius*(math.cos(2*math.pi*j/sides)*a+math.sin(2*math.pi*j/sides)*b)
            if '_Raised_Open_Marquise_Rim' in name:
                co=math.cos(2*math.pi*j/sides);si=math.sin(2*math.pi*j/sides)
                q=p+.20*math.copysign(abs(co)**.40,co)*a+.34*math.copysign(abs(si)**.40,si)*b;q.z-=.19
            verts.append(tuple(q))
    for i in range(n if cyclic else n-1):
        k=(i+1)%n
        for j in range(sides): faces.append((i*sides+j,i*sides+(j+1)%sides,k*sides+(j+1)%sides,k*sides+j))
    if not cyclic: faces.extend([tuple(reversed(tuple(range(sides)))),tuple((n-1)*sides+j for j in range(sides))])
    return mesh_obj(name,verts,faces,col,mat)

def bead(name,point,r,col):
    # Reuse a watertight high-quality UV sphere mesh, with independently editable transforms.
    if 'Granule_master_mesh' not in bpy.data.meshes:
        bpy.ops.mesh.primitive_uv_sphere_add(segments=10,ring_count=6,radius=1)
        ob=bpy.context.object;me=ob.data;me.name='Granule_master_mesh'
        for p in me.polygons:p.use_smooth=True
        bpy.data.objects.remove(ob,do_unlink=True);me.materials.append(GOLD2)
    ob=bpy.data.objects.new(name,bpy.data.meshes['Granule_master_mesh']);COL[col].objects.link(ob);ob.location=point;ob.scale=(r,r,r)
    return ob

def z_at(r):return P['crown_center_z_mm']-P['crown_edge_drop_mm']*(r/(P['flower_nominal_diameter_mm']/2))**1.6

def map_local(u,v,angle,rc,zoff=0):
    r=rc+u;x=r*math.cos(angle)-v*math.sin(angle);y=r*math.sin(angle)+v*math.cos(angle)
    return (x,y,z_at(math.hypot(x,y))+zoff)

# Continuous full 360-degree comfort-fit band, rounded rectangular cross-section.
N=256;M=24;verts=[];faces=[]
for i in range(N):
    a=2*math.pi*i/N;upper=max(0,math.cos(a));width=P['band_bottom_width_mm']+(P['band_shoulder_width_mm']-P['band_bottom_width_mm'])*(upper**2)
    for j in range(M):
        b=2*math.pi*j/M;co=math.cos(b);si=math.sin(b)
        radial=(P['band_radial_thickness_mm']/2)*math.copysign(abs(co)**.40,co);axial=width/2*math.copysign(abs(si)**.40,si)
        rr=P['assumed_inner_diameter_mm']/2+P['band_radial_thickness_mm']/2+radial;verts.append((rr*math.sin(a),axial,rr*math.cos(a)))
for i in range(N):
    for j in range(M):faces.append((i*M+j,((i+1)%N)*M+j,((i+1)%N)*M+(j+1)%M,i*M+(j+1)%M))
band=mesh_obj('Closed_18mm_Bore_Comfort_Shank',verts,faces,'01_Complete_Ring_Shank');band['Inner diameter (assumed mm)']=P['assumed_inner_diameter_mm']
# Under-gallery elliptical hoop, real rising support rails and crown rib connections.
col='02_Raised_Under_Gallery'
for rr,dz,w in [(6.25,-1.35,.28),(9.25,-.95,.23)]:
    path=[(rr*math.cos(2*math.pi*j/128),rr*math.sin(2*math.pi*j/128),z_at(rr)+dz) for j in range(128)]
    tube('Open_Circular_Gallery_'+str(rr),path,w,col,True)
for k in range(12):
    a=2*math.pi*k/12
    path=[(r*math.cos(a),r*math.sin(a),z_at(r)-.37-1.0*math.sin(math.pi*(r-3)/(9.6-3))) for r in [3+(9.6-3)*j/32 for j in range(33)]]
    tube('Raised_Gallery_Radial_Rib_%02d'%k,path,.24,col)
# Four curved shoulder struts join the band to the floral under-gallery.
for sign in [-1,1]:
    for side in [-1,1]:
        p0=Vector((sign*7.35,side*1.65,7.10));p1=Vector((sign*8.4,side*2.3,9.5));p2=Vector((sign*7.2,side*3.5,11.7));p3=Vector((sign*6.25,side*3.0,z_at(6.93)-.5))
        path=[tuple((1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3) for t in [j/40 for j in range(41)]]
        tube('Curved_Rising_Shoulder_%d_%d'%(sign,side),path,.60,col)

def lens_outline(L,W,n=64):
    # Pointed marquise, with rounded convex flanks rather than an oval.
    return [(L/2*math.cos(2*math.pi*j/n),W/2*math.sin(2*math.pi*j/n)*abs(math.sin(2*math.pi*j/n))**.30) for j in range(n)]

def domed_medallion(name,angle,rc,L,W,col,zoff=.35):
    n=64;outline=lens_outline(L,W,n);verts=[];faces=[]
    # Volumetric lens plate: rounded top dome, edged sides, convex back; tips do not flatten the surface.
    layers=[(1,0),(1,.16),(.82,.26),(.48,.31)]
    for scale,h in layers:
        for u,v in outline:verts.append(map_local(u*scale,v*scale,angle,rc,zoff+h))
    top=len(verts);verts.append(map_local(0,0,angle,rc,zoff+.33))
    bottom=len(verts);verts.append(map_local(0,0,angle,rc,zoff-.12))
    for k in range(len(layers)-1):
        for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
    for j in range(n):faces.append(((len(layers)-1)*n+j,(len(layers)-1)*n+(j+1)%n,top));faces.append(((j+1)%n,j,bottom))
    return mesh_obj(name,verts,faces,col)

def motif(tier,count,rc,L,W,col,phase=0,plate_scale=.70):
    for k in range(count):
        a=2*math.pi*k/count+phase;nm='%s_Petal_%02d'%(tier,k+1)
        outline=lens_outline(L,W,80);path=[map_local(u,v,a,rc,.10) for u,v in outline]
        rim=tube(nm+'_Raised_Open_Marquise_Rim',path,P['rim_wire_diameter_mm']/2,col,True,sides=16)
        rim['Construction']='Rounded rectangular 0.40 mm wide × 0.68 mm high closed marquise rim wall follows curved crown surface'
        # Arc-length spaced milgrain beads across the whole leaf contour.
        cum=[0]
        for j in range(len(path)):cum.append(cum[-1]+(Vector(path[(j+1)%len(path)])-Vector(path[j])).length)
        total=cum[-1];nb=max(22,round(total/.32))
        for j in range(nb):
            d=total*j/nb;i=next(ii for ii in range(len(path)) if cum[ii+1]>=d);q=Vector(path[i]).lerp(Vector(path[(i+1)%len(path)]),(d-cum[i])/(cum[i+1]-cum[i]));q.z+=.27
            bead(nm+'_Milgrain_%02d'%j,tuple(q),P['bead_diameter_mm']/2,col)
        # Tapered support stem connects smaller raised plate to full openwork outline.
        stem=[map_local(-L/2+L*j/32,0,a,rc,.10) for j in range(33)]
        tube(nm+'_Radial_Spine',stem,.115,col)
        domed_medallion(nm+'_Polished_Convex_Marquise',a,rc+.17,L*plate_scale,W*.62,col,.32)
        # Side links secure plate/rim and add visible architectural depth.
        for side in [-1,1]:
            path=[map_local(.1,side*W/2*j/10,a,rc,.10+.20*(1-j/10)) for j in range(11)]
            tube(nm+'_Plate_Bridge_%d'%side,path,.10,col)
        bead(nm+'_Outer_Tip',map_local(L/2,0,a,rc,.10),.19,col)

motif('Outer',P['outer_petals'],11.72,5.12,3.28,'03_Outer_20_Marquise_Petals',phase=math.pi/20,plate_scale=.72)
motif('Middle',P['middle_petals'],7.58,5.5,3.55,'04_Middle_12_Marquise_Petals',phase=0,plate_scale=.70)
motif('Inner',P['inner_petals'],3.55,3.82,2.65,'05_Inner_6_Petals_and_Rosette',phase=math.pi/6,plate_scale=.68)
# Six rounded gold center buds plus a central boss form the compact central flower.
col='05_Inner_6_Petals_and_Rosette'
for k in range(6):
    a=2*math.pi*k/6;domed_medallion('Rosette_Small_Petal_%d'%k,a,1.35,1.55,1.20,col,.22)
    rr=1.0;bead('Rosette_Granule_%d'%k,(rr*math.cos(a+math.pi/6),rr*math.sin(a+math.pi/6),z_at(rr)+.4),.14,col)
# Center round convex cabochon mesh, with small surrounding bead ring.
bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=20,radius=1,location=(0,0,P['crown_center_z_mm']+.30))
ob=bpy.context.object;ob.name='Central_Round_Gold_Boss';ob.scale=(.76,.76,.37)
for c in list(ob.users_collection):c.objects.unlink(ob)
COL[col].objects.link(ob);ob.data.materials.append(GOLD)
for p in ob.data.polygons:p.use_smooth=True
for k in range(18):
    a=2*math.pi*k/18;bead('Center_Milgrain_%02d'%k,(.88*math.cos(a),.88*math.sin(a),P['crown_center_z_mm']+.28),.115,col)

# Preserve the actual supplied pixels inside the project, hidden in renders.
if os.path.exists(SOURCE):
    im=bpy.data.images.load(SOURCE,check_existing=True);im.pack()
    ob=bpy.data.objects.new('SOURCE_PHOTO_optional_reference',None);ob.empty_display_type='IMAGE';ob.data=im;ob.empty_display_size=30;ob.location=(35,0,0);ob.rotation_euler=(math.pi/2,0,0);ob.hide_render=True;ob.hide_viewport=True;COL['06_Reference_Image'].objects.link(ob)
# Studio arrangement.
col='07_Studio'
floor_mat=bpy.data.materials.new('Warm charcoal studio floor');floor_mat.use_nodes=True
floor_mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.075,.080,.086,1)
floor_mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.42
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-(P['assumed_inner_diameter_mm']/2+P['band_radial_thickness_mm'])-.02));floor=bpy.context.object;floor.name='Studio floor';floor.data.materials.append(floor_mat)
for c in list(floor.users_collection):c.objects.unlink(floor)
COL[col].objects.link(floor)
world=bpy.data.worlds.new('Soft gray photographic world') if not bpy.data.worlds else bpy.data.worlds[0];scene.world=world;world.use_nodes=True;world.node_tree.nodes.get('Background').inputs[0].default_value=(.60,.65,.72,1);world.node_tree.nodes.get('Background').inputs[1].default_value=.32

def aim(ob,target):ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
def light(name,loc,energy,size,color=(1,1,1),shape='DISK',size_y=None):
    d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape=shape;d.size=size;d.color=color
    if size_y:d.size_y=size_y
    o=bpy.data.objects.new(name,d);COL[col].objects.link(o);o.location=loc;aim(o,(0,0,6));return o
light('Large softbox key',(-25,-28,42),25000,30,(1,.88,.70),'DISK')
light('Cool rim',(24,12,28),19000,22,(.77,.86,1),'RECTANGLE',32)
light('Front vertical reflection',(-4,-32,12),11500,10,(1,1,1),'RECTANGLE',24)
light('Top gold kicker',(5,6,48),14000,18,(1,.89,.72),'DISK')
camd=bpy.data.cameras.new('Product camera');cam=bpy.data.objects.new('Product camera',camd);COL[col].objects.link(cam);cam.location=(30,-43,50);aim(cam,(0,0,3));camd.type='ORTHO';camd.ortho_scale=40;camd.lens=55;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.cycles.sample_clamp_indirect=3.0;scene.cycles.blur_glossy=0.5;scene.render.threads_mode='FIXED';scene.render.threads=4
scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
# Make selecting and editing the jewelry easy in the saved scene.
bpy.ops.object.select_all(action='DESELECT');band.select_set(True);bpy.context.view_layer.objects.active=band
scene['Dimensional status']='Millimetre model; 18mm bore is an explicit unverified assumption. Single-image reconstruction, not manufacturing ready.'
scene['Source photo']='IMG-20260928-WA0013.jpg, packed in hidden reference image object'
scene['Structure']='Complete ring shank, four curved shoulders, raised gallery, three tiers of volumetric openwork petals, fine beaded rims'
# Geometry validation: each mesh shell is checked for edge manifoldness, loose geometry, connected components.
bpy.context.view_layer.update()
records=[];global_counts=Counter();all_v=[];jewelry=[];mesh_checks={};volume_issues=[]
for ob in scene.objects:
    if ob.type!='MESH' or any(c.name=='07_Studio' for c in ob.users_collection):continue
    jewelry.append(ob);me=ob.data;edge_counts=Counter()
    if me.name not in mesh_checks:
        adj=[set() for v in me.vertices]
        for e in me.edges:a,b=e.vertices;adj[a].add(b);adj[b].add(a)
        unseen=set(range(len(me.vertices)));components=0
        while unseen:
            pending=[unseen.pop()];components+=1
            while pending:
                current=pending.pop()
                for other in adj[current]:
                    if other in unseen:unseen.remove(other);pending.append(other)
        me.calc_loop_triangles();vol=sum(me.vertices[t.vertices[0]].co.dot(me.vertices[t.vertices[1]].co.cross(me.vertices[t.vertices[2]].co))/6 for t in me.loop_triangles)
        mesh_checks[me.name]=(components,vol)
    nc,vol=mesh_checks[me.name];global_counts['disjoint_topological_shells']+=nc
    if vol<=0:volume_issues.append({'object':ob.name,'signed_volume':vol})
    for poly in me.polygons:
        vs=list(poly.vertices)
        for j in range(len(vs)):edge_counts[tuple(sorted((vs[j],vs[(j+1)%len(vs)])))]+=1
    boundary=sum(v==1 for v in edge_counts.values());nonmanifold=sum(v!=2 for v in edge_counts.values());global_counts['mesh_objects']+=1;global_counts['vertices_in_instances']+=len(me.vertices);global_counts['faces_in_instances']+=len(me.polygons);global_counts['boundary_edges']+=boundary;global_counts['nonmanifold_edges']+=nonmanifold
    if boundary or nonmanifold:records.append({'object':ob.name,'boundary_edges':boundary,'nonmanifold_edges':nonmanifold})
    all_v.extend([ob.matrix_world@v.co for v in me.vertices])
mins=[min(v[i] for v in all_v) for i in range(3)];maxs=[max(v[i] for v in all_v) for i in range(3)]
notes={'design':'13','source':os.path.basename(SOURCE),'method':'Actual 3D Blender reconstruction guided by inspected photo, with unobserved depth reconstructed as an interpretation. No AI-generated imagery.','scale_status':'No dimensions or orthographic views supplied. All dimensions estimated except chosen nominal 18 mm inner diameter, itself an assumption.','editable_parameters_mm':P,'observed_features':['Broad circular radial gold flower crown','Concentric tiers of pointed marquise/leaf outlines','Fine granulated rims around each openwork leaf','Smaller raised polished gold marquise inlays within outer open frames','Central compact flower','Broad reflective complete ring shank'],'inferred_features':['20 outer petals, 12 middle petals and 6 inner petals are an explicit count interpretation from partially occluded single-view photo','Crown dome, underside open gallery, plate thickness, bridges and shoulder geometry estimated','18 mm inner diameter selected as an editable nominal design assumption'],'geometry_validation':dict(global_counts),'mesh_edge_issues':records,'nonpositive_signed_volume_issues':volume_issues,'rim_wall_cross_section_mm':{'radial_width':.40,'vertical_depth':.68},'overall_bbox_mm':{'min':mins,'max':maxs,'size':[maxs[i]-mins[i] for i in range(3)]},'components':'Separate closed mesh solids retained for editable goldsmith-style assembly. Bead spheres share an editable master mesh. Each named continuous part is closed; the entire assembly is not Boolean-unified.','intersections':'Intentional intersecting solids at bead-to-rim, spine-to-medallion, gallery-to-crown and shoulder-to-shank joints; not checked for zero-clearance manufacturing. Interior coincident volume remains; mesh-edge manifold checks do not validate a castable single solid.','manufacturing_readiness':False,'manufacturing_requirements':['Confirm ring size and all dimensions','Confirm petal counts and back/side geometry with additional photographs','Boolean-union and repair all joining solids or prepare separate production parts','Check bead retention, minimum wall/strut thickness, clearances and shrinkage with jeweler/CAD engineer']}
with open(os.path.join(OUT,'design13_geometry_notes.json'),'w') as f:json.dump(notes,f,indent=2)
readme='DESIGN 13 — RADIAL MARQUISE FLOWER RING\n\nPhoto-guided 3D interpretation. Editable complete 360-degree band, rising shoulders, open underside gallery and three dimensional petal tiers. Original supplied photograph is packed inside the blend as a hidden reference object.\n\nSCALE: The reference contains no physical measurements. Inner ring diameter is an editable assumed 18 mm; all other dimensions are estimated. Scene units are millimetres. Not manufacturing-ready.\n\nFILES\n- design13_editable.blend: original named geometry, gold materials, lighting, camera, packed photo\n- design13_preview.png: 1200 x 1200 rendered view\n- design13_mesh.glb: mesh-only gold assembly (metres in glTF, derived from millimetre model)\n- model_design13.py: complete parameterized source; edit P at top and rerun Blender\n- design13_geometry_notes.json: dimensions, assumptions and mesh-edge validation\n\nINTERSECTIONS: All gold parts retain separate closed surfaces for editability. Intended bead/rim, petal/stem/gallery and shoulder/shank intersections are not Boolean fused. This is a visual design reconstruction, not a watertight single casting master.\n'
open(os.path.join(OUT,'README.txt'),'w').write(readme)
# Mesh-only export, scaled to physical metres by Blender scene scale.
bpy.ops.object.select_all(action='DESELECT')
for ob in jewelry:ob.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'design13_mesh.glb'),export_format='GLB',use_selection=True,export_yup=True,export_apply=True)
# glTF lengths are metres. This Blender build does not bake scene unit scale.
# Wrap existing roots in an explicit 0.001 transform, retaining editable part hierarchy.
import struct
glb_path=os.path.join(OUT,'design13_mesh.glb');raw=open(glb_path,'rb').read();jlen,jtype=struct.unpack_from('<II',raw,12);doc=json.loads(raw[20:20+jlen]);binary=raw[20+jlen:]
for sc in doc['scenes']:
    root=len(doc['nodes']);doc['nodes'].append({'name':'Millimetre_to_metre_physical_scale','scale':[.001,.001,.001],'children':sc['nodes']});sc['nodes']=[root]
js=json.dumps(doc,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
open(glb_path,'wb').write(struct.pack('<III',0x46546C67,2,20+len(js)+len(binary))+struct.pack('<II',len(js),0x4E4F534A)+js+binary)
# Save native scene; render draft first then final.
scene.render.resolution_percentage=60;scene.cycles.samples=24;scene.render.filepath=os.path.join(OUT,'design13_draft.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'design13_editable.blend'))
bpy.ops.render.render(write_still=True)
scene.render.resolution_percentage=100;scene.cycles.samples=144;scene.render.filepath=os.path.join(OUT,'design13_preview.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'design13_editable.blend'))
bpy.ops.render.render(write_still=True)
print('DESIGN13_COMPLETE',json.dumps(dict(global_counts)))
