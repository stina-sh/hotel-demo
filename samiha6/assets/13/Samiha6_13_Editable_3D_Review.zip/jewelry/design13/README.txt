DESIGN 13 — RADIAL MARQUISE FLOWER RING

Photo-guided 3D interpretation. Editable complete 360-degree band, rising shoulders, open underside gallery and three dimensional petal tiers. Original supplied photograph is packed inside the blend as a hidden reference object.

SCALE: The reference contains no physical measurements. Inner ring diameter is an editable assumed 18 mm; all other dimensions are estimated. Scene units are millimetres. Not manufacturing-ready.

FILES
- design13_editable.blend: original named geometry, gold materials, lighting, camera, packed photo
- design13_preview.png: 1200 x 1200 rendered view
- design13_mesh.glb: mesh-only gold assembly (metres in glTF, derived from millimetre model)
- model_design13.py: complete parameterized source; edit P at top and rerun Blender
- design13_geometry_notes.json: dimensions, assumptions and mesh-edge validation

INTERSECTIONS: All gold parts retain separate closed surfaces for editability. Intended bead/rim, petal/stem/gallery and shoulder/shank intersections are not Boolean fused. This is a visual design reconstruction, not a watertight single casting master.
