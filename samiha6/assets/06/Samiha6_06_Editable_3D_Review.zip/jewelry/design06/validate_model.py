# Usage: blender -b Samiha5_01_3D.blend -P validate_model.py
import bpy, bmesh, json, os
out=os.path.dirname(bpy.data.filepath)
coll=bpy.data.collections.get('JEWELRY | editable dimensioned components')
issues=[];triangles=vertices=boundary=negative=0
for ob in coll.objects:
 dg=bpy.context.evaluated_depsgraph_get();ev=ob.evaluated_get(dg);me=ev.to_mesh();bm=bmesh.new();bm.from_mesh(me)
 edges=sum(1 for e in bm.edges if not e.is_manifold);vol=bm.calc_volume(signed=True)
 if edges or vol<=0:issues.append({'object':ob.name,'nonmanifold_edges':edges,'signed_volume_mm3':vol})
 boundary+=edges;negative+=int(vol<0);vertices+=len(me.vertices);me.calc_loop_triangles();triangles+=len(me.loop_triangles);bm.free();ev.to_mesh_clear()
report={'object_count':len(coll.objects),'vertices_evaluated':vertices,'triangles_evaluated':triangles,'nonmanifold_edges_per_component_sum':boundary,'negative_volume_components':negative,'component_issues':issues,'packed_photo':any(im.packed_file is not None for im in bpy.data.images),'warning':'Components are individually inspected, but intentional overlapping assemblies are not boolean-unioned and the total material volume is not a production weight.'}
open(os.path.join(out,'mesh_quality_report.json'),'w').write(json.dumps(report,indent=2));print('MODEL_QA',json.dumps(report))
