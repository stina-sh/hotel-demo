"""Validate binary GLB and STL dimensional consistency without external libraries."""
import json, struct, itertools, math
from pathlib import Path
p=Path(__file__).resolve().parent;design=p.name[-2:]
glb=p/f'Samiha5_{design}_3D.glb';stl=p/f'Samiha5_{design}_review_mm.stl'
b=glb.read_bytes();length,tag=struct.unpack_from('<II',b,12);j=json.loads(b[20:20+length])
def mm(a,b):return [[sum(a[r][k]*b[k][c] for k in range(4)) for c in range(4)] for r in range(4)]
def ident():return [[int(r==c) for c in range(4)] for r in range(4)]
def node_matrix(n):
 if 'matrix' in n:return [[n['matrix'][c*4+r] for c in range(4)] for r in range(4)]
 x,y,z,w=n.get('rotation',[0,0,0,1]);sx,sy,sz=n.get('scale',[1,1,1]);tx,ty,tz=n.get('translation',[0,0,0])
 return [[(1-2*y*y-2*z*z)*sx,(2*x*y-2*z*w)*sy,(2*x*z+2*y*w)*sz,tx],[(2*x*y+2*z*w)*sx,(1-2*x*x-2*z*z)*sy,(2*y*z-2*x*w)*sz,ty],[(2*x*z-2*y*w)*sx,(2*y*z+2*x*w)*sy,(1-2*x*x-2*y*y)*sz,tz],[0,0,0,1]]
lo=[math.inf]*3;hi=[-math.inf]*3
def walk(i,parent):
 n=j['nodes'][i];m=mm(parent,node_matrix(n))
 if 'mesh' in n:
  for prim in j['meshes'][n['mesh']]['primitives']:
   a=j['accessors'][prim['attributes']['POSITION']]
   for v in itertools.product(*zip(a['min'],a['max'])):
    q=[sum(m[r][c]*(*v,1)[c] for c in range(4)) for r in range(3)]
    for k in range(3):lo[k]=min(lo[k],q[k]);hi[k]=max(hi[k],q[k])
 for c in n.get('children',[]):walk(c,m)
for r in j['scenes'][j.get('scene',0)]['nodes']:walk(r,ident())
b=stl.read_bytes();count=struct.unpack_from('<I',b,80)[0];slo=[math.inf]*3;shi=[-math.inf]*3
assert len(b)==84+count*50
for i in range(count):
 tri=struct.unpack_from('<12f',b,84+i*50)
 for v in (tri[3:6],tri[6:9],tri[9:12]):
  for k in range(3):slo[k]=min(slo[k],v[k]);shi[k]=max(shi[k],v[k])
gsize=[hi[k]-lo[k] for k in range(3)];ssize=[shi[k]-slo[k] for k in range(3)]
err=max(abs(a*1000-b) for a,b in zip(sorted(gsize),sorted(ssize)))
report={'design':design,'glb_bounds_metres':{'minimum':lo,'maximum':hi,'size':gsize},'stl_bounds_millimetres':{'minimum':slo,'maximum':shi,'size':ssize},'max_dimension_difference_mm':err,'explicit_metres_conversion':.001,'exchange_units_consistent':err<.01,'glb_only_jewelry':len(j.get('cameras',[]))==0 and len(j.get('images',[]))==0,'stl_triangle_count':count}
(p/'exchange_quality_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
assert report['exchange_units_consistent']
