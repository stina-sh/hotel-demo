# Render an existing editable reconstruction: blender -b <model.blend> -t 2 -P render_existing.py
import bpy, os
from mathutils import Vector
sc=bpy.context.scene;out=os.path.dirname(bpy.data.filepath);design=os.path.basename(out)[-2:];cam=sc.camera
sc.render.threads_mode='FIXED';sc.render.threads=6;sc.cycles.samples=64;sc.cycles.use_denoising=False
sc.render.resolution_x=sc.render.resolution_y=1200;sc.render.resolution_percentage=100
sc.render.filepath=os.path.join(out,'Samiha5_'+design+'_perspective.png');bpy.ops.render.render(write_still=True)
cam.location=(24,-37,9);cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler()
sc.render.resolution_percentage=75;sc.render.filepath=os.path.join(out,'Samiha5_'+design+'_low_angle.png');bpy.ops.render.render(write_still=True)
