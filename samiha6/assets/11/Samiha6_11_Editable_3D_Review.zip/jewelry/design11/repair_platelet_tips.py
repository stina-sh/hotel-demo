"""Eliminate zero-area tip artifacts without changing the rendered surface."""
import bpy,bmesh,os,sys,json
ROOT=os.path.dirname(os.path.abspath(__file__))
N=11
blend=os.path.join(ROOT,'Samiha5_%02d_3D.blend'%N)
bpy.ops.wm.open_mainfile(filepath=blend)
changes=[]
for o in list(bpy.data.objects):
 if o.type!='MESH' or 'raised polished face' not in o.name:continue
 bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();m=bpy.data.meshes.new_from_object(o.evaluated_get(deps),preserve_all_data_layers=True,depsgraph=deps)
 before=len(m.vertices);bm=bmesh.new();bm.from_mesh(m)
 bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7)
 bmesh.ops.dissolve_degenerate(bm,dist=1e-7,edges=list(bm.edges))
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(m);bm.free();m.update()
 for mod in list(o.modifiers):o.modifiers.remove(mod)
 o.data=m;m.calc_loop_triangles()
 zero=[]
 for t in m.loop_triangles:
  a,b,c=[m.vertices[i].co for i in t.vertices];area=(b-a).cross(c-a).length*.5
  if area<1e-12:zero.append(t.index)
 bm=bmesh.new();bm.from_mesh(m);bad=sum(not e.is_manifold for e in bm.edges);bm.free()
 changes.append({'object':o.name,'vertices_before':before,'vertices_after':len(m.vertices),'zero_triangles':zero,'nonmanifold_edges':bad})
 if zero or bad:raise RuntimeError('Cleanup left invalid geometry: '+str(changes[-1]))
model=bpy.data.collections.get('JEWELRY | individually editable components')
bpy.ops.object.select_all(action='DESELECT')
for o in model.objects:o.select_set(True);o.scale=(.001,.001,.001)
bpy.context.view_layer.objects.active=next(iter(model.objects));bpy.ops.export_scene.gltf(filepath=os.path.join(ROOT,'Samiha5_%02d_3D.glb'%N),use_selection=True,export_apply=True)
for o in model.objects:o.scale=(1,1,1)
bpy.ops.wm.stl_export(filepath=os.path.join(ROOT,'Samiha5_%02d_review_mm.stl'%N),export_selected_objects=True,apply_modifiers=True)
bpy.ops.wm.save_as_mainfile(filepath=blend)
open(os.path.join(ROOT,'TIP_GEOMETRY_QA.json'),'w').write(json.dumps(changes,indent=2))
print('REPAIR VERIFIED:',len(changes),'closed platelets, no zero-area triangles')
