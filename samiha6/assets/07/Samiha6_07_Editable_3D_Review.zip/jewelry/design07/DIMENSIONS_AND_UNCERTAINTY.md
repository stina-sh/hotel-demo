# Samiha5 design 07 — 3D reconstruction

07 — broad scalloped leaf-and-circle openwork mosaic

## Basis and limitations
Built from the supplied original reference photograph, embedded in the Blender file. This is a three-dimensional cylindrical ring assembly: complete curved shank, curved-through-space crown galleries, polished raised face plates, structural bridge stems, and individual rounded milgrain beads. It is not a flat SVG extrusion.

Photograph scale is unavailable. All dimensions below are provisional and must be confirmed against a measured sample. Ring size, unseen underside, reverse shoulders, wall thickness, leaf separations and tiny fluted/milgrain details are interpretive. The photograph is low-resolution, so exact surface profile and motif counts at the foreshortened outer shoulder remain uncertain. Gold color is an appearance approximation, not an alloy specification.

## Assumed dimensions (mm)
- nominal inside diameter mm: 18
- nominal shank width mm: 2.65
- nominal shank radial thickness mm: 0.76
- crown axial width approx mm: 8.4

## Files and use
- Editable .blend: named separate components, camera and studio; packed original photograph
- build.py: self-contained reproducible script for Blender 4.3; run `blender -b -t 2 --python build.py`
- .glb: rendered-material review model, exported with metric scene units
- _review_mm.stl: geometry review with numeric coordinates in millimetres
- _perspective.png: 1200 by 1200 rendered view
- reference.jpg: original photo

## Manufacturing caution
VISUAL REVIEW ONLY, NOT MANUFACTURING-READY. The components are closed individual shells but are intentionally assembled with overlaps. A goldsmith/CAD technician must check their unions, bridges, wall/feature thickness, clearances, size, shrinkage, underside comfort, tooling/casting constraints and final polish allowance. STL does not imply casting readiness.

## Verified exported bounding box
Actual overall model extents (X, axial Y, Z): 19.519 × 8.333 × 20.255 mm. These are measured from the constructed review mesh, not from the photograph. GLB root transforms have been independently checked in metres. The numeric STL has no open boundary edges after tolerance welding; it remains an overlapping assembly requiring Boolean union and manufacturing review.
