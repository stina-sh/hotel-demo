# Refine inferred reverse supports to terminate under the visible crown, then export and render.
import bpy, os
sc=bpy.context.scene;out=os.path.dirname(bpy.data.filepath);design=int(os.path.basename(out)[-2:])
ranges={1: {-1: (0, 4.68), 1: (-4.7, 0)}, 4: {-1: (-2.6, 4.65), 1: (-2.1, 0)}, 6: {-1: (0, 3.15), 1: (-4.7, 0)}, 8: {-1: (-3.3, 3.0), 1: (-3.4, 2.9)}, 14: {-1: (0, 4.98), 1: (-5.0, 0)}}
for ob in bpy.data.objects:
 if ob.type=='MESH' and ob.name.startswith('Slim transverse under-crown shoulder '):
  side=int(ob.name.rsplit(' ',1)[1]);a,b=ranges[design][side]
  for v in ob.data.vertices:
   i=v.index//12;v.co.y = a+(b-a)*i/48
  ob.data.update()
model=bpy.data.collections.get('JEWELRY | editable dimensioned components')
bpy.ops.object.select_all(action='DESELECT')
for ob in model.objects:ob.select_set(True)
bpy.context.view_layer.objects.active=next(iter(model.objects))
root=bpy.data.objects.new('Millimetres to metres | exchange scale',None);sc.collection.objects.link(root);root.scale=(.001,.001,.001);root.select_set(True)
for ob in model.objects:ob.parent=root
bpy.ops.export_scene.gltf(filepath=os.path.join(out,'Samiha5_%02d_3D.glb'%design),use_selection=True,export_apply=True)
for ob in model.objects:ob.parent=None
bpy.data.objects.remove(root,do_unlink=True)
bpy.ops.wm.stl_export(filepath=os.path.join(out,'Samiha5_%02d_review_mm.stl'%design),export_selected_objects=True,apply_modifiers=True)
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
exec(compile(open(os.path.join(out,'validate_model.py')).read(),'validate_model.py','exec'))
exec(compile(open(os.path.join(out,'render_existing.py')).read(),'render_existing.py','exec'))
