import sys,os
from pathlib import Path
D=int(sys.argv[sys.argv.index('--')+1]);ROOT=Path(__file__).resolve().parent;OUT=str(ROOT/('design%02d'%D));os.makedirs(OUT,exist_ok=True)
import shutil
if not Path(OUT+'/reference.jpg').exists():
 source=ROOT/'references'/('IMG-20260928-WA00%02d.jpg'%D)
 if not source.exists():raise FileNotFoundError('Place the original image at '+OUT+'/reference.jpg before rebuilding')
 shutil.copy(source,OUT+'/reference.jpg')
code=(ROOT/'model_utils.py').read_text();code=code.replace("OUT=os.path.dirname(os.path.abspath(__file__))",'')
exec(code)
# Complete tapered shank joining shoulders at +/- 68 degrees.
vs=[];fs=[];N=200
for i in range(N+1):
 a=1.13+(2*pi-2.26)*i/N; f=max(0,(abs(a-pi)-(pi-1.13-.58))/.58);width=2.35+1.5*f*f
 for r,y in [(9.,-width/2),(9.,width/2),(9.85,width/2),(9.85,-width/2)]:vs.append((r*sin(a),y,r*cos(a)))
for i in range(N):
 for j in range(4):fs.append((4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j))
fs.extend([(3,2,1,0),tuple(4*N+j for j in range(4))]);o=mesh('Complete tapered shank | reverse geometry estimated',vs,fs);bev=o.modifiers.new('Comfort round','BEVEL');bev.width=.1;bev.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
for sign in [-1,1]:
 lo,hi=((-2.5+sign*1.5,2.5+sign*1.5) if D==2 else (-2.52,1.0))
 tube('Crown transverse shoulder support',[P(sign*11.15,lo,9.77),P(sign*11.15,hi,9.77)],.22)
GALLERY=[];ANCHORS=[]
def outline(cx,cy,L,W,ang=0,N=80):
 out=[]
 for i in range(N):
  t=2*pi*i/N;x=L/2*cos(t);y=W/2*sin(t)*abs(sin(t))**1.0;out.append((cx+x*cos(ang)-y*sin(ang),cy+x*sin(ang)+y*cos(ang)))
 return out
def plate(name,coords,r=10.28,th=.38):
 n=len(coords);vs=[P(x,y,z) for z in [r-th,r] for x,y in coords];cx=sum(p[0] for p in coords)/n;cy=sum(p[1] for p in coords)/n
 vs += [P(cx,cy,r-th),P(cx,cy,r)];fs=[]
 for i in range(n):j=(i+1)%n;fs += [(i,j,j+n,i+n),(2*n,j,i),(2*n+1,i+n,j+n)]
 o=mesh(name,vs,fs);b=o.modifiers.new('Hand-polished rim','BEVEL');b.width=.05;b.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
def gallery_wall(name,coords,r=10.09,depth=.58,width=.19):
 n=len(coords);vs=[];fs=[]
 for i,(x,y) in enumerate(coords):
  prev=Vector(coords[(i-1)%n]);nxt=Vector(coords[(i+1)%n]);d=(nxt-prev).normalized();nx,ny=-d.y,d.x
  for rad,off in [(r-depth,-width/2),(r-depth,width/2),(r,width/2),(r,-width/2)]:vs.append(P(x+nx*off,y+ny*off,rad))
 for i in range(n):
  for j in range(4):fs.append((i*4+j,i*4+(j+1)%4,((i+1)%n)*4+(j+1)%4,((i+1)%n)*4+j))
 o=mesh(name,vs,fs);b=o.modifiers.new('Rounded gallery edge','BEVEL');b.width=.035;b.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
def leaf(name,s,y,L=3.9,W=2.1,ang=0):
 co=outline(s,y,L,W,ang);pts=[P(x,z,10.04) for x,z in co];GALLERY.append(pts);gallery_wall(name+' open gallery wall',co);edge_beads(pts+[pts[0]],.19)
 # Rim-to-center structural stems are integral assembly connections.
 co=outline(s,y,L*.74,W*.57,ang);plate(name+' raised platelet',co,10.38,.37)
 for t in [0,pi,pi/2]:
  x=L/2*cos(t);z=W/2*sin(t);a=(x*cos(ang)-z*sin(ang),x*sin(ang)+z*cos(ang));tube(name+' bridge',[P(s+a[0]*.57,y+a[1]*.57,10.05),P(s+a[0],y+a[1],10.04)],.072)
def band(name,fn,width,start=-11.5,end=11.5,rad=10.18):
 ribbon(name,start,end,0,width,rad,.72,fn)
 for sign in [-1,1]:
  pts=[P(start+(end-start)*i/240,fn(start+(end-start)*i/240)+sign*width/2,rad+.01) for i in range(241)];tube(name+' rolled rim',pts,.075);edge_beads(pts,.20);ANCHORS.extend(pts)
if D==2:
 band('Sweeping diagonal gold ribbon',lambda s:.14*s+.28*cos(s/7),1.65)
 for sign in [-1,1]:
  for j,s in enumerate([-9,-5.4,-1.8,1.8,5.4,9]):
   y=.14*s+.28*cos(s/7)+sign*2.07;leaf('Border%d leaf%d'%(sign,j),s,y,3.65,2.05,(-.15 if sign<0 else .45))
 # Tie every border gallery into the sweeping ribbon.
 for sign in [-1,1]:
  for ss in [-9,-5.4,-1.8,1.8,5.4,9]:
   yy=.14*ss+.28*cos(ss/7);tube('Leaf to ribbon bridge',[P(ss,yy+sign*.78,9.93),P(ss,yy+sign*1.37,9.93)],.13)
 # small round accent visible near center of upper ribbon
 co=[(-2+.5*cos(2*pi*i/48),-.1+.5*sin(2*pi*i/48)) for i in range(48)];plate('Round raised accent',co,10.52,.35)
else:
 # Foreground chevron ribbon and crown; D09 has a second separated ribbon.
 fn=lambda s:-2.65+.95*(abs(s)/11.5)**.75
 band('Shallow chevron front band',fn,1.8)
 if D==9:band('Split upper ribbon',lambda s:-.82+.35*(abs(s)/11.5),1.28)
 # Flower fan at center; positions reflect photograph, extending above ribbon.
 leaves=[(-1.15,.2,3.45,1.95,1.13),(1.1,.2,3.6,1.95,1.98),(-2.35,2.5,3.45,1.95,1.98),(.15,3.0,3.7,1.85,1.30),(2.95,2.25,3.6,1.85,.55)]
 if D==9:leaves=[(-1.1,.6,3.5,1.9,1.28),(1.35,.65,3.5,1.8,1.7),(-2.0,3.0,2.65,1.85,1.9),(.6,3.1,3.65,1.8,1.4),(3.0,2.1,3.2,1.8,.55)]
 for i,p in enumerate(leaves):leaf('Central crown petal%02d'%i,*p)
 for sign in [-1,1]:
  for j,s in enumerate([4.9,7.6,10.]):
   leaf('Shoulder crown%d_%d'%(sign,j),sign*s,.9-.08*s,3.0,1.8,.20*sign)
   if D==12 and j<2:leaf('Lower interlocking petal%d_%d'%(sign,j),sign*(s-.9),-.45,2.7,1.65,-.25*sign)
# Minimal under-gallery spanning supports physically connect every ornament to a ribbon.
import numpy as np
arrays=[np.array(ANCHORS)]+[np.array(p) for p in GALLERY];edges=[]
for a in range(len(arrays)):
 for b in range(a+1,len(arrays)):
  dist=((arrays[a][:,None,:]-arrays[b][None,:,:])**2).sum(axis=2);ii,jj=np.unravel_index(dist.argmin(),dist.shape);edges.append((float(dist[ii,jj]),a,b,arrays[a][ii],arrays[b][jj]))
parents=list(range(len(arrays)))
def root(k):
 while parents[k]!=k:k=parents[k]
 return k
for distance,a,b,pa,pb in sorted(edges,key=lambda x:x[0]):
 ra,rb=root(a),root(b)
 if ra==rb:continue
 parents[ra]=rb
 if distance>.005:
  pa=Vector(pa);pb=Vector(pb)
  for v in [pa,pb]:
   rr=(v.x*v.x+v.z*v.z)**.5;v.x*=9.79/rr;v.z*=9.79/rr
  delta=(pb-pa).normalized()*.12;tube('Structural under-gallery joining bridge',[pa-delta,pb+delta],.14)
mesh('Milgrain | individually editable bead geometry',BV,BF,smooth=True)
# Save source reference and clear studio-separated export collection.
ref=bpy.data.images.load(OUT+'/reference.jpg');ref.pack();o=bpy.data.objects.new('Original source photograph | scale unknown',None);o.empty_display_type='IMAGE';o.data=ref;bpy.context.collection.objects.link(o);o.hide_render=True;o.hide_viewport=True
model=bpy.data.collections.new('JEWELRY | separate solid components');sc.collection.children.link(model)
for o in list(bpy.context.collection.objects):
 if o.type=='MESH':
  for col in list(o.users_collection):col.objects.unlink(o)
  model.objects.link(o)
sc['nominal_inner_diameter_mm']=18.;sc['scale_status']='Assumed, not measured';sc['geometry_status']='Photograph-led visual reconstruction; hidden shank inferred; assembled overlapping solids, not casting ready'
floor=material('Studio gray',(.18,.19,.21),0,.33);bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-10.03));bpy.context.object.data.materials.append(floor)
def point_at(o,t):o.rotation_euler=(Vector(t)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(16,-40,60));cam=bpy.context.object;point_at(cam,(0,0,1));cam.data.type='ORTHO';cam.data.ortho_scale=30;sc.camera=cam
for loc,power,size,col in [((-15,-20,35),16000,22,(1,.93,.8)),((23,8,24),12000,15,(1,1,1)),((-25,5,8),9500,18,(.8,.88,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=col;point_at(o,(0,0,0))
sc.world.use_nodes=True;bg=sc.world.node_tree.nodes.get('Background');bg.inputs['Color'].default_value=(.55,.55,.55,1);bg.inputs['Strength'].default_value=.7;sc.render.engine='CYCLES';sc.cycles.samples=96;sc.cycles.use_denoising=False;sc.render.threads_mode='FIXED';sc.render.threads=2;sc.render.resolution_x=1200;sc.render.resolution_y=1200;sc.render.resolution_percentage=100;sc.view_settings.view_transform='AgX'
bpy.ops.object.select_all(action='DESELECT')
for o in model.objects:o.select_set(True)
bpy.context.view_layer.objects.active=next(iter(model.objects));prefix=OUT+'/Samiha5_%02d'%D
bpy.ops.export_scene.gltf(filepath=prefix+'_3D.glb',use_selection=True,export_apply=True);bpy.ops.wm.stl_export(filepath=prefix+'_review_mm.stl',export_selected_objects=True,apply_modifiers=True)
exec((ROOT/'fix_glb_units.py').read_text().split("if __name__==")[0]);fix(prefix+'_3D.glb')
bpy.ops.wm.save_as_mainfile(filepath=prefix+'_3D.blend');sc.render.filepath=prefix+'_perspective.png';bpy.ops.render.render(write_still=True)
