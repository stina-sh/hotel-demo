import bpy, math, os, json
from mathutils import Vector
from math import sin, cos, pi
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene; sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001;sc.unit_settings.length_unit='MILLIMETERS'
R=9.0; gold=None
# All lengths in millimetres. Scale and reverse-side structure are explicit assumptions.
def material(name,color,metal=0,rough=.25):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
gold=material('Warm yellow gold | visual approximation',(.78,.54,.20),1,.28)
def mesh(name,vs,fs,mat=gold,smooth=False):
 m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
 if smooth:
  for p in m.polygons:p.use_smooth=True
 return o
def P(s,y,r=10):
 a=s/10;return Vector((r*sin(a),y,r*cos(a)))
def tube(name,pts,rad,cyclic=False,sides=10):
 vs=[];fs=[]; n=len(pts)
 for i,p in enumerate(pts):
  tang=(Vector(pts[(i+1)%n])-Vector(pts[(i-1)%n])) if cyclic else Vector(pts[min(n-1,i+1)])-Vector(pts[max(0,i-1)])
  tang.normalize();u=tang.cross(Vector((0,1,0)))
  if u.length<.01:u=tang.cross(Vector((0,0,1)))
  u.normalize();v=tang.cross(u).normalized()
  for j in range(sides):vs.append(Vector(p)+rad*(u*cos(j*2*pi/sides)+v*sin(j*2*pi/sides)))
 for i in range(n if cyclic else n-1):
  for j in range(sides):a=i*sides+j;b=i*sides+(j+1)%sides;c=((i+1)%n)*sides+(j+1)%sides;d=((i+1)%n)*sides+j;fs.append((a,b,c,d))
 if not cyclic:fs.extend([tuple(range(sides-1,-1,-1)),tuple((n-1)*sides+j for j in range(sides))])
 return mesh(name,vs,fs,smooth=True)
def ribbon(name,start,end,y,width,r=10,th=.7,offset=None):
 vs=[];fs=[];N=160
 for i in range(N+1):
  s=start+(end-start)*i/N; yy=y+(offset(s) if offset else 0)
  for rad,dy in [(r-th,-width/2),(r-th,width/2),(r,width/2),(r,-width/2)]:vs.append(P(s,yy+dy,rad))
 for i in range(N):
  for j in range(4):fs.append((4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j))
 fs.extend([(3,2,1,0),tuple(4*N+j for j in range(4))]);o=mesh(name,vs,fs)
 bevel=o.modifiers.new('Soft polished edges','BEVEL');bevel.width=.07;bevel.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
# Shared bead geometry, aggregated meshes are more efficient and fully editable.
BV=[];BF=[]
def bead(c,r=.092):
 c=Vector(c);base=len(BV);lat=6;lon=10
 BV.append(tuple(c+Vector((0,0,r))))
 for a in range(1,lat):
  t=pi*a/lat
  for b in range(lon):u=2*pi*b/lon;BV.append(tuple(c+Vector((r*sin(t)*cos(u),r*sin(t)*sin(u),r*cos(t)))))
 BV.append(tuple(c-Vector((0,0,r))));bottom=len(BV)-1
 for b in range(lon):BF.append((base,base+1+b,base+1+(b+1)%lon))
 for a in range(lat-2):
  for b in range(lon):v=base+1+a*lon+b;w=base+1+a*lon+(b+1)%lon;BF.append((v,v+lon,w+lon,w))
 for b in range(lon):BF.append((bottom,base+1+(lat-2)*lon+(b+1)%lon,base+1+(lat-2)*lon+b))
def edge_beads(pts,spacing=.20):
 # equal-distance sampling on a dense polyline
 carry=0.;prev=Vector(pts[0]);bead(prev)
 for p in pts[1:]:
  p=Vector(p);v=p-prev;l=v.length
  if l:
   d=spacing-carry
   while d<=l:bead(prev+v*(d/l));d+=spacing
   carry=l-(d-spacing)
  prev=p
