import struct,json,sys
from pathlib import Path
def fix(path):
 p=Path(path);blob=p.read_bytes();magic,version,total=struct.unpack('<III',blob[:12]);chunks=[];off=12
 while off<len(blob):
  n,t=struct.unpack('<II',blob[off:off+8]);off+=8;chunks.append((t,blob[off:off+n]));off+=n
 doc=json.loads(chunks[0][1]);nodes=doc.setdefault('nodes',[])
 if any(n.get('name')=='Millimetres to metres | 0.001' for n in nodes):return
 for scene in doc.get('scenes',[]):
  root={'name':'Millimetres to metres | 0.001','scale':[.001,.001,.001],'children':scene.get('nodes',[])};scene['nodes']=[len(nodes)];nodes.append(root)
 doc.setdefault('asset',{}).setdefault('extras',{})['source_units']='millimeters; root transform converts to glTF metres'
 b=json.dumps(doc,separators=(',',':')).encode();b+=b' '*((-len(b))%4);chunks[0]=(chunks[0][0],b);out=b''.join(struct.pack('<II',len(b),t)+b for t,b in chunks);p.write_bytes(struct.pack('<III',magic,version,12+len(out))+out)
 print(path,'GLB root scale confirmed 0.001')
if __name__=='__main__':
 for p in sys.argv[1:]:fix(p)
