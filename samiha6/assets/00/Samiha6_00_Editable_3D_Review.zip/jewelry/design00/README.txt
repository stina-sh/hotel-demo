DESIGN 00
Photo-guided 3D visual reconstruction. Nominal inner diameter 18.0 mm is an unconfirmed editable review assumption. Other dimensions and hidden construction are inferred.

.blend = editable mesh components with materials, studio and packed original reference.
.glb = metre-unit mesh interchange.
.stl = numerical millimetres, review only.
_mesh.3dm when included = Rhino millimetre mesh interchange, NOT NURBS/BREP.

Individual closed components intentionally overlap and need jeweler review and a fused master before manufacture. No casting readiness or exact photographic reverse engineering is claimed. See package README for full instructions.
