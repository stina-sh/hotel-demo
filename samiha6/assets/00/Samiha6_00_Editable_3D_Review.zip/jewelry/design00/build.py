import bpy, math, os, json
from mathutils import Vector
from math import sin, cos, pi
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
sc=bpy.context.scene; sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001;sc.unit_settings.length_unit='MILLIMETERS'
R=9.0; gold=None
# All lengths in millimetres. Scale and reverse-side structure are explicit assumptions.
def material(name,color,metal=0,rough=.25):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
gold=material('Warm yellow gold | visual approximation',(.78,.54,.20),1,.28)
def mesh(name,vs,fs,mat=gold,smooth=False):
 m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
 if smooth:
  for p in m.polygons:p.use_smooth=True
 return o
def P(s,y,r=10):
 a=s/10;return Vector((r*sin(a),y,r*cos(a)))
def tube(name,pts,rad,cyclic=False,sides=10):
 vs=[];fs=[]; n=len(pts)
 for i,p in enumerate(pts):
  tang=(Vector(pts[(i+1)%n])-Vector(pts[(i-1)%n])) if cyclic else Vector(pts[min(n-1,i+1)])-Vector(pts[max(0,i-1)])
  tang.normalize();u=tang.cross(Vector((0,1,0)))
  if u.length<.01:u=tang.cross(Vector((0,0,1)))
  u.normalize();v=tang.cross(u).normalized()
  for j in range(sides):vs.append(Vector(p)+rad*(u*cos(j*2*pi/sides)+v*sin(j*2*pi/sides)))
 for i in range(n if cyclic else n-1):
  for j in range(sides):a=i*sides+j;b=i*sides+(j+1)%sides;c=((i+1)%n)*sides+(j+1)%sides;d=((i+1)%n)*sides+j;fs.append((a,b,c,d))
 if not cyclic:fs.extend([tuple(range(sides-1,-1,-1)),tuple((n-1)*sides+j for j in range(sides))])
 return mesh(name,vs,fs,smooth=True)
def ribbon(name,start,end,y,width,r=10,th=.7,offset=None):
 vs=[];fs=[];N=160
 for i in range(N+1):
  s=start+(end-start)*i/N; yy=y+(offset(s) if offset else 0)
  for rad,dy in [(r-th,-width/2),(r-th,width/2),(r,width/2),(r,-width/2)]:vs.append(P(s,yy+dy,rad))
 for i in range(N):
  for j in range(4):fs.append((4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j))
 fs.extend([(3,2,1,0),tuple(4*N+j for j in range(4))]);o=mesh(name,vs,fs)
 bevel=o.modifiers.new('Soft polished edges','BEVEL');bevel.width=.07;bevel.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
# Shared bead geometry, aggregated meshes are more efficient and fully editable.
BV=[];BF=[]
def bead(c,r=.092):
 c=Vector(c);base=len(BV);lat=6;lon=10
 BV.append(tuple(c+Vector((0,0,r))))
 for a in range(1,lat):
  t=pi*a/lat
  for b in range(lon):u=2*pi*b/lon;BV.append(tuple(c+Vector((r*sin(t)*cos(u),r*sin(t)*sin(u),r*cos(t)))))
 BV.append(tuple(c-Vector((0,0,r))));bottom=len(BV)-1
 for b in range(lon):BF.append((base,base+1+b,base+1+(b+1)%lon))
 for a in range(lat-2):
  for b in range(lon):v=base+1+a*lon+b;w=base+1+a*lon+(b+1)%lon;BF.append((v,v+lon,w+lon,w))
 for b in range(lon):BF.append((bottom,base+1+(lat-2)*lon+(b+1)%lon,base+1+(lat-2)*lon+b))
def edge_beads(pts,spacing=.20):
 # equal-distance sampling on a dense polyline
 carry=0.;prev=Vector(pts[0]);bead(prev)
 for p in pts[1:]:
  p=Vector(p);v=p-prev;l=v.length
  if l:
   d=spacing-carry
   while d<=l:bead(prev+v*(d/l));d+=spacing
   carry=l-(d-spacing)
  prev=p
# Complete shank, narrower at base, shoulders joining decorative crown.
vs=[];fs=[];N=224
for i in range(N+1):
 a=1.05+(2*pi-2.10)*i/N; f=max(0,(abs(a-pi)-(pi-1.05-.6))/.6);width=2.45+1.8*f*f
 for r,y in [(9.,-width/2),(9.,width/2),(9.9,width/2),(9.9,-width/2)]:vs.append((r*sin(a),y,r*cos(a)))
for i in range(N):
 for j in range(4):fs.append((4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j))
fs.extend([(3,2,1,0),tuple(4*N+j for j in range(4))]);o=mesh('Complete comfort shank | estimated reverse geometry',vs,fs);bev=o.modifiers.new('Comfort rounding','BEVEL');bev.width=.12;bev.segments=4;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
for sign in [-1,1]:tube('Crown transverse shoulder support',[P(sign*11.45,-5.65,9.83),P(sign*11.45,5.8,9.83)],.32)
# Three swept solid bands; slight bow across span matches the reference.
def bow(s):return .45*(1-(s/11.3)**2)
for j,y in enumerate([-4.8,0,4.8]):
 ribbon('Crown polished ribbon %02d'%j,-11.8,11.8,y,1.70,r=10.18,th=.75,offset=bow)
 for sign in [-1,1]:
  pts=[P(-11.8+23.6*i/220,y+sign*.84+bow(-11.8+23.6*i/220),10.20) for i in range(221)];tube('Ribbon fine rolled edge',pts,.08);edge_beads(pts)
# Marquise leaves with a smaller raised platelet nested in an open surrounding gallery.
def outline(cx,cy,L,W,angle=0,N=80):
 pts=[]
 for i in range(N):
  t=2*pi*i/N; x=L/2*cos(t);y=W/2*sin(t)*abs(sin(t))**1.0
  pts.append((cx+x*cos(angle)-y*sin(angle),cy+x*sin(angle)+y*cos(angle)))
 return pts
def gallery_wall(name,coords,r=10.09,depth=.58,width=.19):
 n=len(coords);vs=[];fs=[]
 for i,(x,y) in enumerate(coords):
  prev=Vector(coords[(i-1)%n]);nxt=Vector(coords[(i+1)%n]);d=(nxt-prev).normalized();nx,ny=-d.y,d.x
  for rad,off in [(r-depth,-width/2),(r-depth,width/2),(r,width/2),(r,-width/2)]:vs.append(P(x+nx*off,y+ny*off,rad))
 for i in range(n):
  for j in range(4):fs.append((i*4+j,i*4+(j+1)%4,((i+1)%n)*4+(j+1)%4,((i+1)%n)*4+j))
 o=mesh(name,vs,fs);b=o.modifiers.new('Rounded gallery edge','BEVEL');b.width=.035;b.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
def leaf(name,s,y,L=4.35,W=2.65):
 coords=outline(s,y,L,W);pts=[P(x,z,10.04) for x,z in coords];gallery_wall(name+' open marquise wall',coords);edge_beads(pts+[pts[0]],.19)
 # Curved solid centre platelet, not an extruded trace.
 cs=outline(s,y-.12,L*.71,W*.49);vs=[P(x,z,r) for r in [10.01,10.37] for x,z in cs];n=len(cs);fs=[]
 fs.extend([tuple(range(n-1,-1,-1)),tuple(range(n,2*n))])
 for i in range(n):fs.append((i,(i+1)%n,(i+1)%n+n,i+n))
 o=mesh(name+' domed gold platelet',vs,fs);b=o.modifiers.new('Rounded leaf edges','BEVEL');b.width=.06;b.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 # Visible bridges at pointed tips and lower gallery, embedding both ends.
 for dx,dy in [(-L*.38,0),(L*.38,0),(0,-W*.33)]:
  tube(name+' structural bridge',[P(s+dx*.68,y+dy*.65,10.05),P(s+dx*1.20,y+dy*1.16,10.04)],.075)
 # Short ties positively connect the ornamental rim to the adjacent ribbons.
 for sign in [-1,1]:
  tube(name+' ribbon tie',[P(s,y+sign*W/2,9.99),P(s,y+sign*1.62,10.00)],.115)
for row,y in enumerate([-2.40,2.40]):
 for j,s in enumerate([-9.0,-4.5,0,4.5,9.0]):leaf('Row%d leaf%d'%(row+1,j+1),s,y+bow(s))
mesh('Milgrain | individual rounded beads',BV,BF,smooth=True)
# Store photographic source in a hidden reference collection; pack bytes into .blend.
ref=bpy.data.images.load(os.path.join(OUT,'reference.jpg'));ref.pack();empty=bpy.data.objects.new('SOURCE photograph | non-dimensional',None);empty.empty_display_type='IMAGE';empty.data=ref;bpy.context.collection.objects.link(empty);empty.hide_render=True;empty.hide_viewport=True
sc['design']='Samiha5 design00, reconstructed from original photograph';sc['dimension_assumptions']='18.0 mm nominal ID; 11.3 mm crown axial width. Scale unconfirmed. Reverse/shank inferred.';sc['readiness']='Visual design review only. Not casting/CNC approved. Intersecting assembled solids require goldsmith joining/union and wall/clearance review.'
# Model collection isolated from studio for clean export.
model=bpy.data.collections.new('JEWELRY | editable components');sc.collection.children.link(model)
for o in list(bpy.context.collection.objects):
 if o.type=='MESH':
  for coll in list(o.users_collection):coll.objects.unlink(o)
  model.objects.link(o)
# Studio
floor=material('Warm gray studio',(.18,.19,.21),0,.32);bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-10.05));bpy.context.object.name='Studio ground';bpy.context.object.data.materials.append(floor)
def point_at(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(30,-43,52));cam=bpy.context.object;point_at(cam,(0,0,1));cam.data.type='ORTHO';cam.data.ortho_scale=30;sc.camera=cam
for name,loc,power,size,color in [('Large softbox',(-15,-20,35),16000,22,(1,.93,.8)),('Strip highlight',(23,8,24),12000,15,(1,1,1)),('Fill',(-25,5,8),9500,18,(.8,.88,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;point_at(o,(0,0,0))
sc.world.color=(.45,.45,.45);sc.render.engine='CYCLES';sc.cycles.samples=192;sc.cycles.use_denoising=False;sc.render.threads_mode='FIXED';sc.render.threads=4;sc.render.resolution_x=1200;sc.render.resolution_y=1200;sc.render.resolution_percentage=100;sc.view_settings.view_transform='AgX'
# Export only jewelry components. GLB preserves assembly; STL also provided for inspection, not manufacturing.
bpy.ops.object.select_all(action='DESELECT')
for o in model.objects:o.select_set(True)
bpy.context.view_layer.objects.active=next(iter(model.objects));bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'Samiha5_00_3D.glb'),use_selection=True,export_apply=True)
exec(open(os.path.join(OUT,'..','fix_glb_units.py')).read().split("if __name__==")[0]);fix(os.path.join(OUT,'Samiha5_00_3D.glb'))
bpy.ops.wm.stl_export(filepath=os.path.join(OUT,'Samiha5_00_review_mm.stl'),export_selected_objects=True,apply_modifiers=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'Samiha5_00_3D.blend'))
sc.render.filepath=os.path.join(OUT,'Samiha5_00_perspective.png');bpy.ops.render.render(write_still=True)
cam.location=(24,-37,9);point_at(cam,(0,0,0));sc.render.filepath=os.path.join(OUT,'Samiha5_00_low_angle.png');bpy.ops.render.render(write_still=True)
