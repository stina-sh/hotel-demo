Historical analysis from 4 October, supplied separately for learning and explanation. Its illustrations are not the new Samiha8 deliverables and do not replace their final dimensions or QA reports.
