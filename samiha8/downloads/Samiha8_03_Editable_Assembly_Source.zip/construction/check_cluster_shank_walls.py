#!/usr/bin/env python3
"""Independent finite material-wall and readback checks of canonical gallery parts."""
import cadquery as cq,json,argparse,hashlib
from pathlib import Path
from OCP.BRep import BRep_Tool
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
from OCP.TopAbs import TopAbs_IN,TopAbs_ON
from OCP.gp import gp_Lin,gp_Dir,gp_Pnt2d

def check(directory,dense=False,parts=('footplate','skirt')):
 rows=[]
 for name in parts:
  path=directory/(name+'.brep');s=cq.Shape.importBrep(str(path));cl=BRepClass3d_SolidClassifier(s.wrapped);inter=IntCurvesFace_ShapeIntersector();inter.Load(s.wrapped,1e-7)
  def inside(v):cl.Perform(v.toPnt(),1e-7);return cl.State()==TopAbs_IN
  samples=[];reject=[];outside=0;noexit=[];faces=[];trim_boundary_skipped=[]
  for fi,f in enumerate(s.Faces()):
   if name=='sized25_S_ribbon' and fi not in [0,2]:continue
   if name in ['footplate','cap'] and not (fi==0 or f.geomType()=='OFFSET'):continue
   if name=='skirt' and f.geomType() not in ['EXTRUSION','OFFSET']:continue
   u0,u1,v0,v1=f._uvBounds();sf=BRep_Tool.Surface_s(f.wrapped)
   for fu in ([.04,.1,.2,.35,.5,.65,.8,.9,.96] if dense else [.06,.2,.4,.6,.8,.94]):
    for fv in ([.08,.2,.35,.5,.65,.8,.92] if dense else [.1,.5,.9]):
     u=u0+(u1-u0)*fu;v=v0+(v1-v0)*fv
     if BRepClass_FaceClassifier(f.wrapped,gp_Pnt2d(u,v),1e-8).State() not in [TopAbs_IN,TopAbs_ON]:outside+=1;continue
     p=f.positionAt(u,v)
     edge_distance=cq.Vertex.makeVertex(*p.toTuple()).distance(cq.Compound.makeCompound(f.Edges()))
     if edge_distance<1e-4:trim_boundary_skipped.append(dict(face=fi,u=u,v=v,edge_distance_mm=edge_distance));continue
     pp=GeomLProp_SLProps(sf,u,v,1,1e-9)
     if not pp.IsNormalDefined():reject.append(dict(face=fi,reason='normal_undefined'));continue
     nn=pp.Normal();n=cq.Vector(nn.X(),nn.Y(),nn.Z());a,b=inside(p+n*.015),inside(p-n*.015)
     if a==b:reject.append(dict(face=fi,u=u,v=v,reason='both_inside' if a else 'both_outside'));continue
     if b:n=-n
     inter.Perform(gp_Lin(p.toPnt(),gp_Dir(n.x,n.y,n.z)),1e-5,50)
     hits=sorted(inter.WParameter(j) for j in range(1,inter.NbPnt()+1) if inter.WParameter(j)>1e-4);h=None
     for hh in hits:
      if inside(p+n*(hh-1e-5)) and not inside(p+n*(hh+1e-5)):h=hh;break
     if h is None:noexit.append(dict(face=fi,u=u,v=v));continue
     samples.append(dict(face=fi,point_mm=p.toTuple(),inward_normal=n.toTuple(),thickness_mm=h))
   vv=[r['thickness_mm'] for r in samples if r['face']==fi];faces.append(dict(face=fi,surface=f.geomType(),samples=len(vv),minimum_mm=min(vv,default=None),maximum_mm=max(vv,default=None)))
  vals=[r['thickness_mm'] for r in samples];thin=[r for r in samples if r['thickness_mm']<.2-1e-5]
  row=dict(part=name,file=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),valid=s.isValid(),closed_solids=len(s.Solids()),sample_count=len(vals),minimum_mm=min(vals,default=None),maximum_mm=max(vals,default=None),under_nominal_samples=thin,outside_trim_skipped=outside,trim_boundary_samples_excluded=trim_boundary_skipped,xor_rejections=reject,no_exit=noexit,faces=faces)
  (directory/(name+'.wall-samples.json')).write_text(json.dumps(samples,indent=2));rows.append(row);print(name,len(vals),min(vals,default=None),max(vals,default=None),'thin',len(thin),'rejected',len(reject),flush=True)
 report=dict(scope='Finite trim-aware normal material-exit rays on every sampled shank face, including end/rim caps. Long tangential paths through cap transitions are reported separately from nominal normal-offset panels. Not a global minimum-thickness proof.',method='Trim-aware UV sampling; points within 0.0001 mm of trim edges are excluded because a single face normal is not a unique boundary normal there; strict inside/outside XOR at +/-0.015 mm; inward ray to first classified material exit',nominal_wall_mm=.2,numerical_allowance_mm=1e-5,parts=rows,pass_finite_wall_checks=all(r['valid'] and r['closed_solids']==1 and r['sample_count'] and not r['under_nominal_samples'] and not r['no_exit'] and all(f['samples'] for f in r['faces']) for r in rows))
 (directory/'wall-qa.json').write_text(json.dumps(report,indent=2));assert report['pass_finite_wall_checks'];return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('--dense',action='store_true');p.add_argument('--parts',nargs='+',default=['footplate','skirt']);a=p.parse_args();check(a.directory,a.dense,a.parts)
