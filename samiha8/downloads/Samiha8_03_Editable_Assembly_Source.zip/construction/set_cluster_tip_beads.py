"""Set the two supported outer tip grains to the requested25mm complete envelope.
Run after plan_cluster_beads.py and before design3-beads/reflow_bead_junctions.py.
"""
from pathlib import Path
import json,numpy as np
D=Path(__file__).resolve().parent/'design3-beads';p=D/'crown_bead_plan.json';q=json.loads(p.read_text());c=np.array([b['center'] for b in q['beads']]);i=int(np.argmin(c[:,1]));j=int(np.argmax(c[:,1]));mid=(c[i,1]+c[j,1])/2
for k,target in [(i,mid-12),(j,mid+12)]:
 q['beads'][k]['tip_envelope_adjustment_mm']=float(target-c[k,1]);q['beads'][k]['center'][1]=float(target);q['beads'][k]['fixed_envelope_anchor']=True
q['envelope_method']='Two outer tip grains positioned to span exactly25mm including0.5mm sphere radii. Positive native support must verify; no metal scaled.';q['envelope_center_y_mm']=float(mid);p.write_text(json.dumps(q,indent=2))
