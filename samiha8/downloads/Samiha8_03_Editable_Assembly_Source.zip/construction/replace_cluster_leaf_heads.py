import rhino3dm as r,json,math
from pathlib import Path
D=Path(__file__).resolve().parent;src=r.File3dm.Read(str(D/'design3_joined_crown_study.3dm'));out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;plan=json.loads((D/'design3-fluting-plan.json').read_text());poses={s['setting']:s for s in plan['settings']};cap=r.File3dm.Read(str(D/'canonical-heads/leaf_scale1p7/cap.3dm'));n=0
for obj in src.Objects:
 name=obj.Attributes.Name
 if name.startswith('leaf_') and name.endswith('_donor10_61'):
  sid=int(name.split('_')[1]);s=poses[sid];t=r.Transform.Identity()
  for i in range(3):
   for j in range(3):setattr(t,f'M{i}{j}',s['A'][i][j])
   setattr(t,f'M{i}3',s['b'][i])
  g=cap.Objects[0].Geometry.Duplicate();g.Transform(t);name=f'leaf_{sid}_donor61_retained_outer_0p2_hollow_head';n+=1
 else:g=obj.Geometry.Duplicate()
 a=r.ObjectAttributes();a.Name=name;out.Objects.Add(g,a)
assert n==6;assert out.Write(str(D/'design3_qualified_crown.3dm'),7);print('Replaced',n,'qualified0.2 heads')
