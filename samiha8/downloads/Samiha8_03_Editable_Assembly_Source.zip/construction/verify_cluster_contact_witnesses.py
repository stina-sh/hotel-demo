from pathlib import Path
import cadquery as cq,numpy as np,json,itertools,vtk
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN
from OCP.gp import gp_Pnt
D=Path(__file__).resolve().parent;sh=[cq.Shape.importBrep(str(D/f'gallery_contact_shape_{i}.brep')) for i in range(15)];classes=[[BRepClass3d_SolidClassifier(s.wrapped) for s in a.Solids()] for a in sh];pds=[]
for a in sh:
 vv,tt=a.tessellate(.01,.14);points=vtk.vtkPoints();polys=vtk.vtkCellArray()
 for p in vv:points.InsertNextPoint(p.x,p.y,p.z)
 for t in tt:polys.InsertNextCell(3);[polys.InsertCellPoint(int(k)) for k in t]
 pd=vtk.vtkPolyData();pd.SetPoints(points);pd.SetPolys(polys);pds.append(pd)
I=vtk.vtkMatrix4x4();I.Identity()
def inside(i,p):
 for c in classes[i]:
  c.Perform(gp_Pnt(*map(float,p)),1e-7)
  if c.State()==TopAbs_IN:return True
 return False
def both(a,b,p):return inside(a,p) and inside(b,p)
checks=[]
for a,b in [(0,1),(1,2),(0,9),(9,10),(10,11),(1,4),(3,4),(4,5),(5,6),(6,7),(7,8),(3,12),(12,13),(13,14)]:
 coll=vtk.vtkCollisionDetectionFilter();coll.SetInputData(0,pds[a]);coll.SetInputData(1,pds[b]);coll.SetMatrix(0,I);coll.SetMatrix(1,I);coll.SetBoxTolerance(0);coll.SetCellTolerance(0);coll.SetNumberOfCellsPerNode(2);coll.SetCollisionModeToFirstContact();coll.GenerateScalarsOff();coll.Update();contacts=coll.GetContactsOutput();pts=[np.array(contacts.GetPoint(i)) for i in range(contacts.GetNumberOfPoints())];found=None
 for centre in pts+([np.mean(pts,axis=0)] if pts else []):
  for dist in [.01,.02,.04,.07,.10,.15]:
   for v in itertools.product([-1,0,1],repeat=3):
    p=centre+dist*np.array(v)
    if both(a,b,p) and all(both(a,b,p+s*.008*np.eye(3)[axis]) for axis in range(3) for s in [-1,1]):found=p;break
   if found is not None:break
  if found is not None:break
 row={'settings':[a,b],'positive_overlap_witness':found.tolist() if found is not None else None,'six_axis_neighborhood_mm':.008,'preview_contact_points':len(pts)};checks.append(row);print(row,flush=True)
q={'method':'Preview intersections only seed strict native-derived OCP solid classification; centre and six +/-0.008mm axis probes must lie IN both reconstructed gallery compounds. Finite positive-overlap evidence, not globalunion/manufacturingcertificate','all_required_links_positive':all(x['positive_overlap_witness'] is not None for x in checks),'checks':checks};(D/'design3_contact_witnesses.json').write_text(json.dumps(q,indent=2));print('ALL',q['all_required_links_positive'])
