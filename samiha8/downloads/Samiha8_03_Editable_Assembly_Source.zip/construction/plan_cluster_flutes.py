import cadquery as cq,numpy as np,json,math
from pathlib import Path
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN
from OCP.gp import gp_Pnt
D=Path(__file__).resolve().parent;q=json.loads((D/'design3_sized24_metal_study.json').read_text());moves=json.loads((D/'design3_row_join_moves.json').read_text())['setting_translations'];classes={};boxes={}
for i in range(15):
 s=cq.Shape.importBrep(str(D/f'gallery_contact_shape_{i}.brep'));classes[i]=[BRepClass3d_SolidClassifier(x.wrapped) for x in s.Solids()];boxes[i]=s.BoundingBox()
def inside(i,p):
 b=boxes[i]
 if not(b.xmin<=p[0]<=b.xmax and b.ymin<=p[1]<=b.ymax and b.zmin<=p[2]<=b.zmax):return False
 for cl in classes[i]:
  cl.Perform(gp_Pnt(*map(float,p)),1e-7)
  if cl.State()==TopAbs_IN:return True
 return False
settings=[];retained=0;masked=0
for row in q['objects']:
 if row['source_index']!=(66 if row['kind']=='leaf' else 733):continue
 kind=row['kind'];sid=row['setting'];meta=json.loads((D/'canonical-galleries'/f'{kind}_scale1p7/build-qa.json').read_text());ribs=json.loads((D/'fluting-study'/f'{kind}_scale1p7/build-qa.json').read_text());c=meta['frame']['centre'];rh=11+1.7*(math.hypot(c[0],c[2])-11);t=row['turn'];rz=np.array([[math.cos(t),-math.sin(t),0],[math.sin(t),math.cos(t),0],[0,0,1]]);t=row['theta'];ry=np.array([[math.cos(t),0,math.sin(t)],[0,1,0],[-math.sin(t),0,math.cos(t)]]);A=ry@rz;b=ry@(np.array([0,0,row['head_radius']])-rz@np.array([0,0,rh]))+np.array([0,row['translation_y'],0])+np.array(moves.get(str(sid),[0,0,0]));keep=[];omit=[]
 for k,r in enumerate(ribs['records']):
  p=A@np.array([*r['axis_xy_mm'],sum(r['z_limits_mm'])/2])+b;covered=[i for i in range(15) if i!=sid and inside(i,p)]
  if covered:omit.append({'rib':k,'covered_by_settings':covered});masked+=1
  else:keep.append(k);retained+=1
 settings.append({'setting':sid,'kind':kind,'A':A.tolist(),'b':b.tolist(),'retained_ribs':keep,'masked_ribs':omit})
(D/'design3-fluting-plan.json').write_text(json.dumps({'status':'Exposed native0.13mm decorative ribs; neighbour-body interiors masked using exact solid classification; original canonical contact witnesses preserved rigidly','retained':retained,'masked':masked,'settings':settings},indent=2));print('RIBS',retained,'MASKED',masked)
