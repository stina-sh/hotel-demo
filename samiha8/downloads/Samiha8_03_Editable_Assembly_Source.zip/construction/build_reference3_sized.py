"""25-mm-envelope layout study. Keeps donor geometry local; reserves bead extent.
Source gallery offsets remain provisional pending canonical0.2mm replacements.
"""
from pathlib import Path
import rhino3dm as r,numpy as np,math,json
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'rebuild-v3';src=r.File3dm.Read(str(ROOT/'client-donors/10.3dm'));natural=json.loads((D/'design3_natural_dense_trace.json').read_text());records=natural['records'];scale=1.7
ys=[x['y'] for x in records];yc=(max(ys)+min(ys))/2;phase=(min(x['u'] for x in records)+max(x['u'] for x in records))/(2*11.25);parts=[]
def sample(g):
 ps=[]
 for e in g.Edges:
  dom=e.Domain
  for t in np.linspace(dom.T0,dom.T1,33):
   p=e.PointAt(float(t));ps.append([p.X,p.Y,p.Z])
 return np.array(ps)
for k,row in enumerate(records):
 kind=row['kind'];head=750 if kind=='round' else 61;cpoints=sample(src.Objects[head].Geometry);c=(cpoints.min(0)+cpoints.max(0))/2;th=math.atan2(c[0],c[2]);rad=math.hypot(c[0],c[2]);theta=(row['u']/11.25-phase)*1.12;angle=row['angle'];destR=12.65 if kind=='round' else 12.7
 for idx in row['source_indices']:
  g=src.Objects[idx].Geometry.Duplicate();g.Transform(r.Transform.Rotation(-th,r.Vector3d(0,1,0),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,-float(c[1]),-rad))
  if kind=='round' and idx==750:g.Transform(r.Transform.Scale(r.Plane.WorldXY(),1.55,1.55,1/scale));g.Translate(r.Vector3d(0,0,.13/scale))
  g.Transform(r.Transform.Scale(r.Point3d(0,0,0),scale));g.Transform(r.Transform.Rotation(angle,r.Vector3d(0,0,1),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,0,destR));g.Transform(r.Transform.Rotation(theta,r.Vector3d(0,1,0),r.Point3d(0,0,0)));pp=sample(g);parts.append({'geometry':g,'setting':k,'kind':kind,'source_index':idx,'row_y':row['y']-yc,'ymin':float(pp[:,1].min()),'ymax':float(pp[:,1].max()),'theta':theta,'turn':angle,'head_radius':destR,'source_theta':th,'source_y':float(c[1]),'source_head_radius':rad})
def width(a):return max(x['ymax']+a*x['row_y'] for x in parts)-min(x['ymin']+a*x['row_y'] for x in parts)
axial=brentq(lambda a:width(a)-24,0.5,3.5);lo=min(x['ymin']+axial*x['row_y'] for x in parts);hi=max(x['ymax']+axial*x['row_y'] for x in parts);recenter=(lo+hi)/2;out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;rows=[]
for p in parts:
 g=p.pop('geometry');dy=axial*p['row_y']-recenter;g.Translate(r.Vector3d(0,dy,0));a=r.ObjectAttributes();a.Name=f"{p['kind']}_{p['setting']}_donor10_{p['source_index']}";out.Objects.Add(g,a);rows.append({**p,'translation_y':dy,'scale':scale,'native_valid':g.IsValid,'native_closed':g.IsSolid})
p=D/'design3_sized24_metal_study.3dm';assert out.Write(str(p),7);q={'status':'Study only;24mm bare-metal target reserves0.5mm bead extent per side for intended25mm final crown. Final width not yet verified with beads.','natural_source':'design3_natural_dense_trace.json','axial_layout_scale':axial,'axial_recenter':recenter,'ring_phase_radians':phase,'circumferential_spread':1.12,'source_component_scale':scale,'sampled_metal_width_mm':width(axial),'objects':rows,'pending':['canonical0.2mm foot/skirt substitution','head/rim contact checks','1mm beads','final25mm exact envelope','new tapered shank','reference-fidelity acceptance']};(D/'design3_sized24_metal_study.json').write_text(json.dumps(q,indent=2));print('metal study',width(axial),len(out.Objects),'axial',axial)
