import cadquery as cq,numpy as np,math,json
from pathlib import Path
from OCP.BRepAlgoAPI import BRepAlgoAPI_Section
from OCP.gp import gp_Pln,gp_Pnt,gp_Dir
D=Path(__file__).resolve().parent;records=[]
for rail,setting,xs,ys in [(1,8,1,1),(2,14,1,-1),(3,10,-1,1),(4,9,-1,-1)]:
 target=cq.Shape.importBrep(str(D/f'gallery_contact_shape_{setting}.brep'));best=None
 for angle in np.arange(84.5,24,-1):
  a=math.radians(angle);op=BRepAlgoAPI_Section(target.wrapped,gp_Pln(gp_Pnt(0,0,0),gp_Dir(xs*math.cos(a),0,-math.sin(a))),False);op.Build()
  if not op.IsDone():continue
  points=[]
  for e in cq.Shape.cast(op.Shape()).Edges():
   for t in np.linspace(0,1,31):
    p=e.positionAt(float(t))
    if p.x*xs>0 and p.y*ys>0:points.append(p)
  if not points:continue
  yv=[p.y*ys for p in points];radii=[math.hypot(p.x,p.z) for p in points];outer=max(yv);inner=min(yv)
  if outer-inner<.85 or max(radii)-min(radii)<.45:continue
  best={'design':3,'rail':rail,'setting':setting,'sign_x':xs,'sign_y':ys,'head_angle_deg':float(angle),'head_outer_y_abs_mm':outer-.05,'head_width_mm':min(1.2,outer-inner-.1),'target_radial_min_mm':min(radii),'target_radial_max_mm':max(radii),'section_span_mm':outer-inner,'section_count':len(points),'target':f'Canonical_gallery_{setting}'};break
 if best is None:raise RuntimeError(f'No supported section forrail{rail}')
 records.append(best);print(best,flush=True)
(D/'design3-fitted-shoulder-parameters.json').write_text(json.dumps(records,indent=2))
