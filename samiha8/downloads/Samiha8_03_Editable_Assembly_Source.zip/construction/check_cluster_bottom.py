from pathlib import Path
import cadquery as cq,numpy as np,json
from OCP.BRepAlgoAPI import BRepAlgoAPI_Section
from OCP.gp import gp_Pln,gp_Pnt,gp_Dir
D=Path(__file__).resolve().parent;O=D/'design3-shank-final';s=cq.Shape.importBrep(str(O/'lower_band.brep'));op=BRepAlgoAPI_Section(s.wrapped,gp_Pln(gp_Pnt(0,0,0),gp_Dir(1,0,0)),False);op.Build();pts=[]
for e in cq.Shape.cast(op.Shape()).Edges():
 for t in np.linspace(0,1,41):
  p=e.positionAt(float(t))
  if p.z<0:pts.append(p.toTuple())
v=np.array(pts);q={'method':'Native-derived exact CAD section at x=0, restricted to lower half of ring; finite curve samples including endpoints','sample_count':len(v),'bottom_y_min_mm':float(v[:,1].min()),'bottom_y_max_mm':float(v[:,1].max()),'bottom_width_mm':float(np.ptp(v[:,1])),'target_mm':4.,'pass_0p001_mm':bool(abs(np.ptp(v[:,1])-4)<.001)};(O/'bottom-width-qa.json').write_text(json.dumps(q,indent=2));print(q)
