import cadquery as cq,json,math,time
from pathlib import Path
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'rebuild-v3';q=json.loads((D/'design3_sized24_metal_study.json').read_text());sh=[];rows=[]
for row in q['objects']:
 if row['source_index']!=(66 if row['kind']=='leaf' else 733):continue
 base=D/'canonical-galleries'/f"{row['kind']}_scale1p7";meta=json.loads((base/'build-qa.json').read_text());c=meta['frame']['centre'];rh=11+1.7*(math.hypot(c[0],c[2])-11);s=cq.Shape.importBrep(str(base/'gallery.brep')).translate((0,0,-rh)).rotate((0,0,0),(0,0,1),math.degrees(row['turn'])).translate((0,0,row['head_radius'])).rotate((0,0,0),(0,1,0),math.degrees(row['theta'])).translate((0,row['translation_y'],0));sh.append(s);rows.append(row)
links=[];near=[]
for i,a in enumerate(sh):
 for j in range(i+1,len(sh)):
  aa=a.BoundingBox();bb=sh[j].BoundingBox();gap=math.sqrt(sum(max(0,getattr(aa,k+'min')-getattr(bb,k+'max'),getattr(bb,k+'min')-getattr(aa,k+'max'))**2 for k in 'xyz'))
  if gap>1.2:continue
  op=BRepExtrema_DistShapeShape(a.wrapped,sh[j].wrapped);op.Perform();dist=op.Value()
  if dist<1.2:near.append({'a':rows[i]['setting'],'b':rows[j]['setting'],'distance_mm':dist})
  if dist<1e-5:links.append((i,j))
  print(i,j,dist,flush=True)
ccs=[];unseen=set(range(len(sh)))
while unseen:
 cc={unseen.pop()};old=-1
 while old!=len(cc):
  old=len(cc)
  for a,b in links:
   if a in cc or b in cc:cc|={a,b}
 unseen-=cc;ccs.append([rows[k]['setting'] for k in sorted(cc)])
(D/'design3-gallery-distance-qa.json').write_text(json.dumps({'status':'Controlled donor-derived exact-shape distance diagnostic; zero-distance is contact candidate, not positive-overlap proof','near_pairs':near,'contact_candidate_components':ccs},indent=2));print('COMPONENTS',ccs)
