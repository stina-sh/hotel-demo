import cadquery as cq,json,numpy as np,math,rhino3dm as r
from pathlib import Path
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
D=Path(__file__).resolve().parent
ns={'__file__':str(D/'check_cluster_contacts.py')};code=(D/'check_cluster_contacts.py').read_text();exec(compile(code[:code.index('links=[]')],str(D/'check_cluster_contacts.py'),'exec'),ns);sh=ns['sh'];rows=ns['rows'];moves={};records=[]
for group,a,b in [([0,1,2,9,10,11],1,4),([12,13,14],12,3)]:
 op=BRepExtrema_DistShapeShape(sh[a].wrapped,sh[b].wrapped);op.Perform();pa=op.PointOnShape1(1);pb=op.PointOnShape2(1);v=np.array([pb.X()-pa.X(),pb.Y()-pa.Y(),pb.Z()-pa.Z()]);dist=np.linalg.norm(v);delta=v/dist*(dist+.06)
 for i in group:moves[i]=delta.tolist();sh[i]=sh[i].translate(tuple(delta))
 post=BRepExtrema_DistShapeShape(sh[a].wrapped,sh[b].wrapped);post.Perform();records.append({'settings':group,'joining_pair':[a,b],'pre_gap_mm':float(dist),'translation_mm':delta.tolist(),'translation_length_mm':float(np.linalg.norm(delta)),'post_gap_mm':post.Value(),'overlap_status':'Contact candidate only; positive material witnesses pending'});print(records[-1],flush=True)
src=r.File3dm.Read(str(D/'design3_hollow_caps_crown_study.3dm'));out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters
for obj in src.Objects:
 name=obj.Attributes.Name;i=int(name.split('_')[1]);g=obj.Geometry.Duplicate()
 if i in moves:g.Translate(r.Vector3d(*moves[i]))
 at=r.ObjectAttributes();at.Name=name;out.Objects.Add(g,at)
assert out.Write(str(D/'design3_joined_crown_study.3dm'),7);(D/'design3_row_join_moves.json').write_text(json.dumps({'status':'Rigid complete-row compaction; not CAD Boolean union','records':records,'setting_translations':moves},indent=2))
for i,s in enumerate(sh):s.exportBrep(str(D/f'gallery_contact_shape_{i}.brep'))
