import rhino3dm as r,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'rebuild-v3';p=D/'design3_sized24_metal_study.3dm';q=json.loads(p.with_suffix('.json').read_text());src=r.File3dm.Read(str(p));out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;rows=[]
for i,row in enumerate(q['objects']):
 kind=row['kind'];idx=row['source_index']
 if kind=='round' and idx==750:
  base=D/'canonical-galleries/round_cap_scale1p7';qa=json.loads((base/'build-qa.json').read_text());cap=r.File3dm.Read(str(base/'cap.3dm'));c=qa['frame']['centre'];rh=11+1.7*(math.hypot(c[0],c[2])-11)
  for obj in cap.Objects:
   g=obj.Geometry.Duplicate();g.Translate(r.Vector3d(0,0,-rh));g.Transform(r.Transform.Rotation(row['turn'],r.Vector3d(0,0,1),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,0,row['head_radius']));g.Transform(r.Transform.Rotation(row['theta'],r.Vector3d(0,1,0),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,row['translation_y'],0));a=r.ObjectAttributes();a.Name=f"round_{row['setting']}_canonical_0p2_cap";out.Objects.Add(g,a)
  continue
 if idx!=(66 if kind=='leaf' else 733):
  a=r.ObjectAttributes();a.Name=src.Objects[i].Attributes.Name;out.Objects.Add(src.Objects[i].Geometry.Duplicate(),a);continue
 base=D/'canonical-galleries'/f'{kind}_scale1p7';qa=json.loads((base/'build-qa.json').read_text());canonical=r.File3dm.Read(str(base/'gallery.3dm'));c=qa['frame']['centre'];rh=11+1.7*(math.hypot(c[0],c[2])-11)
 for obj in canonical.Objects:
  g=obj.Geometry.Duplicate();g.Translate(r.Vector3d(0,0,-rh));g.Transform(r.Transform.Rotation(row['turn'],r.Vector3d(0,0,1),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,0,row['head_radius']));g.Transform(r.Transform.Rotation(row['theta'],r.Vector3d(0,1,0),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,row['translation_y'],0));a=r.ObjectAttributes();a.Name=f"{kind}_{row['setting']}_canonical_{obj.Attributes.Name}";out.Objects.Add(g,a)
 rows.append({'setting':row['setting'],'kind':kind,'canonical_directory':str(base),'placement':row,'parts':len(canonical.Objects),'nominal_normal_wall_mm':.2})
assert out.Write(str(D/'design3_hollow_caps_crown_study.3dm'),7);re=r.File3dm.Read(str(D/'design3_hollow_caps_crown_study.3dm'));assert all(o.Geometry.IsValid and o.Geometry.IsSolid for o in re.Objects)
(D/'design3_hollow_caps_crown_study.json').write_text(json.dumps({'status':'Study only; native hollow gallery substitution complete, assembly contacts/beads/shank/visual acceptance pending','source_study':q,'native_breps':len(re.Objects),'canonical_gallery_placements':rows},indent=2));print('native hollow crown',len(re.Objects))
