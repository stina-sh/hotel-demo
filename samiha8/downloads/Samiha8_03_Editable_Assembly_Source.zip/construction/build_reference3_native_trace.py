"""Natural-scale image-layout study using complete original native settings.
Camera/assumed cylinder are approximate. No engineering release approval.
"""
import rhino3dm as r,numpy as np,math,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'rebuild-v3';src=r.File3dm.Read(str(ROOT/'client-donors/10.3dm'));cam=json.loads((D/'reference3_bore_camera.json').read_text());rr=np.array(cam['right']);up=np.array(cam['up']);dd=np.array(cam['direction']);sc=cam['parameters'][3];tx,ty=cam['parameters'][4:6]
rounds=[[226,178],[297,174],[373,173],[229,233],[304,227],[380,237],[444,271],[501,324],[535,392]]
leaves=[([162,185],[[152,197],[177,175]]),([221,139],[[190,151],[250,124]]),([334,122],[[291,127],[374,112]]),([264,281],[[225,291],[303,270]]),([382,310],[[343,292],[421,328]]),([476,381],[[451,348],[493,411]])]
def points(g):
 a=[]
 for e in g.Edges:
  d=e.Domain
  for t in np.linspace(d.T0,d.T1,33):
   p=e.PointAt(float(t));a.append([p.X,p.Y,p.Z])
 return np.array(a)
def unproject(xy,rad):
 p=(xy[0]-tx)/sc*rr-(xy[1]-ty)/sc*up;a=dd[0]**2+dd[2]**2;b=2*(p[0]*dd[0]+p[2]*dd[2]);c=p[0]**2+p[2]**2-rad**2;disc=b*b-4*a*c
 if disc<0:raise ValueError('Landmark outside assumed cylinder')
 return p+(-b+math.sqrt(disc))/(2*a)*dd
out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;records=[]
for kind,xy,ends in [('round',q,None) for q in rounds]+[('leaf',q,a) for q,a in leaves]:
 ids=[733,750,751,752,753,754] if kind=='round' else [61,62,63,64,65,66];head=750 if kind=='round' else 61;size=1.0 if kind=='round' else 1.3
 hp=points(src.Objects[head].Geometry);c=(hp.min(0)+hp.max(0))/2;th=math.atan2(c[0],c[2]);radius=11+size*(math.hypot(c[0],c[2])-11)+(.035 if kind=='round' else 0);target=unproject(xy,radius);tu=math.atan2(target[0],target[2]);tyy=float(target[1])
 ry=np.array([[math.cos(-th),0,math.sin(-th)],[0,1,0],[-math.sin(-th),0,math.cos(-th)]]);flat=hp@ry.T;xypts=flat[:,:2]-flat[:,:2].mean(0);va,ve=np.linalg.eigh(xypts.T@xypts);sourceang=math.atan2(ve[1,-1],ve[0,-1]) if kind=='leaf' else 0
 if ends:
  a,b=[unproject(v,radius) for v in ends];da=math.atan2(b[0],b[2])-math.atan2(a[0],a[2]);targetang=math.atan2(b[1]-a[1],da*11.25)
 else:targetang=0
 angle=targetang-sourceang;idx=len(records);object_ids=[]
 for sourceid in ids:
  g=src.Objects[sourceid].Geometry.Duplicate();g.Transform(r.Transform.Rotation(-th,r.Vector3d(0,1,0),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,-float(c[1]),0))
  if kind=='round' and sourceid==750:
   plane=r.Plane(r.Point3d(0,0,math.hypot(c[0],c[2])),r.Vector3d(0,0,1));g.Transform(r.Transform.Scale(plane,1.55,1.55,1));g.Translate(r.Vector3d(0,0,.035))
  g.Transform(r.Transform.Scale(r.Point3d(0,0,11),size));g.Transform(r.Transform.Rotation(angle,r.Vector3d(0,0,1),r.Point3d(0,0,0)));g.Transform(r.Transform.Rotation(tu,r.Vector3d(0,1,0),r.Point3d(0,0,0)));g.Translate(r.Vector3d(0,tyy,0));a=r.ObjectAttributes();a.Name=f'{kind}_{idx}_source10_{sourceid}';out.Objects.Add(g,a);object_ids.append(len(out.Objects)-1)
 records.append({'kind':kind,'head_pixel':xy,'axis_pixels':ends,'source_indices':ids,'local_scale':size,'u':tu*11.25,'y':tyy,'angle':angle,'source_polar_angle':th,'source_y':float(c[1]),'object_ids':object_ids,'pending':['gallery-skirt construction','contact and hollow-wall restoration','25mm sizing','shank fitting']})
band=r.File3dm.Read(str(ROOT/'final/design_3/model.3dm'));a=r.ObjectAttributes();a.Name='Measured_EU62_lower_band_REFERENCE_ONLY';out.Objects.Add(band.Objects[265].Geometry.Duplicate(),a)
p=D/'design3_natural_trace.3dm';assert out.Write(str(p),7);(D/'design3_natural_trace.json').write_text(json.dumps({'status':'Natural-scale native-donor visual study, not release CAD','camera':cam,'records':records},indent=2));print(len(out.Objects),'natural head axial span',max(x['y'] for x in records)-min(x['y'] for x in records))
