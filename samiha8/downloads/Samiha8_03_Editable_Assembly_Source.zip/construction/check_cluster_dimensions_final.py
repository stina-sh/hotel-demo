import cadquery as cq,numpy as np,json,math
from pathlib import Path
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.TopAbs import TopAbs_IN,TopAbs_ON
from OCP.gp import gp_Pnt2d
D=Path(__file__).resolve().parent;O=D/'design3-shank-final';R=62/(2*math.pi);rows=[]
for name in ['branch_1','branch_2','branch_3','branch_4','lower_band']:
 p=O/(name+'.brep')
 if not p.exists():continue
 s=cq.Shape.importBrep(str(p));pts=[]
 for f in s.Faces():
  u0,u1,v0,v1=f._uvBounds()
  for fu in np.linspace(.001,.999,41):
   for fv in np.linspace(.001,.999,11):
    u=u0+fu*(u1-u0);v=v0+fv*(v1-v0)
    if BRepClass_FaceClassifier(f.wrapped,gp_Pnt2d(u,v),1e-8).State() not in [TopAbs_IN,TopAbs_ON]:continue
    pts.append(f.positionAt(float(u),float(v)).toTuple())
 pts=np.array(pts);r=np.linalg.norm(pts[:,[0,2]],axis=1);rows.append({'part':name,'trimmed_surface_samples':len(pts),'minimum_radial_distance_mm':float(r.min()),'bore_margin_mm':float(r.min()-R)})
q={'EU_size':62,'bore_diameter_target_mm':2*R,'scope':'Finite trim-aware surface witnesses, not global extremum proof','shank':rows,'pass_bore_clearance_0p001_mm':all(r['bore_margin_mm']>=-.001 for r in rows)};(O/'dimension-qa.json').write_text(json.dumps(q,indent=2));print(q)
