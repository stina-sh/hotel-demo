from pathlib import Path
import cadquery as cq,numpy as np,json,math
from scipy.interpolate import CubicSpline
from OCP.BRep import BRep_Tool
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge
from OCP.BRepProj import BRepProj_Projection
from OCP.gp import gp_Pnt,gp_Dir
D=Path(__file__).resolve().parent;O=D/'design3-beads';O.mkdir(exist_ok=True)
leaf=json.loads((D/'design2-worker/complete-v1/canonical_bead_plan.json').read_text());base=D/'canonical-galleries/round_scale1p7';top=cq.Shape.importBrep(str(base/'retained_top.brep')).Faces()[0];edges=[]
for e in top.outerWire().Edges():
 c=BRep_Tool.Curve_s(e.wrapped,0.,0.).Copy()
 for i in range(1,c.NbPoles()+1):p=c.Pole(i);c.SetPole(i,gp_Pnt(p.X(),p.Y(),0))
 a,b=BRep_Tool.Range_s(e.wrapped);ee=BRepBuilderAPI_MakeEdge(c,a,b).Edge();ee.Orientation(e.wrapped.Orientation());edges.append(cq.Edge(ee))
flat=cq.Wire.assembleEdges(edges);rail2d=flat.offset2D(-.28,'intersection')[0];proj=BRepProj_Projection(rail2d.wrapped,top.wrapped,gp_Dir(0,0,1));rail=cq.Wire(proj.Current());rr=[];total=0
for e in rail.Edges():
 L=e.Length()
 for t in np.linspace(0,1,601,endpoint=False):rr.append([total+t*L,*e.positionAt(float(t)).toTuple()])
 total+=L
rr.append([total,*rr[0][1:]]);rr=np.array(rr);f=CubicSpline(rr[:,0],rr[:,1:],bc_type='periodic')
for n in range(int(total),5,-1):
 ss=np.arange(n)*total/n;pp=f(ss);pp[:,2]+=.32;dist=np.linalg.norm(pp[:,None]-pp[None,:],axis=2);np.fill_diagonal(dist,1e9)
 if dist.min()>1.015:break
rnd={'canonical_centers':pp.tolist(),'arc_parameters_mm':ss.tolist(),'min_center_distance_mm':float(dist.min()),'beads':n};(O/'round_canonical_bead_plan.json').write_text(json.dumps(rnd,indent=2))
q=json.loads((D/'design3_sized24_metal_study.json').read_text());moves=json.loads((D/'design3_row_join_moves.json').read_text())['setting_translations'];out=[]
for row in q['objects']:
 if row['source_index']!=(66 if row['kind']=='leaf' else 733):continue
 kind=row['kind'];setting=row['setting'];pts=np.array((leaf if kind=='leaf' else rnd)['canonical_centers']);meta=json.loads((D/'canonical-galleries'/f'{kind}_scale1p7/build-qa.json').read_text());c=meta['frame']['centre'];rh=11+1.7*(math.hypot(c[0],c[2])-11);pts[:,2]-=rh;t=row['turn'];rz=np.array([[math.cos(t),-math.sin(t),0],[math.sin(t),math.cos(t),0],[0,0,1]]);pts=pts@rz.T;pts[:,2]+=row['head_radius'];t=row['theta'];ry=np.array([[math.cos(t),0,math.sin(t)],[0,1,0],[-math.sin(t),0,math.cos(t)]]);pts=pts@ry.T;pts[:,1]+=row['translation_y'];pts+=np.array(moves.get(str(setting),[0,0,0]))
 for i,p in enumerate(pts):out.append({'center':p.tolist(),'members':[{'setting':setting,'kind':kind,'bead':i}],'kind':'gallery'})
shared=[]
while True:
 best=None
 for i,a in enumerate(out):
  for j in range(i+1,len(out)):
   b=out[j]
   if {m['setting'] for m in a['members']}=={m['setting'] for m in b['members']}:continue
   distance=np.linalg.norm(np.array(a['center'])-b['center'])
   if distance>=.999:continue
   old=a.get('original_centers',[a['center']])+b.get('original_centers',[b['center']]);p=np.mean(old,axis=0)
   if max(np.linalg.norm(p-v) for v in old)>.465:continue
   if best is None or distance<best[0]:best=distance,i,j,p,old
 if best is None:break
 _,i,j,p,old=best;new={'center':p.tolist(),'members':out[i]['members']+out[j]['members'],'original_centers':old,'kind':'shared_junction'};shared.append(new);out[i]=new;del out[j]
pts=np.array([b['center'] for b in out]);qq={'beads':out,'shared_junction_replacements':shared,'bead_diameter_mm':1.,'status':'Candidate requiring bounded reflow, support and envelope QA','sphere_axial_bounds_mm':[pts[:,1].min()-.5,pts[:,1].max()+.5]};(O/'crown_bead_plan.json').write_text(json.dumps(qq,indent=2));print(len(out),len(shared),qq['sphere_axial_bounds_mm'])
