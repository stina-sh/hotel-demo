import cadquery as cq,numpy as np,math,json,time
from pathlib import Path
from scipy.interpolate import CubicHermiteSpline
from concurrent.futures import ProcessPoolExecutor
D=Path(__file__).resolve().parent;ROOT=D.parent;ns={'__file__':str(ROOT/'source/build_tapered_shank.py')};code=(ROOT/'source/build_tapered_shank.py').read_text();exec(code[:code.index("ROOT.joinpath('final')")],ns);halfwidth=ns['halfwidth'];radius=ns['radius'];RIN=62/(2*math.pi);BASE=110.;OUT=D/'design3-shank-final';OUT.mkdir(exist_ok=True)
def derivative(f,x):return (f(x+.001)-f(x-.001))/.002
def point(a,y,r,xs=1):t=math.radians(a);return cq.Vector(xs*r*math.sin(t),y,r*math.cos(t))
def rectangle(a,lo,hi,r,xs=1,ri=RIN):
 p=[point(a,lo,ri,xs),point(a,hi,ri,xs),point(a,hi,r,xs),point(a,lo,r,xs)];return cq.Wire.makePolygon(p+[p[0]])
def boundary(head,hv,bv,end_derivative):
 hh=halfwidth(head);hb=halfwidth(BASE)
 def raw(a):return bv+(hv-bv)*(halfwidth(a)-hb)/(hh-hb)
 lead=head+min(8,(BASE-head)/3);tail=BASE-min(8,(BASE-head)/3)
 begin=CubicHermiteSpline([head,lead],[hv,raw(lead)],[0,derivative(raw,lead)]);end=CubicHermiteSpline([tail,BASE],[raw(tail),bv],[derivative(raw,tail),end_derivative])
 return lambda a:float(begin(a) if a<lead else end(a) if a>tail else raw(a))
def branch(rec):
 k=rec['rail'];path=OUT/f'branch_{k}.brep'
 cached=path.exists() and cq.Shape.importBrep(str(path)).isValid()
 head=rec['head_angle_deg'];ys=rec['sign_y'];xs=rec['sign_x'];outer=ys*rec['head_outer_y_abs_mm'];inner=outer-ys*rec['head_width_mm'];wo=boundary(head,outer,ys*halfwidth(BASE),ys*derivative(halfwidth,BASE));wi=boundary(head,inner,0,0);delta=max(0,rec['target_radial_min_mm']+.3-radius(head))
 def rawr(a):
  t=np.clip((a-head)/(BASE-head),0,1);return radius(a)+delta*(1-3*t*t+2*t*t*t)
 lead=head+min(8,(BASE-head)/3);leadR=CubicHermiteSpline([head,lead],[rawr(head),rawr(lead)],[0,derivative(rawr,lead)])
 def rr(a):return float(leadR(a) if a<lead else rawr(a))
 inner_head=max(RIN,rec['target_radial_min_mm']-.18);inner_end=head+min(13,(BASE-head)*.65);inner_curve=CubicHermiteSpline([head,inner_end],[inner_head,RIN],[0,0])
 stations=[];wires=[]
 for a in np.linspace(head,BASE+.5,31):
  if a>BASE:oo=ys*halfwidth(a);ii=0
  else:oo=wo(a);ii=wi(a)
  lo,hi=sorted([oo,ii]);r=rr(a);assert hi-lo>.7;tt=float(np.clip((a-head)/(inner_end-head),0,1));ri=RIN+.0006+(inner_head-RIN-.0006)*(1-10*tt**3+15*tt**4-6*tt**5);wires.append(rectangle(a,lo,hi,r,xs,ri));stations.append([float(a),lo,hi,r,ri])
 outerSolid=cq.Solid.makeLoft(wires,False).fix();assert outerSolid.isValid();caps=[f for f in outerSolid.Faces() if f.geomType()=='PLANE'];base=min(caps,key=lambda f:f.Center().z);start=time.time();s=cq.Shape.importBrep(str(path)) if cached else outerSolid.shell([base],-.2,tolerance=1e-5,kind='intersection').fix();assert s.isValid();assert s.Volume()<outerSolid.Volume()*.98,'Shell silently retained filled outer solid';s.exportBrep(str(path));rrs=cq.Shape.importBrep(str(path)).fix();rrs.exportBrep(str(path));assert cq.Shape.importBrep(str(path)).isValid();q={'rail':k,'source_target':rec,'normal_wall_offset_mm':.2,'head_closed_base_open':True,'lower_join_angle_deg':BASE,'C1_flat_head':True,'inner_transition':'C2 quintic endpoint blend','pre_hollowing_inner_construction_clearance_mm':.0006,'inner_head_lift_mm':inner_head-RIN,'inner_lift_end_angle_deg':inner_end,'stations':stations,'build_seconds':time.time()-start,'outer_volume_mm3':outerSolid.Volume(),'hollow_material_volume_mm3':s.Volume(),'outer_faces':len(outerSolid.Faces()),'hollow_faces':len(s.Faces())};path.with_suffix('.json').write_text(json.dumps(q,indent=2));print('BRANCH',k,q['build_seconds'],flush=True);return q
if __name__=='__main__':
 params=json.loads((D/'design3-fitted-shoulder-parameters.json').read_text())
 with ProcessPoolExecutor(max_workers=2) as pool:results=list(pool.map(branch,params))
 p=OUT/'lower_band.brep'
 if not p.exists():
  ts=np.unique(np.r_[np.linspace(BASE-.5,180,27),180,360-np.linspace(BASE-.5,180,27)]);o=cq.Solid.makeLoft([rectangle(a,-halfwidth(a),halfwidth(a),radius(a)) for a in ts],False).fix();caps=[f for f in o.Faces() if f.geomType()=='PLANE'];s=o.shell(caps,-.2,tolerance=1e-5,kind='intersection').fix();assert s.isValid();s.exportBrep(str(p));print('LOWER',s.isValid(),flush=True)
 parts=[cq.Shape.importBrep(str(p))]+[cq.Shape.importBrep(str(OUT/f'branch_{i}.brep')) for i in range(1,5)];cq.Compound.makeCompound(parts).exportBrep(str(OUT/'shank.brep'));(OUT/'construction.json').write_text(json.dumps({'normal_wall_mm':.2,'EU62_radius':RIN,'bottom_width_mm':4,'lower_start_deg':BASE-.5,'source_profile':'client07 faces73/72 adapted to actual crown sections, with derivative-matched lower joins','branches':results},indent=2));print('DONE')
