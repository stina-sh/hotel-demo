from pathlib import Path
import rhino3dm as r,json,math
D=Path(__file__).resolve().parent;o=r.File3dm();o.Settings.ModelUnitSystem=r.UnitSystem.Millimeters
layers={}
for name,color in [('Native donor heads and hollow galleries',(184,184,190,255)),('Fitted hollow shank',(150,150,157,255)),('One millimetre beads',(214,193,145,255)),('Decorative fluting',(185,166,127,255))]:
 l=r.Layer();l.Name=name;l.Color=color;layers[name]=o.Layers.Add(l)
for p,l in [(D/'design3_qualified_crown.3dm',0),(D/'design3-shank-final/shank.3dm',1)]:
 f=r.File3dm.Read(str(p))
 for x in f.Objects:
  a=r.ObjectAttributes();a.Name=x.Attributes.Name or 'Fitted_hollow_shank';a.LayerIndex=l;o.Objects.Add(x.Geometry.Duplicate(),a)
beads=json.loads((D/'design3-beads/crown_bead_plan_reflowed.json').read_text());support=json.loads((D/'design3-beads/reflowed_bead_support_qa.json').read_text());assert support['accepted']==len(beads['beads'])
for i,b in enumerate(beads['beads']):
 g=r.Sphere(r.Point3d(*b['center']),.5).ToBrep();a=r.ObjectAttributes();a.Name=f'Bead_1mm_{i:03d}';a.LayerIndex=2;o.Objects.Add(g,a)
plan=json.loads((D/'design3-fluting-plan.json').read_text())
for s in plan['settings']:
 f=r.File3dm.Read(str(D/'fluting-study'/f"{s['kind']}_scale1p7/ribs.3dm"));t=r.Transform.Identity()
 for i in range(3):
  for j in range(3):setattr(t,f'M{i}{j}',s['A'][i][j])
  setattr(t,f'M{i}3',s['b'][i])
 for i in s['retained_ribs']:
  g=f.Objects[i].Geometry.Duplicate();g.Transform(t);a=r.ObjectAttributes();a.Name=f"Setting_{s['setting']}_flute_{i}";a.LayerIndex=3;o.Objects.Add(g,a)
p=D/'design3_final_review.3dm';assert o.Write(str(p),7);re=r.File3dm.Read(str(p));assert all(x.Geometry.IsValid and x.Geometry.IsSolid for x in re.Objects);q={'file':str(p),'native_valid_closed_breps':len(re.Objects),'beads_1mm':len(beads['beads']),'flutes':plan['retained'],'full_top_sphere_envelope_mm':beads['sphere_axial_bounds_mm'],'width_mm':beads['sphere_axial_bounds_mm'][1]-beads['sphere_axial_bounds_mm'][0],'status':'Native assembly regenerated; use published QA only after matching verified delivery geometry'};(D/'design3_final_review.json').write_text(json.dumps(q,indent=2));print(q)
