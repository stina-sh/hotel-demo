Samiha8 design 4: Three Ribbons

Extract Samiha8_04_Three_Ribbons_25mm_EU62.3dm, then open that native Rhino 7 millimetre file in your CAD application. The ZIP changes no geometry.
Native SHA-256: 3d71c1d3be12e203d38f22a9a692b75641133cb9d87a154ffe46f7b8daf58ac4

Editable, separate contacting BREP solids. See the catalog review notes for dimensions and finite checks. No MatrixGold runtime or manufacturing certification is claimed.
