Samiha8 Design 4 — editable native source

This package assembles only qualified final native components. Raw client donor files and rejected studies are not included.

Requirements: Python 3 and rhino3dm 8.35.0 for the recorded exact-geometry comparison. Nothing is installed or downloaded by the script.

Run: python assemble.py
The output is a Rhino 7 file and replay-qa.json. All 702 object geometry hashes are checked against the verified model. File timestamps, object IDs and metadata may differ; geometry must match.

Edit the native crown or shank components in Rhino. Bead centers, diameters, actual-rim station provenance and shared junction mappings are in plans/beads.json. The final bead centers are authoritative. Fluting uses qualified native capsule modules and explicit rigid placements in plans/flutes.json; the canonical rim station and capsule dimensions are included. Edit these plans or modules to make intentional changes. The stored geometry comparison will flag any deliberate change until it is reviewed and the expected fingerprints are updated.

Hollow channel openings are intentional. The assembly consists of separate closed solids with positive contact evidence; it is not globally Boolean fused. No manufacturing or Matrix runtime certification is claimed.
