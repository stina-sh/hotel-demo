"""Assemble the qualified native components and explicit editable layout plans.
Requires Python3 and rhino3dm8.35.0 for the recorded exact-geometry hash check.
No network access or external donor files are used.
"""
from pathlib import Path
import argparse,json,hashlib,math
import rhino3dm as r
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args();plan=json.load(open(ROOT/'assembly.json'));out=a.output or ROOT/plan['output'];out.parent.mkdir(parents=True,exist_ok=True);m=r.File3dm();m.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;m.Settings.ModelAbsoluteTolerance=plan['absolute_tolerance_mm'];layers={}
def layer(name):
 if name not in layers:l=r.Layer();l.Name=name;layers[name]=m.Layers.Add(l)
 return layers[name]
def add(g,name,lay):
 assert isinstance(g,r.Brep) and g.IsValid and g.IsSolid
 at=r.ObjectAttributes();at.Name=name;at.LayerIndex=layer(lay);at.SetUserString('source','Qualified final component and explicit layout plan');m.Objects.Add(g,at)
for relative in plan['fixed_components']:
 f=r.File3dm.Read(str(ROOT/relative));assert f
 for o in f.Objects:add(o.Geometry,o.Attributes.Name,f.Layers[o.Attributes.LayerIndex].Name)
flutes=json.load(open(ROOT/'plans/flutes.json'));flute_count=0
for pose in flutes['placements']:
 A,b=pose['matrix'],pose['translation_mm'];assert max(abs(sum(A[k][i]*A[k][j] for k in range(3))-(1 if i==j else 0)) for i in range(3) for j in range(3))<1e-10
 t=r.Transform.Identity()
 for i in range(3):
  for j in range(3):setattr(t,f'M{i}{j}',A[i][j])
  setattr(t,f'M{i}3',b[i])
 f=r.File3dm.Read(str(ROOT/pose['module']))
 for i,o in enumerate(f.Objects):g=o.Geometry.Duplicate();assert g.Transform(t);add(g,pose['name_prefix']+f'{i:02d}',plan['fluting_layer']);flute_count+=1
beads=json.load(open(ROOT/'plans/beads.json'))
for q in beads['beads']:
 assert q['diameter_mm']==1.;s=r.Sphere(r.Point3d(*q['center_mm']),q['diameter_mm']/2);add(s.ToBrep(),f'Border_bead_{q["index"]:03d}_diameter1mm',plan['bead_layer'])
assert len(m.Objects)==plan['expected_objects'] and m.Write(str(out),7);re=r.File3dm.Read(str(out));actual={o.Attributes.Name:hashlib.sha256(json.dumps(o.Geometry.Encode(),sort_keys=True).encode()).hexdigest() for o in re.Objects};expected=json.load(open(ROOT/'expected_geometry.json'))['objects'];diff=[k for k in sorted(set(actual)|set(expected)) if actual.get(k)!=expected.get(k)];report={'objects':len(re.Objects),'all_valid_closed_native_Breps':all(isinstance(o.Geometry,r.Brep) and o.Geometry.IsValid and o.Geometry.IsSolid for o in re.Objects),'mesh_objects':0,'beads':len(beads['beads']),'flutes':flute_count,'exact_native_geometry_hash_comparison_pass':not diff,'geometry_mismatches':diff,'reference_comparison_scope':'Geometry only, keyed by stable object names. File timestamps, object IDs and file metadata may differ.','output_file':out.name,'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest()};(out.parent/'replay-qa.json').write_text(json.dumps(report,indent=2));assert report['all_valid_closed_native_Breps'] and not diff,report;print(json.dumps(report),flush=True)
