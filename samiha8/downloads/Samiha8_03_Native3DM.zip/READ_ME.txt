Samiha8 design 3: Cluster

Extract Samiha8_03_Cluster_25mm_EU62.3dm, then open that native Rhino 7 millimetre file in your CAD application. The ZIP changes no geometry.
Native SHA-256: e37b9c394f41091271117f6b9e333c5f29ea9231ee423215fdd43b85b8af2df8

Editable, separate contacting BREP solids. See the catalog review notes for dimensions and finite checks. No MatrixGold runtime or manufacturing certification is claimed.
