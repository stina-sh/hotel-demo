from pathlib import Path
import json,numpy as np,cadquery as cq
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
D=Path(__file__).resolve().parent
exec((D/'check_head_clearances.py').read_text().split('results=[]')[0])
path=D/'crown_bead_plan_reflowed.json';plan=json.loads(path.read_text());(D/'crown_bead_plan_before_head_masks.json').write_text(json.dumps(plan,indent=2));occlusion=json.load(open(D/'head_occlusion_classification.json'))['rows'];labels={(r['field'],r['setting']):i for i,r in enumerate(q['objects'])};hidden={r['bead'] for r in occlusion if r['radial_projection_occluded']};exposed={r['bead'] for r in occlusion if not r['radial_projection_occluded']}-hidden;adjustments=[]
def clearance(point,hi):
 op=BRepExtrema_DistShapeShape(cq.Vertex.makeVertex(*point).wrapped,heads[hi].wrapped);op.Perform();return op.Value()
for i in sorted(exposed):
 targets=[labels[tuple(r['head'])] for r in occlusion if r['bead']==i];point=np.array(plan['beads'][i]['center']);n=point*np.array([1,0,1]);n/=np.linalg.norm(n)
 def dist(depth):return min(clearance(point-n*depth,hi) for hi in targets)
 lo=0.;hi=.65
 if dist(hi)<.51:raise RuntimeError('Visible bead cannot clear head within allowed radial repositioning')
 for _ in range(25):
  mid=(lo+hi)/2
  if dist(mid)<.51:lo=mid
  else:hi=mid
 new=point-n*hi;plan['beads'][i]['center']=new.tolist();plan['beads'][i]['radial_drop_for_exposed_head_clearance_mm']=hi;adjustments.append({'old_bead_index':i,'radial_drop_mm':hi,'new_head_clearance_mm':dist(hi),'reason':'Exposed rim bead retained at true1mm diameter, seated lower to clear neighboring cap'});print('LOWER',i,hi,dist(hi),flush=True)
masked=[];out=[]
for i,b in enumerate(plan['beads']):
 if i in hidden:
  masked.append({'old_bead_index':i,'members':b['members'],'center':b['center'],'reason':'Covered rim arc beneath neighboring native head; exact outward radial ray intersects cap','head_evidence':[r for r in occlusion if r['bead']==i]})
 else:b['original_final_bead_index']=i;out.append(b)
plan['beads']=out;plan['head_occlusion_masks']=masked;plan['visible_bead_head_clearance_adjustments']=adjustments;plan['status']='Visible rim cadences with explicit polished-S and covered-head arc masks; all retained beads must pass final support and clearance replay';points=np.array([b['center'] for b in out]);matrix=np.linalg.norm(points[:,None]-points[None,:],axis=2);np.fill_diagonal(matrix,1e9);plan['final_minimum_sphere_center_distance_mm']=float(matrix.min());plan['sphere_axial_bounds_mm']=[float(points[:,1].min()-.5),float(points[:,1].max()+.5)];plan['final_bead_count']=len(out);path.write_text(json.dumps(plan,indent=2));print('MASKED',len(masked),'FINAL',len(out),'MINDIST',matrix.min());assert matrix.min()>=1.0
