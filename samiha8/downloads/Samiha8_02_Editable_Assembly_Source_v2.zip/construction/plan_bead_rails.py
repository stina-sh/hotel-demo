import cadquery as cq,numpy as np,json,math
from pathlib import Path
from scipy.interpolate import CubicSpline
from OCP.BRep import BRep_Tool
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge
from OCP.BRepProj import BRepProj_Projection
from OCP.gp import gp_Pnt,gp_Dir
D=Path(__file__).resolve().parent;P=D.parent;C=P.parent/'canonical-galleries/leaf_scale1p7';top=cq.Shape.importBrep(str(C/'retained_top.brep')).Faces()[0]
edges=[]
for e in top.outerWire().Edges():
 c=BRep_Tool.Curve_s(e.wrapped,0.,0.).Copy()
 for i in range(1,c.NbPoles()+1):p=c.Pole(i);c.SetPole(i,gp_Pnt(p.X(),p.Y(),0))
 a,b=BRep_Tool.Range_s(e.wrapped);ee=BRepBuilderAPI_MakeEdge(c,a,b).Edge();ee.Orientation(e.wrapped.Orientation());edges.append(cq.Edge(ee))
flat=cq.Wire.assembleEdges(edges);inset=flat.offset2D(-.28,'intersection');assert len(inset)==1
projection=BRepProj_Projection(inset[0].wrapped,top.wrapped,gp_Dir(0,0,1));assert projection.IsDone();rail=cq.Wire(projection.Current());rail.exportBrep(str(D/'canonical_bead_rail.brep'))
# Arc-length parameterization of the full closed rail, including its sharp tips.
rr=[];total=0.;edgeends=[0.]
for e in rail.Edges():
 length=e.Length()
 for s in np.linspace(0,length,601,endpoint=False):rr.append([total+s,*e.positionAt(float(s/length)).toTuple()])
 total+=length;edgeends.append(total)
rail_edges=rail.Edges();turns=[]
for i,e in enumerate(rail_edges):
 prev=rail_edges[i-1].tangentAt(1);nxt=e.tangentAt(0);turns.append((math.acos(np.clip(prev.dot(nxt),-1,1)),edgeends[i]))
tips=sorted(x[1] for x in sorted(turns,reverse=True)[:2]);edgeends=tips+[total+tips[0]]
rr.append([total,*rr[0][1:]]);rr=np.array(rr);interp=CubicSpline(rr[:,0],rr[:,1:],bc_type='periodic');candidates=[]
for divisions in range(12,5,-1):
 # Fixed bead at each tip; equal arc subdivisions on each half rim.
 a,b=edgeends[0:2];l1=b-a;l2=total-l1;ss=np.r_[a+np.arange(divisions)/divisions*l1,b+np.arange(divisions)/divisions*l2]%total;points=interp(ss);points[:,2]+=.32
 distances=np.linalg.norm(points[:,None]-points[None,:],axis=2);np.fill_diagonal(distances,1e9);mind=float(distances.min());candidates.append({'subdivisions_per_half':divisions,'beads':len(ss),'min_center_distance_mm':mind})
 if mind>=1.015:
  selected={'subdivisions_per_half':divisions,'beads':len(ss),'min_center_distance_mm':mind,'canonical_centers':points.tolist(),'arc_parameters_mm':ss.tolist(),'length_mm':total,'tip_arc_parameters_mm':edgeends,'radius_mm':.5,'rail_inset_xy_mm':.28,'height_above_gallery_top_z_mm':.32};break
else:raise RuntimeError('No supported bead cadence')
selected['candidates']=candidates;selected['method']='Complete symmetric perimeter cadence with tip beads. Count chosen before placement to avoid within-rim sphere intersections; no individual beads pruned.';(D/'canonical_bead_plan.json').write_text(json.dumps(selected,indent=2));print(json.dumps({k:v for k,v in selected.items() if k not in ['canonical_centers','arc_parameters_mm']},indent=2))
