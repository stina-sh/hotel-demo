from pathlib import Path
import json,numpy as np,math
from scipy.spatial import cKDTree
D=Path(__file__).resolve().parent;q=json.load(open(D/'crown_bead_plan.json'));base=np.array([b['center'] for b in q['beads']]);r=np.linalg.norm(base[:,[0,2]],axis=1);a0=np.arctan2(base[:,0],base[:,2]);delta=np.zeros((len(base),2));limit=.36;low=np.c_[-np.full(len(base),limit),np.maximum(-limit,-12-base[:,1])];high=np.c_[np.full(len(base),limit),np.minimum(limit,12-base[:,1])]
def positions():
 a=a0+delta[:,0]/r;return np.c_[r*np.sin(a),base[:,1]+delta[:,1],r*np.cos(a)]
for iteration in range(600):
 p=positions();pairs=sorted(cKDTree(p).query_pairs(1.012));maxerr=0
 for i,j in pairs:
  # Current positions after the preceding constraint correction.
  aa=a0[[i,j]]+delta[[i,j],0]/r[[i,j]];vv=np.c_[r[[i,j]]*np.sin(aa),base[[i,j],1]+delta[[i,j],1],r[[i,j]]*np.cos(aa)];d=vv[0]-vv[1];dist=np.linalg.norm(d);gap=1.01-dist
  if gap<=0:continue
  maxerr=max(maxerr,gap);d/=dist;ei=np.array([math.cos(aa[0]),0,-math.sin(aa[0])]);ej=np.array([math.cos(aa[1]),0,-math.sin(aa[1])]);gi=np.array([d@ei,d[1]]);gj=-np.array([d@ej,d[1]]);den=gi@gi+gj@gj
  delta[i]+=gap*gi/den;delta[j]+=gap*gj/den;delta[i]=np.clip(delta[i],low[i],high[i]);delta[j]=np.clip(delta[j],low[j],high[j])
 if maxerr<2e-6:break
p=positions();tree=cKDTree(p);near=tree.query_pairs(1.015);mind=min(np.linalg.norm(p[i]-p[j]) for i,j in near);conf=[(i,j,float(np.linalg.norm(p[i]-p[j]))) for i,j in tree.query_pairs(.9999)]
for i,b in enumerate(q['beads']):b['pre_reflow_center']=b['center'];b['center']=p[i].tolist();b['tangent_reflow_delta_mm']=delta[i].tolist();b['reflow_displacement_mm']=float(np.linalg.norm(p[i]-base[i]))
q['status']='Bead candidate with explicit S masks, shared-junction replacement and bounded tangential cadence reflow; support validation pending';q['reflow']={'method':'Resolve complete junction cadences by bounded tangential movement on each bead radial level. No bead deleted during reflow.','iterations':iteration+1,'maximum_tangent_coordinate_shift_mm':float(np.abs(delta).max()),'maximum_centre_displacement_mm':float(np.linalg.norm(p-base,axis=1).max()),'minimum_centre_spacing_mm':float(mind),'remaining_conflicts':conf};q['sphere_axial_bounds_mm']=[float(p[:,1].min()-.5),float(p[:,1].max()+.5)];(D/'crown_bead_plan_reflowed.json').write_text(json.dumps(q,indent=2));print(json.dumps(q['reflow'],indent=2));print('envelope',q['sphere_axial_bounds_mm'])
