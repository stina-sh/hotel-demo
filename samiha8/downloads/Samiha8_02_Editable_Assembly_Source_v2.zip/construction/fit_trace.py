import numpy as np,math,json
from scipy.optimize import least_squares
from pathlib import Path
D=Path(__file__).resolve().parent;R=62/(2*math.pi)
pix=np.array([[107,362],[146,423],[205,470],[280,505],[355,528],[430,531],[480,513],[504,488]],float);bottom=np.array([412,538])
def axes(p):
 az,el,roll=p[:3];d=np.array([math.cos(el)*math.cos(az),math.cos(el)*math.sin(az),math.sin(el)]);right=np.array([-d[1],d[0],0]);right/=np.linalg.norm(right);up=np.cross(d,right);return right*math.cos(roll)-up*math.sin(roll),right*math.sin(roll)+up*math.cos(roll),d
def residual(p):
 rr,up,d=axes(p);C=np.array([[rr[0],rr[2]],[-up[0],-up[2]]])*p[3];q=(pix-p[4:6])@np.linalg.inv(C).T;err=(np.linalg.norm(q,axis=1)-R)*p[3];b=np.array([rr[2],-up[2]])*(-R)*p[3]+p[4:6];return np.r_[err,(b-bottom)*.7]
fit=least_squares(residual,[-.7,.51,.52,22,333,374],bounds=([-3,.1,-1.4,10,150,150],[-.1,1.3,1.4,40,500,500]),max_nfev=5000);rr,up,d=axes(fit.x)
q={'method':'Approximate single-view camera fit to manually observed bore arc. Crown depth is assumed, not calibrated.','parameters':fit.x.tolist(),'right':rr.tolist(),'up':up.tolist(),'direction':d.tolist(),'bore_pixels':pix.tolist(),'bottom_datum':bottom.tolist(),'residual_pixels':residual(fit.x).tolist(),'image_size':[679,675]}
left=np.array([[204,170],[244,166],[280,183],[298,215],[287,263],[280,307],[296,350],[334,387],[393,424],[478,466]])
right=np.array([[217,130],[265,126],[312,142],[344,178],[348,216],[336,267],[341,319],[380,369],[432,402],[494,433]])
def unproject(xy,rad=11.6):
 p=(xy[0]-fit.x[4])/fit.x[3]*rr-(xy[1]-fit.x[5])/fit.x[3]*up
 a=d[0]**2+d[2]**2;b=2*(p[0]*d[0]+p[2]*d[2]);c=p[0]**2+p[2]**2-rad**2;disc=b*b-4*a*c
 if disc<0:return [float('nan')]*3
 return (p+(-b+np.sqrt(disc))/(2*a)*d).tolist()
q['left_pixels']=left.tolist();q['right_pixels']=right.tolist();q['left_world']=[unproject(x) for x in left];q['right_world']=[unproject(x) for x in right]
(D/'reference2_camera_and_trace.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
