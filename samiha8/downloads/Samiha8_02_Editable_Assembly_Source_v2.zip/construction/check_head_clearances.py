from pathlib import Path
import json,numpy as np,cadquery as cq
from OCP.gp import gp_Trsf
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
D=Path(__file__).resolve().parent;P=D.parent;q=json.load(open(P/'sized25_crown_deep.provenance.json'));source=cq.Shape.importBrep(str(P.parent/'canonical-heads/leaf_scale1p7/cap.brep'));heads=[];boxes=[]
for rec in q['objects']:
 r=rec['replacement_gallery'];A=np.array(r['rigid_rotation_matrix']);b=r['translation_mm'];T=gp_Trsf();T.SetValues(*[x for i in range(3) for x in [*A[i],b[i]]]);s=cq.Shape.cast(BRepBuilderAPI_Transform(source.wrapped,T,True).Shape());heads.append(s);boxes.append(s.BoundingBox())
def gap(a,b):
 v=[]
 for k in 'xyz':v.append(max(0,getattr(a,k+'min')-getattr(b,k+'max'),getattr(b,k+'min')-getattr(a,k+'max')))
 return float(np.linalg.norm(v))
results=[]
for i,a in enumerate(heads):
 for j in range(i+1,len(heads)):
  bound=gap(boxes[i],boxes[j])
  if bound>.75:continue
  op=BRepExtrema_DistShapeShape(a.wrapped,heads[j].wrapped);op.Perform();distance=op.Value();results.append({'a':[q['objects'][i]['field'],q['objects'][i]['setting']],'b':[q['objects'][j]['field'],q['objects'][j]['setting']],'distance_mm':distance,'done':op.IsDone()});print('HEAD',results[-1],flush=True)
beads=json.load(open(D/'crown_bead_plan_reflowed.json'))['beads'];contacts=[];checked=0;min_bead_distance=1e9
for bi,bead in enumerate(beads):
 p=np.array(bead['center'])
 for hi,head in enumerate(heads):
  b=boxes[hi];outside=np.array([max(0,getattr(b,k+'min')-p[z],p[z]-getattr(b,k+'max')) for z,k in enumerate('xyz')])
  if np.linalg.norm(outside)>.55:continue
  op=BRepExtrema_DistShapeShape(cq.Vertex.makeVertex(*p).wrapped,head.wrapped);op.Perform();d=op.Value();checked+=1;min_bead_distance=min(min_bead_distance,d)
  if d<.5001:
   contact={'bead':bi,'head':[q['objects'][hi]['field'],q['objects'][hi]['setting']],'centre_to_head_distance_mm':d,'radius_mm':.5,'potential_overlap_mm':.5-d};contacts.append(contact);print('BEAD_HEAD',contact,flush=True)
r={'scope':'Exact CAD distance on qualified source-derived head-cap solids. Broadphase is conservative actual trimmed BRep bounds. Does not use preview triangles.','head_pair_count_total':78,'head_pairs_narrowphase':results,'minimum_head_clearance_mm':min(x['distance_mm'] for x in results),'minimum_narrowphase_bead_centre_to_head_distance_mm':min_bead_distance,'minimum_bead_head_clearance_mm':min_bead_distance-.5,'bead_head_narrowphase_tests':checked,'bead_head_contact_candidates':contacts};(D/'head_clearance_qa.json').write_text(json.dumps(r,indent=2));print('DONE',r['minimum_head_clearance_mm'],len(contacts))
