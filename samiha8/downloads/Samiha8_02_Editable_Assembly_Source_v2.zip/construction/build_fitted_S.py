from pathlib import Path
import json,math,numpy as np,cadquery as cq
from scipy.interpolate import PchipInterpolator
D=Path(__file__).resolve().parent;q=json.loads((D.parent/'reference2_camera_and_trace.json').read_text());R=11.6; axial_scale=25/(7.5179042255446165+5.013766232253656)*(25/25.000199119614464)*(25/24.999807210163944); axial_center=(7.5179042255446165-5.013766232253656)/2
curves=[]
for name in ['left_world','right_world']:
 p=np.array(q[name]);uv=np.c_[R*np.arctan2(p[:,0],p[:,2]),p[:,1]];curves.append(PchipInterpolator(uv[:,0],uv[:,1]))
u0=max(R*np.arctan2(q[k][0][0],q[k][0][2]) for k in ['left_world','right_world']);u1=min(R*np.arctan2(q[k][-1][0],q[k][-1][2]) for k in ['left_world','right_world'])-.1
u0=R*(.75-math.radians(44)/1.15);u1=R*(.75+math.radians(44)/1.15)
w=[]
stations=np.unique(np.r_[np.linspace(u0,u1,120),curves[0].x,curves[1].x]);stations=stations[(stations>=u0)&(stations<=u1)]
for u in stations:
 theta=(u/R-.75)*1.15;lo,hi=[(float(c(u))-axial_center)*axial_scale for c in curves];hi+=0.0
 p=[]
 for yy,rad in [(lo,11.55),(hi,11.55),(hi,11.35),(lo,11.35)]:p.append(cq.Vector(rad*math.sin(theta),yy,rad*math.cos(theta)))
 w.append(cq.Wire.makePolygon(p+[p[0]]))
s=cq.Solid.makeLoft(w,False);assert s.isValid();s.exportBrep(str(D/'S_terminal_fitted.brep'))
v,t=s.tessellate(.02,.1)
with (D/'S_terminal_fitted.obj').open('w') as f:
 for p in v:f.write(f'v {p.x} {p.y} {p.z}\n')
 for a in t:f.write('f '+' '.join(str(j+1) for j in a)+'\n')
(D/'S_terminal_fitted_notes.json').write_text(json.dumps({'status':'Crown layout study','construction':'Both edges independently traced from reference; unprojected to an assumed radial support using an approximate bore-based camera. Curves remain uncertain in depth.','ribbon_top_radius_mm':11.55,'ribbon_inner_radius_mm':11.35,'nominal_radial_wall_mm':.2,'normal_wall_status':'Dense loft approximation; full normal-distance validation pending','input_edge_trace':'../reference2_camera_and_trace.json','terminal_angles_degrees':[-44,44],'shoulder_underlap_start_degrees':[-41,41],'volume':s.Volume(),'valid':s.isValid()},indent=2))
print('RIBBON',s.Volume(),s.isValid())
