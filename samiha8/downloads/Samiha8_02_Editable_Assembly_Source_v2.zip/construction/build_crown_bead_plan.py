from pathlib import Path
import numpy as np,json,math
from scipy.interpolate import PchipInterpolator,CubicSpline
D=Path(__file__).resolve().parent;P=D.parent;q=json.load(open(P/'reference2_camera_and_trace.json'));source=json.load(open(D/'raw_gallery_beads.json'));beads=source['beads'];R=11.6;scale=25/(7.5179042255446165+5.013766232253656)*(25/25.000199119614464);center=(7.5179042255446165-5.013766232253656)/2
curves=[]
for name in ['left_world','right_world']:
 p=np.array(q[name]);curves.append(PchipInterpolator(R*np.arctan2(p[:,0],p[:,2]),(p[:,1]-center)*scale))
def edges(theta):return [float(c(R*(theta/1.15+.75))) for c in curves]
retained=[];masked=[]
for b in beads:
 p=np.array(b['center']);theta=math.atan2(p[0],p[2]);lo,hi=edges(theta)
 if abs(theta)<math.radians(44) and lo+.55<p[1]<hi-.55:
  masked.append(dict(b,reason='Gallery rim interval absorbed into uninterrupted polished S body'));continue
 retained.append({'center':b['center'],'members':[{'field':b['field'],'setting':b['setting'],'bead':b['bead'],'arc_mm':b['arc_mm']}],'kind':'gallery'})
# Inner S edge: complete arc-length cadence, with0.5mm axial inset to reserve total25mm.
theta=np.linspace(-math.radians(44),math.radians(44),3001);v=np.array([[11.87*math.sin(t),edges(t)[0]+.5,11.87*math.cos(t)] for t in theta]);arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(v,axis=0),axis=1))];curve=CubicSpline(arc,v);L=arc[-1];n=int((L-1.2)//1.03)+1;ss=np.linspace(.6,L-.6,n)
for i,s in enumerate(ss):retained.append({'center':curve(s).tolist(),'members':[{'field':'S','setting':0,'bead':i,'arc_mm':float(s)}],'kind':'S_inner_edge'})
shoulder_count=0
for rail in [3,2]:
 path=P/'shoulder-fit'/f'rail{rail}_{"inner" if rail==3 else "outer"}_roof_bead_path.json';data=json.load(open(path));points=np.array([r['bead_centre_radial_plus_0p32_mm'] for r in data['samples']]);points[:,1]+=.5;arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))];cu=CubicSpline(arc,points);length=arc[-1];count=int((length-.45-.55)//1.035)+1
 for bi,sa in enumerate(np.linspace(.45,length-.55,count)):
  retained.append({'center':cu(sa).tolist(),'members':[{'field':f'shoulder{rail}','setting':0,'bead':bi,'arc_mm':float(sa)}],'kind':'S_shoulder_continuation'});shoulder_count+=1
# Explicit shared-junction replacement. Every input centre remains covered by its
# replacement sphere; compact junctions preserve rail memberships and are never dropped.
shared=[]
while True:
 best=None
 for i in range(len(retained)):
  a=retained[i]
  for j in range(i+1,len(retained)):
   b=retained[j]
   if {tuple([m['field'],m['setting']]) for m in a['members']}=={tuple([m['field'],m['setting']]) for m in b['members']}:continue
   distance=np.linalg.norm(np.array(a['center'])-b['center'])
   if distance>=.999:continue
   old=a.get('original_centers',[a['center']])+b.get('original_centers',[b['center']]);c=np.mean(old,axis=0);spread=max(np.linalg.norm(c-p) for p in old)
   if spread>.465:continue
   if best is None or distance<best[0]:best=(distance,i,j,c,old)
 if best is None:break
 distance,i,j,c,old=best;a,b=retained[i],retained[j];new={'center':c.tolist(),'members':a['members']+b['members'],'original_centers':old,'kind':'shared_junction','max_center_relocation_mm':float(max(np.linalg.norm(c-p) for p in old))};shared.append({'members':new['members'],'center':c.tolist(),'reason':'Single true1mm shared-junction bead replaces overlapping rim candidates; all original centre nodes remain covered'});retained[i]=new;del retained[j]
centres=np.array([b['center'] for b in retained]);conflicts=[]
for i in range(len(retained)):
 for j in range(i+1,len(retained)):
  distance=float(np.linalg.norm(centres[i]-centres[j]))
  if distance<.999:conflicts.append({'a':i,'b':j,'distance_mm':distance,'members_a':retained[i]['members'],'members_b':retained[j]['members']})
out={'status':'DESIGN PLAN; shared-junction support and remaining conflicts require checks before release','bead_diameter_mm':1.0,'gallery_input_beads':len(beads),'gallery_absorbed_S_intervals':masked,'S_bead_count':n,'shoulder_bead_count':shoulder_count,'shared_junction_replacements':shared,'beads':retained,'unresolved_center_conflicts':conflicts,'sphere_axial_bounds_mm':[float(centres[:,1].min()-.5),float(centres[:,1].max()+.5)],'methods':['Original rim cadence preserved outside explicit polished-S mask','True1mm shared beads replace compact overlapping junction clusters; source memberships and relocation bounds retained','No isolated visible bead was silently removed']};(D/'crown_bead_plan.json').write_text(json.dumps(out,indent=2));print('masked S interior',len(masked),'S beads',n,'junction merges',len(shared),'output',len(retained),'remaining conflicts',len(conflicts),'envelope',out['sphere_axial_bounds_mm'])
