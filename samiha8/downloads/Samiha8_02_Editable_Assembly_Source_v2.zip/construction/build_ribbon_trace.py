from pathlib import Path
import json,math,numpy as np,cadquery as cq
from scipy.interpolate import PchipInterpolator
D=Path(__file__).resolve().parent;q=json.loads((D/'reference2_camera_and_trace.json').read_text());R=11.6
curves=[]
for name in ['left_world','right_world']:
 p=np.array(q[name]);uv=np.c_[R*np.arctan2(p[:,0],p[:,2]),p[:,1]];curves.append(PchipInterpolator(uv[:,0],uv[:,1]))
u0=max(R*np.arctan2(q[k][0][0],q[k][0][2]) for k in ['left_world','right_world']);u1=min(R*np.arctan2(q[k][-1][0],q[k][-1][2]) for k in ['left_world','right_world'])-.1
w=[]
for u in np.linspace(u0,u1,100):
 theta=u/R;lo,hi=[float(c(u)) for c in curves];p=[]
 for yy,rad in [(lo,R),(hi,R),(hi,R-.2),(lo,R-.2)]:p.append(cq.Vector(rad*math.sin(theta),yy,rad*math.cos(theta)))
 w.append(cq.Wire.makePolygon(p+[p[0]]))
s=cq.Solid.makeLoft(w,False);assert s.isValid();s.exportBrep(str(D/'traced_S_ribbon.brep'))
v,t=s.tessellate(.02,.1)
with (D/'traced_S_ribbon.obj').open('w') as f:
 for p in v:f.write(f'v {p.x} {p.y} {p.z}\n')
 for a in t:f.write('f '+' '.join(str(j+1) for j in a)+'\n')
(D/'traced_S_ribbon_notes.json').write_text(json.dumps({'status':'Crown layout study','construction':'Both edges independently traced from reference; unprojected to an assumed radial support using an approximate bore-based camera. Curves remain uncertain in depth.','ribbon_top_radius_mm':R,'ribbon_inner_radius_mm':R-.2,'nominal_radial_wall_mm':.2,'normal_wall_status':'Dense loft approximation; full normal-distance validation pending','input_edge_trace':'reference2_camera_and_trace.json','volume':s.Volume(),'valid':s.isValid()},indent=2))
print('RIBBON',s.Volume(),s.isValid())
