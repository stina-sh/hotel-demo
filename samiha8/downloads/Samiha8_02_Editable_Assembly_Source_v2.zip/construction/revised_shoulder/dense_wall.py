from pathlib import Path
import json,math,hashlib,numpy as np,cadquery as cq
from OCP.BRep import BRep_Tool
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
from OCP.TopAbs import TopAbs_IN,TopAbs_ON
from OCP.gp import gp_Lin,gp_Dir,gp_Pnt2d
D=Path(__file__).resolve().parent;C=D.parents[2]/'shoulder-fit/ledge-correction/flow-fitted-wall';p=C/'shoulder_3.brep';s=cq.Shape.importBrep(str(p));cl=BRepClass3d_SolidClassifier(s.wrapped);inter=IntCurvesFace_ShapeIntersector();inter.Load(s.wrapped,1e-8);new={4,11,12,13,14,15};rim={2,5};rows=[];samples=[];reject=[];noexit=[]
def inside(v):cl.Perform(v.toPnt(),1e-8);return cl.State()==TopAbs_IN
for fi,face in enumerate(s.Faces()):
 if fi in rim:continue
 surface=BRep_Tool.Surface_s(face.wrapped);u0,u1,v0,v1=face._uvBounds();fractions=[.04,.12,.24,.38,.5,.62,.76,.88,.96] if fi in new else [.07,.21,.39,.61,.79,.93];count=0;before=len(samples)
 for fu in fractions:
  for fv in fractions:
   u=u0+(u1-u0)*fu;v=v0+(v1-v0)*fv
   if BRepClass_FaceClassifier(face.wrapped,gp_Pnt2d(u,v),1e-9).State()!=TopAbs_IN:continue
   point=face.positionAt(u,v);normal=GeomLProp_SLProps(surface,u,v,1,1e-10)
   if not normal.IsNormalDefined():reject.append({'face':fi,'reason':'undefined_normal'});continue
   nn=normal.Normal();n=cq.Vector(nn.X(),nn.Y(),nn.Z());plus=inside(point+n*.002);minus=inside(point-n*.002)
   if plus==minus:reject.append({'face':fi,'point_mm':point.toTuple(),'reason':'normal_XOR_failed','both_inside':plus});continue
   if minus:n=-n
   count+=1;inter.Perform(gp_Lin(point.toPnt(),gp_Dir(n.x,n.y,n.z)),1e-6,4.0);hits=sorted(inter.WParameter(i) for i in range(1,inter.NbPnt()+1) if inter.WParameter(i)>1e-5);exitdist=None
   for h in hits:
    eps=min(1e-6,h/20)
    if inside(point+n*(h-eps)) and not inside(point+n*(h+eps)):exitdist=h;break
   if exitdist is None:noexit.append({'face':fi,'point_mm':point.toTuple()});continue
   samples.append({'face':fi,'new_side_closure':fi in new,'point_mm':point.toTuple(),'inward_normal':n.toTuple(),'thickness_mm':exitdist})
 vals=[x['thickness_mm'] for x in samples[before:]];rows.append({'face':fi,'type':face.geomType(),'new_side_closure':fi in new,'normal_boundary_accepted':count,'exit_samples':len(vals),'minimum_mm':min(vals,default=None),'maximum_mm':max(vals,default=None)});print('FACE',rows[-1],flush=True)
q={'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'valid':s.isValid(),'solid_count':len(s.Solids()),'method':'Independent trim-interior UV sample grid, boundary XOR at0.002mm, exact inward surface normal ray, first classified material exit within4mm. Dense9x9 grids for every new closure extrusion face;6x6 alternate grids for retained regular wall surfaces. Open annular rims2 and5 excluded from normal wall thickness.','scope':'Finite normal-wall witnesses, not a global minimum or uniform-thickness proof.','samples':samples,'faces':rows,'normal_boundary_rejections':reject,'no_exit_within4mm':noexit,'minimum_mm':min(x['thickness_mm'] for x in samples),'new_side_closure_minimum_mm':min(x['thickness_mm'] for x in samples if x['new_side_closure']),'under_nominal':[x for x in samples if x['thickness_mm']<.2-1e-5],'all_new_side_closure_faces_sampled':all(any(x['face']==f for x in samples) for f in new)};q['pass_finite_wall_check']=not q['under_nominal'] and q['all_new_side_closure_faces_sampled'];(D/'dense-wall.json').write_text(json.dumps(q,indent=2));print('FINAL',q['pass_finite_wall_check'],len(samples),q['minimum_mm'],q['new_side_closure_minimum_mm'],flush=True)
