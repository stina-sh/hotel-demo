#!/usr/bin/env python3
"""Independent finite wall sampling of source shoulders, including head caps."""
from pathlib import Path
import json,math,hashlib,concurrent.futures,time,argparse
import cadquery as cq
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Tool
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
from OCP.TopAbs import TopAbs_IN,TopAbs_ON
from OCP.gp import gp_Lin,gp_Dir,gp_Pnt2d
ROOT=Path.cwd()
OUT=ROOT/'qa';DETAILS=OUT/'fitted-shoulder-samples'
EPS=.015;NUM_TOL=1e-5

def check(path):
    p=Path(path);s=cq.Shape.importBrep(str(p));metadata=json.loads(p.with_suffix('.parameters.json').read_text())
    a=math.radians(metadata['head_angle_deg']);t=cq.Vector(metadata['sign_x']*math.cos(a),0,-math.sin(a))
    record=dict(key=p.stem,source=str(p),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),valid=s.isValid(),solid_count=len(s.Solids()),volume_mm3=s.Volume(),head_angle_deg=metadata['head_angle_deg'],faces=[],defects=[])
    if not record['valid'] or record['solid_count']!=1:record['defects'].append('Invalid source or not exactly one solid');return record
    BRepTools.Clean_s(s.wrapped)
    classifier=BRepClass3d_SolidClassifier(s.wrapped)
    def inside(v):
        classifier.Perform(v.toPnt(),1e-7);return classifier.State()==TopAbs_IN
    inter=IntCurvesFace_ShapeIntersector();inter.Load(s.wrapped,1e-7)
    samples=[];failures=[]
    for fi,face in enumerate(s.Faces()):
        c=face.Center();normal=face.normalAt(c);typ=face.geomType()
        ishead=typ=='PLANE' and abs(normal.dot(t))>.98 and abs(c.dot(t))<.25
        isbase=typ=='PLANE' and not ishead and abs(math.degrees(math.atan2(metadata['sign_x']*c.x,c.z))-90.5)<2
        is_new_rim=ishead or typ=='CYLINDER'
        role='open_head_rim' if is_new_rim else 'open_base_rim' if isbase else 'side_wall'
        fr=dict(face=fi,role=role,surface_type=typ,tested_uv=0,outside_trim=0,xor_rejected=0,accepted_boundary_samples=0,valid_exit_samples=0,no_exit_within_2mm=0,errors=[])
        fractions=[.08,.25,.5,.75,.92] if ishead else [.1,.3,.5,.7,.9]
        u0,u1,v0,v1=face._uvBounds();surface=BRep_Tool.Surface_s(face.wrapped)
        for fu in fractions:
            for fv in fractions:
                u=u0+(u1-u0)*fu;v=v0+(v1-v0)*fv;fr['tested_uv']+=1
                try:
                    fc=BRepClass_FaceClassifier(face.wrapped,gp_Pnt2d(u,v),1e-8)
                    if fc.State() not in (TopAbs_IN,TopAbs_ON):fr['outside_trim']+=1;continue
                    point=face.positionAt(u,v);prop=GeomLProp_SLProps(surface,u,v,1,1e-9)
                    if not prop.IsNormalDefined():fr['errors'].append('Undefined normal');continue
                    nn=prop.Normal();n=cq.Vector(nn.X(),nn.Y(),nn.Z())
                    plus=inside(point+n*EPS);minus=inside(point-n*EPS)
                    if plus==minus:
                        fr['xor_rejected']+=1
                        # Preserve ambiguous actual-face samples; never count them as thickness passes.
                        failures.append(dict(face=fi,role=role,u=u,v=v,point=point.toTuple(),reason='both_inside' if plus else 'both_outside'))
                        continue
                    if minus:n=-n
                    fr['accepted_boundary_samples']+=1
                    inter.Perform(gp_Lin(point.toPnt(),gp_Dir(n.x,n.y,n.z)),1e-5,2.)
                    hits=sorted(inter.WParameter(j) for j in range(1,inter.NbPnt()+1) if inter.WParameter(j)>1e-4)
                    exit_distance=None
                    for h in hits:
                        e=min(1e-5,h/10)
                        if inside(point+n*(h-e)) and not inside(point+n*(h+e)):
                            exit_distance=h;break
                    if exit_distance is None:fr['no_exit_within_2mm']+=1;continue
                    sample=dict(face=fi,role=role,u=u,v=v,point_mm=point.toTuple(),inward_normal=n.toTuple(),thickness_mm=exit_distance)
                    samples.append(sample);fr['valid_exit_samples']+=1
                except Exception as ex:fr['errors'].append(str(ex))
        vals=[z['thickness_mm'] for z in samples if z['face']==fi]
        fr['minimum_mm']=min(vals) if vals else None;fr['maximum_mm']=max(vals) if vals else None
        if ishead and not vals:pass
        record['faces'].append(fr)
    regular=[z for z in samples if z['role'] not in ('open_base_rim','open_head_rim')];heads=[z for z in samples if z['role']=='closed_head'];thin=[z for z in regular if z['thickness_mm']<.2-NUM_TOL]
    if thin:record['defects'].append(f'{len(thin)} boundary-valid samples below nominal 0.2 mm minus numerical tolerance 0.00001 mm')
    if not heads:record['open_head_rim_intentional']=True
    record.update(sample_count=len(regular),head_sample_count=len(heads),minimum_mm=min((z['thickness_mm'] for z in regular),default=None),maximum_mm=max((z['thickness_mm'] for z in regular),default=None),head_minimum_mm=min((z['thickness_mm'] for z in heads),default=None),head_maximum_mm=max((z['thickness_mm'] for z in heads),default=None),under_nominal_samples=thin,ambiguous_actual_face_boundary_samples=len(failures),sample_details=str(DETAILS/(p.stem+'.json')))
    (DETAILS/(p.stem+'.json')).write_text(json.dumps(dict(samples=samples,xor_rejections=failures),indent=2))
    (DETAILS/(p.stem+'.summary.json')).write_text(json.dumps(record,indent=2))
    print(json.dumps({k:record[k] for k in ['key','valid','sample_count','head_sample_count','minimum_mm','head_minimum_mm','defects']}),flush=True)
    return record
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--geometry-dir',default='final/fitted_shoulders');ap.add_argument('--report',default='qa/fitted-shoulder-independent-qa.json');ap.add_argument('--samples-dir',default='qa/fitted-shoulder-samples');ap.add_argument('--workers',type=int,default=2);args=ap.parse_args()
    DETAILS=ROOT/args.samples_dir;DETAILS.mkdir(parents=True,exist_ok=True)
    paths=sorted((ROOT/args.geometry_dir).glob('shoulder_[1-4].brep'))
    if not paths: raise SystemExit('No shoulder BREP files found in the selected directory')
    with concurrent.futures.ProcessPoolExecutor(max_workers=max(1,args.workers)) as pool:rows=list(pool.map(check,map(str,paths)))
    report=dict(scope=f'{len(rows)} unique crown-matched shoulder source solids; finite independent wall witnesses, not a global minimum proof',method='Trim-aware UV classification followed by inside/outside XOR at +/-0.015 mm; inward normal ray to first classified material exit. Closed head faces included. Open-base rim rays reported separately.',nominal_wall_mm=.2,numerical_allowance_mm=NUM_TOL,probe_offset_mm=EPS,ray_max_mm=2.,unique_shoulders=len(rows),all_source_solids_valid=all(r['valid'] and r['solid_count']==1 for r in rows),wall_sampling_pass=all(not r['defects'] for r in rows),sample_count=sum(r.get('sample_count',0) for r in rows),head_sample_count=sum(r.get('head_sample_count',0) for r in rows),minimum_mm=min((r['minimum_mm'] for r in rows if r.get('minimum_mm') is not None),default=None),head_minimum_mm=min((r['head_minimum_mm'] for r in rows if r.get('head_minimum_mm') is not None),default=None),shoulders=rows,native_export_status='pending')
    (ROOT/args.report).parent.mkdir(parents=True,exist_ok=True)
    (ROOT/args.report).write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='shoulders'}),flush=True)
