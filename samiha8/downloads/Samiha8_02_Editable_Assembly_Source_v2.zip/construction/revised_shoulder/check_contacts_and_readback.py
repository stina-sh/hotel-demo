from pathlib import Path
import json,numpy as np,cadquery as cq,hashlib
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN
D=Path(__file__).resolve().parent;W=D.parents[2];C=W/'shoulder-fit/ledge-correction/flow-fitted-wall';P=W/'complete-v1';ROOT=W.parents[1]
cl=lambda p:BRepClass3d_SolidClassifier(cq.Shape.importBrep(str(p)).wrapped)
shoulder=cl(C/'shoulder_3.brep');S=cl(P/'S_terminal_fitted.brep');lower=cl(ROOT/'final/shank_lower_hollow.brep')
def inside(c,p):c.Perform(gp_Pnt(*map(float,p)),1e-7);return c.State()==TopAbs_IN
def probes(p,d):p=np.array(p);return [p]+[p+sign*d*np.eye(3)[axis] for axis in range(3) for sign in [-1,1]]
cert=json.load((C/'contact-checks.json').open());rec=next(x for x in cert['results'] if x['rail']==3);checks=[]
for family,other in [('crown',S),('lower',lower)]:
 for w in rec[family+'_contact_witnesses']:
  pp=probes(w['point_mm'],.008);checks.append({'family':family,'point_mm':w['point_mm'],'all7_points_strictly_inside_both':all(inside(shoulder,p) and inside(other,p) for p in pp)})
print('CROWN_LOWER',len(checks),all(x['all7_points_strictly_inside_both'] for x in checks),flush=True)
beadcert=json.load((P/'reflowed_bead_support_qa.json').open());beads=json.load((D.parent/'final_bead_geometry.json').open());bc=[]
for rec in beadcert['checks']:
 if not any(owner[0]=='shoulder3' for owner in rec['support_owners']):continue
 i=rec['bead'];c=np.array(beads[i]['center']);pp=probes(rec['witness_mm'],.008);bc.append({'bead':i,'native_center_mm':c.tolist(),'all7_points_inside_candidate_shoulder_and_native_sphere':all(inside(shoulder,p) and np.linalg.norm(p-c)<.5 for p in pp)})
print('BEADS',len(bc),all(x['all7_points_inside_candidate_shoulder_and_native_sphere'] for x in bc),flush=True)
q={'candidate_brep_sha256':hashlib.sha256((C/'shoulder_3.brep').read_bytes()).hexdigest(),'candidate_native_sha256':hashlib.sha256((C/'shoulder_3.3dm').read_bytes()).hexdigest(),'retained_S_brep_sha256':hashlib.sha256((P/'S_terminal_fitted.brep').read_bytes()).hexdigest(),'method':'Independent classification of every candidate shoulder3/S and lower witness and every old shoulder3-supported bead witness, each with six0.008mm axis neighbors. Bead centers/radii came from the independently read frozen native model.','contact_checks':checks,'all_contacts_pass':all(x['all7_points_strictly_inside_both'] for x in checks),'bead_checks':bc,'all_affected_bead_supports_pass':all(x['all7_points_inside_candidate_shoulder_and_native_sphere'] for x in bc),'limits':'Finite positive attachment witnesses; not a fused solid or full interface-continuity proof.'};(D/'contact-replay.json').write_text(json.dumps(q,indent=2))
