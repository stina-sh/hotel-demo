from pathlib import Path
import sys,json,math,itertools,numpy as np
from scipy.optimize import minimize,minimize_scalar
D=Path(__file__).resolve().parent;root=D.parents[4];sys.path.insert(0,str(root/'source/donor-preview'))
from faces_to_mesh import Reader,surface,curve,build_face
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.gp import gp_Pnt2d
from OCP.TopAbs import TopAbs_IN,TopAbs_ON
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
reports=[]
for stem in ['candidate_S3']:
 r=Reader(D/(stem+'.faces'));r.expect('NATIVEFACES');r.i();r.expect('O');oi,nf=r.i(),r.i();rows=[]
 for _ in range(nf):
  r.expect('F');fi,rev,nl,mapping=r.i(),r.i(),r.i(),r.i();s,err=surface(r);loops=[]
  for _ in range(nl):
   r.expect('L');typ,nt=r.i(),r.i();items=[]
   for _ in range(nt):r.expect('T');tt,v0,v1=r.i(),r.i(),r.i();items.append((tt,curve(r)))
   loops.append((typ,items))
  f=build_face(s,loops,rev);box=Bnd_Box();BRepBndLib.AddOptimal_s(f,box,False,False)
  uvbounds=s.Bounds();bounds=[uvbounds[:2],uvbounds[2:]];candidate=[]
  def pos(uv):p=s.Value(*map(float,uv));return np.array([p.X(),p.Y(),p.Z()])
  def allowed(uv):return BRepClass_FaceClassifier(f,gp_Pnt2d(*map(float,uv)),1e-9).State() in [TopAbs_IN,TopAbs_ON]
  # Candidate extrema include every trim's 81 brackets, endpoints, and stationary face interiors.
  objectives=[('ymin',lambda p:p[1]),('ymax',lambda p:-p[1]),('zmin',lambda p:p[2]),('rmin',lambda p:math.hypot(p[0],p[2]))]
  extrema={}
  for key,fun in objectives:
   cc=[]
   for typ,items in loops:
    for tt,c in items:
     def fp(t):uv=c.Value(t);return pos((uv.X(),uv.Y()))
     tt=np.linspace(c.FirstParameter(),c.LastParameter(),81);vv=[fun(fp(t)) for t in tt];idx=[0,80]+[i for i in range(1,80) if vv[i]<=vv[i-1] and vv[i]<=vv[i+1]]
     for i in idx:
      t=tt[i]
      if 0<i<80:t=minimize_scalar(lambda t:fun(fp(t)),bounds=(tt[i-1],tt[i+1]),method='bounded',options={'xatol':1e-12}).x
      p=fp(t);cc.append((fun(p),p.tolist(),'trim'))
   for uv in itertools.product(np.linspace(*bounds[0],7),np.linspace(*bounds[1],7)):
    result=minimize(lambda x:fun(pos(x)),uv,method='L-BFGS-B',bounds=bounds,options={'ftol':1e-15,'gtol':1e-10,'maxiter':200})
    if allowed(result.x):
     p=pos(result.x);cc.append((fun(p),p.tolist(),'face'))
   best=min(cc,key=lambda c:c[0]);extrema[key]={'value_mm':-best[0] if key=='ymax' else best[0],'point_mm':best[1],'kind':best[2],'candidate_count':len(cc)}
  rows.append({'face':fi,'mapping':mapping,'surface_transfer_witness_error_mm':err,'trimmed_AddOptimal_bounds_mm':list(box.Get()),'optimized':extrema})
 report={'object':oi,'name':stem,'faces':rows,'axial_bounds_mm':[min(x['optimized']['ymin']['value_mm'] for x in rows),max(x['optimized']['ymax']['value_mm'] for x in rows)],'minimum_z_mm':min(x['optimized']['zmin']['value_mm'] for x in rows),'face_trim_sampled_minimum_bore_radius_mm':min(x['optimized']['rmin']['value_mm'] for x in rows),'scope':'Trim-edge bracketed numerical extrema plus multi-start stationary face search on reopened native rational surfaces; exact native trim curves, no display-mesh bounds. Finite numerical search, not a symbolic extrema proof.'};reports.append(report);print(stem,report['axial_bounds_mm'],report['minimum_z_mm'],report['face_trim_sampled_minimum_bore_radius_mm'],flush=True)
 (D/'trim_bounds.json').write_text(json.dumps(reports,indent=2))
