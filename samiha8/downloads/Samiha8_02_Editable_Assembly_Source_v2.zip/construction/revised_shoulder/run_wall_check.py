from pathlib import Path
import json
import check_open_walls as w
D=Path(__file__).resolve().parent;w.DETAILS=D/'wall-samples';w.DETAILS.mkdir(exist_ok=True);q=w.check(str(D/'shoulder_3.brep'));(D/'wall-checks.json').write_text(json.dumps(q,indent=2))
