import cadquery as cq,numpy as np, math,json,pathlib,time
from scipy.interpolate import CubicSpline, PchipInterpolator, CubicHermiteSpline
ROOT=pathlib.Path(__file__).resolve().parents[1];RIN=62/(2*math.pi)
a=np.loadtxt(ROOT/'qa/client-taper-samples.csv',delimiter=',',skiprows=1)
up=a[a[:,3]==73];lo=a[a[:,3]==72];up=up[np.argsort(up[:,0])];lo=lo[np.argsort(lo[:,0])]
us=CubicSpline(up[:,0],up[:,1]);ls=CubicSpline(lo[:,0],lo[:,1]);ur=CubicSpline(up[:,0],up[:,2]);lr=CubicSpline(lo[:,0],lo[:,2]);MAX=float(a[:,1].max());MIN=float(lo[-1,1]);START=float(a[np.argmax(a[:,1]),0])
# Local Hermite blend replaces the native tangent discontinuity around90deg.
blend=CubicHermiteSpline([80,100],[us(80),ls(100)],[us(80,1),ls(100,1)])
blendr=CubicHermiteSpline([80,100],[ur(80),lr(100)],[ur(80,1),lr(100,1)])
def halfwidth(t):
 t=min(t,360-t)
 w=float(us(t) if t<80 else blend(t) if t<=100 else ls(min(t,lo[-1,0])))
 return 2+10.5*(w-MIN)/(MAX-MIN)
def radius(t):
 t=min(t,360-t)
 return float(ur(t) if t<80 else blendr(t) if t<=100 else lr(min(t,lo[-1,0])))
def pt(t,y,rad):
 t=math.radians(t);return cq.Vector(rad*math.sin(t),y,rad*math.cos(t))
def section(t,y0,y1):
 r=radius(t);ps=[pt(t,y0,RIN),pt(t,y1,RIN),pt(t,y1,r),pt(t,y0,r)];return cq.Wire.makePolygon(ps+[ps[0]])
def hollow(wires,name):
 print('loft',name,flush=True);outer=cq.Solid.makeLoft(wires,False)
 assert outer.isValid()
 outer.exportBrep(str(ROOT/'final'/f'{name}_outer.brep'))
 caps=[f for f in outer.Faces() if f.geomType()=='PLANE']
 print(name,'caps',len(caps),flush=True);t0=time.time()
 result=outer.shell(caps,-.2,tolerance=1e-5,kind='intersection').fix()
 print(name,'offset',time.time()-t0,result.isValid(),flush=True)
 path=ROOT/'final'/f'{name}.brep';result.exportBrep(str(path));reread=cq.Shape.importBrep(str(path)).fix();reread.exportBrep(str(path));assert cq.Shape.importBrep(str(path)).isValid()
 return reread
ROOT.joinpath('final').mkdir(exist_ok=True)
theta=np.unique(np.r_[np.linspace(89.5,180,27),180,360-np.linspace(89.5,180,27)])
lower=hollow([section(t,-halfwidth(t),halfwidth(t)) for t in theta],'shank_lower_hollow')
sections=[]
for t in np.linspace(START,90.5,22):
 w=halfwidth(t)
 # Source-style upper shoulders are two open rails. Their inner gap closes
 # smoothly at90deg, with a short positive overlap into the lower band.
 a=min(1,max(0,(t-START)/(90-START)));ease=a*a*(3-2*a)
 rail_width=.9*(1-ease)+w*ease
 sections.append(section(t,w-rail_width,w))
rightpos=hollow(sections,'shank_upper_rail_hollow')
rightneg=rightpos.mirror('XZ');leftpos=rightpos.mirror('YZ');leftneg=rightneg.mirror('YZ')
parts=[lower,rightpos,rightneg,leftpos,leftneg]
compound=cq.Compound.makeCompound(parts);compound.exportBrep(str(ROOT/'final/shank_hollow.brep'));cq.exporters.export(compound,str(ROOT/'final/shank_hollow.step'))
q={'valid':all(x.isValid() for x in parts),'solid_count':5,'bore_radius_mm':RIN,'target_top_width_mm':25,'target_bottom_width_mm':4,'offset_wall_mm':.2,'source_profile_faces':[73,72],'native_slope_blend_angles_deg':[80,100],'upper_angle_deg':START,'construction':'Open forked shoulders; two branch rails on each side join hollow lower band','lower_upper_contacts_mm3':[lower.intersect(x).Volume() for x in parts[1:]],'stations':[{'angle_deg':float(t),'width_mm':float(2*halfwidth(t)),'outer_radius_mm':radius(t)} for t in np.linspace(START,180,51)]}
(ROOT/'qa/shank-construction.json').write_text(json.dumps(q,indent=2));print(q,flush=True)
