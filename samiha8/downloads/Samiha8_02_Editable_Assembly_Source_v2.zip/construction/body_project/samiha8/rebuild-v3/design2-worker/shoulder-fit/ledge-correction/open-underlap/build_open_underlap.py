from pathlib import Path
import cadquery as cq,math,json
from OCP.BRepTools import BRepTools
D=Path(__file__).resolve().parent;P=D.parents[1];angle=42.75;t=math.radians(angle);s=cq.Shape.importBrep(str(P/'shoulder_3.brep'));BRepTools.Clean_s(s.wrapped)
plane=cq.Plane(origin=(0,0,0),xDir=(0,1,0),normal=(math.cos(t),0,math.sin(t)));cutter=cq.Workplane(plane).rect(100,100).extrude(100).val();r=s.cut(cutter).clean().fix();assert r.isValid() and len(r.Solids())==1;r.exportBrep(str(D/'shoulder_3.brep'));r=cq.Shape.importBrep(str(D/'shoulder_3.brep'));assert r.isValid();q=json.load(open(P/'shoulder_3.parameters.json'));q.update(head_angle_deg=angle,open_head_underlap=True,normal_wall_offset_unchanged=True,source=str(P/'shoulder_3.brep'),cut='Plane through Y axis at signed -42.75 degrees removes original cap, leaving an open hollow underlap and preserving the outer/inner wall surfaces',volume_mm3=r.Volume());(D/'shoulder_3.parameters.json').write_text(json.dumps(q,indent=2));print('PASS',r.Volume(),len(r.Faces()),flush=True)
with (D/'shoulders-preview.obj').open('w') as f:
 off=0
 for i in range(1,5):
  part=r if i==3 else cq.Shape.importBrep(str(P/f'shoulder_{i}.brep'));v,tri=part.tessellate(.03,.12);f.write('o shoulder_'+str(i)+'\n')
  for a in v:f.write(f'v {a.x} {a.y} {a.z}\n')
  for a in tri:f.write('f '+' '.join(str(x+1+off) for x in a)+'\n')
  off+=len(v)
