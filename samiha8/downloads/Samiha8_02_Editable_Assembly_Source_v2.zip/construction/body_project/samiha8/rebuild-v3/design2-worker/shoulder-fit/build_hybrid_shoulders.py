from pathlib import Path
import cadquery as cq,numpy as np,math,json,time,sys
from scipy.interpolate import PchipInterpolator,CubicHermiteSpline
from concurrent.futures import ProcessPoolExecutor
D=Path(__file__).resolve().parent;W=D.parent;ROOT=W.parents[1]
ns={'__file__':str(ROOT/'source/build_tapered_shank.py')};code=(ROOT/'source/build_tapered_shank.py').read_text();exec(code[:code.index("ROOT.joinpath('final')")],ns)
halfwidth=ns['halfwidth'];radius=ns['radius'];RIN=ns['RIN']
def d1(f,t):return (f(t+.001)-f(t-.001))/.002

def smooth(u):u=np.clip(u,0,1);return u*u*(3-2*u)
def smooth_c2(u):u=np.clip(u,0,1);return u*u*u*(10-15*u+6*u*u)
S=json.loads((D/'hybrid-S-section-samples.json').read_text())+json.loads((D/'hybrid-S-underlap-sections.json').read_text())
PARAMS=[{'rail':1,'name':'positive_X_positive_Y_gallery_shoulder','sign_x':1,'sign_y':1,'kind':'gallery','target':'right_01_skirt','head_angle_deg':47.,'flow_start_angle_deg':47.,'head_outer_y_abs_mm':9.141194675930056,'head_width_mm':1.6,'head_inner_radius_mm':11.18,'head_outer_radius_mm':11.73,'inner_radius_blend_end_angle_deg':75.,'roof_blend_end_angle_deg':61.},
{'rail':2,'name':'positive_X_negative_Y_S_shoulder','sign_x':1,'sign_y':-1,'kind':'S','target':'S_ribbon','head_angle_deg':41.,'flow_start_angle_deg':44.,'head_inner_radius_mm':11.,'head_outer_radius_mm':11.55,'inner_radius_blend_end_angle_deg':75.,'roof_blend_end_angle_deg':57.},
{'rail':3,'name':'negative_X_positive_Y_S_shoulder','sign_x':-1,'sign_y':1,'kind':'S','target':'S_ribbon','head_angle_deg':41.,'flow_start_angle_deg':44.,'head_inner_radius_mm':11.,'head_outer_radius_mm':11.55,'inner_radius_blend_end_angle_deg':75.,'roof_blend_end_angle_deg':57.},
{'rail':4,'name':'negative_X_negative_Y_gallery_shoulder','sign_x':-1,'sign_y':-1,'kind':'gallery','target':'left_05_skirt','head_angle_deg':60.,'flow_start_angle_deg':60.,'head_outer_y_abs_mm':11.623093719811404,'head_width_mm':1.6,'head_inner_radius_mm':10.825,'head_outer_radius_mm':11.375,'inner_radius_blend_end_angle_deg':81.,'roof_blend_end_angle_deg':72.}]

def laws(p):
 h=p['flow_start_angle_deg'];hs=p['head_angle_deg'];join=89.5;span=join-h
 if p['kind']=='S':
  vals=sorted([r for r in S if r['sign_x']==p['sign_x']],key=lambda r:r['angle_deg']);xa=np.array([r['angle_deg'] for r in vals]);oa=np.array([r['y_range_abs_mm'][1] for r in vals]);ia=np.array([r['y_range_abs_mm'][0] for r in vals]);souter=PchipInterpolator(xa,oa);sinner=PchipInterpolator(xa,ia)
  inset=.005;p['axial_underlap_inset_mm']=inset
  wh=float(souter(h))-inset;gh=float(sinner(h))+inset;wd=float((souter(h+.25)-souter(h-.25))/.5);gd=float((sinner(h+.25)-sinner(h-.25))/.5);rw=wh-gh
  p.update(head_outer_y_abs_mm=float(souter(hs))-inset,head_width_mm=float(souter(hs)-sinner(hs))-2*inset,trim_angle_deg=44.,underlap_angle_deg=3.,flow_outer_y_abs_mm=wh,flow_inner_y_abs_mm=gh,flow_rail_width_mm=rw,flow_outer_slope_mm_per_deg=wd,flow_inner_slope_mm_per_deg=gd)
 else:wh=p['head_outer_y_abs_mm'];rw=p['head_width_mm'];gh=wh-rw;wd=0.;gd=0.
 delta=wh-halfwidth(h)
 def rawwidth(a):return halfwidth(a)+delta*(1-float(smooth((a-h)/span)))
 lead=min(h+10,join-6);outerlead=CubicHermiteSpline([h,lead],[wh,rawwidth(lead)],[wd,d1(rawwidth,lead)])
 def width(a):
  if a<h and p['kind']=='S':return float(souter(a))-.005
  if a<lead:return float(outerlead(a))
  if a<join:return rawwidth(a)
  return halfwidth(a)
 waist=max(h+5,68.)
 waist_width=.72*rw if p['kind']=='S' else rw
 gapwaist=width(waist)-waist_width
 gapcurve=CubicHermiteSpline([h,waist,join],[gh,gapwaist,0.],[gd,d1(width,waist),0.])
 def gap(a):
  if a<h and p['kind']=='S':return float(sinner(a))+.005
  return max(0.,float(gapcurve(a))) if a<join else 0.
 roofend=p['roof_blend_end_angle_deg'];roof=CubicHermiteSpline([h,roofend],[p['head_outer_radius_mm'],radius(roofend)],[0.,d1(radius,roofend)])
 def ro(a):return p['head_outer_radius_mm'] if a<h else float(roof(a)) if a<roofend else radius(a)
 innerend=p['inner_radius_blend_end_angle_deg']
 def ri(a):return p['head_inner_radius_mm']+(RIN+.0003-p['head_inner_radius_mm'])*float(smooth_c2((a-h)/(innerend-h)))
 p.update(inner_radius_target_construction_allowance_mm=.0003,inner_radius_target_mm=RIN+.0003,width_method='Measured client07 half-width plus endpoint fade; C1 head lead; no minimum accumulation',waist_angle_deg=waist,waist_rail_width_mm=waist_width,lower_join_angle_deg=join,lower_overlap_end_angle_deg=90.5,normal_wall_offset_mm=.2,head_band_radial_height_mm=p['head_outer_radius_mm']-p['head_inner_radius_mm'])
 return width,gap,ri,ro

def build(p):
 p=dict(p);w,g,ri,ro=laws(p);h=p['head_angle_deg'];critical=np.unique([h,p['flow_start_angle_deg'],p['flow_start_angle_deg']+10,p['waist_angle_deg'],p['roof_blend_end_angle_deg'],p['inner_radius_blend_angle_deg'] if 'inner_radius_blend_angle_deg' in p else p['inner_radius_blend_end_angle_deg'],89.5,90.5]);regular=[a for a in np.linspace(h,90.5,23) if min(abs(a-critical))>.8];angles=np.sort(np.r_[critical,regular])
 dense=np.linspace(h,90.5,2001);v=np.array([[a,w(a),g(a),w(a)-g(a),ri(a),ro(a)] for a in dense]);p['minimum_radial_band_mm']=float((v[:,5]-v[:,4]).min());p['minimum_rail_width_mm']=float(v[:,3].min());p['maximum_axial_width_increase_per_dense_step_mm']=float(np.diff(v[:,1]).max());p['gap_min_mm']=float(v[:,2].min())
 if p['minimum_radial_band_mm']<.44:raise ValueError(('Band too shallow for shell',p))
 if p['minimum_rail_width_mm']<.5:raise ValueError(('Rail too narrow for shell',p))
 if np.diff(v[:,1]).max()>.001:raise ValueError(('Nonmonotone width',p))
 wires=[]
 for a in angles:
  t=math.radians(a)
  def pt(y,r):return cq.Vector(r*math.sin(t),y,r*math.cos(t))
  ps=[pt(g(a),ri(a)),pt(w(a),ri(a)),pt(w(a),ro(a)),pt(g(a),ro(a))];wires.append(cq.Wire.makePolygon(ps+[ps[0]]))
 start=time.time();print('BUILD',p['rail'],p['name'],'minheight',p['minimum_radial_band_mm'],'minwidth',p['minimum_rail_width_mm'],flush=True)
 outer=cq.Solid.makeLoft(wires,False).fix();assert outer.isValid();outer.exportBrep(str(D/f"shoulder_{p['rail']}_outer.brep"))
 caps=[f for f in outer.Faces() if f.geomType()=='PLANE'];base=min(caps,key=lambda f:f.Center().z)
 error=None
 for mode in ['intersection','arc']:
  try:
   s=outer.shell([base],-.2,tolerance=1e-5,kind=mode).fix()
   if not s.isValid():raise ValueError('Invalid shell')
   if len(s.Faces())<=len(outer.Faces()) or s.Volume()>.95*outer.Volume():raise ValueError('Offset returned un-hollowed outer solid')
   p['offset_junction_mode']=mode;break
  except Exception as e:error=str(e);print('OFFSET RETRY',p['rail'],mode,error,flush=True)
 else:raise ValueError(('Both offset methods failed',p['rail'],error))
 if p['sign_x']<0:s=s.mirror('YZ')
 if p['sign_y']<0:s=s.mirror('XZ')
 path=D/f"shoulder_{p['rail']}.brep";s.exportBrep(str(path));s=cq.Shape.importBrep(str(path)).fix();assert s.isValid() and len(s.Solids())==1;s.exportBrep(str(path));r=cq.Shape.importBrep(str(path));assert r.isValid()
 p['file']=str(path);p['valid_after_reopen']=True;p['solid_count']=len(r.Solids());p['volume_mm3']=r.Volume();p['build_seconds']=time.time()-start;p['stations_angle_outerY_innerY_railwidth_innerR_outerR']=v[::20].tolist();(D/f"shoulder_{p['rail']}.parameters.json").write_text(json.dumps(p,indent=2));print('DONE',p['rail'],p['build_seconds'],flush=True)
 return p

if __name__=='__main__':
 if len(sys.argv)>1:
  k=int(sys.argv[1]);build(PARAMS[k-1]);sys.exit(0)
 with ProcessPoolExecutor(max_workers=2) as pool:params=list(pool.map(build,PARAMS))
 parts=[cq.Shape.importBrep(str(D/f'shoulder_{p["rail"]}.brep')) for p in params];compound=cq.Compound.makeCompound(parts);compound.exportBrep(str(D/'shoulders.brep'))
 with (D/'shoulders-preview.obj').open('w') as f:
  off=0
  for p,s in zip(params,parts):
   f.write('o '+p['name']+'\n');vs,ts=s.tessellate(.04,.12)
   for v in vs:f.write(f'v {v.x} {v.y} {v.z}\n')
   for t in ts:f.write('f '+' '.join(str(i+1+off) for i in t)+'\n')
   off+=len(vs)
 (D/'parameters.json').write_text(json.dumps({'source_07_sha256':'d28ed353ad664bfc6f45089dbda1363f8bcc0ec67d51c5cfd73762130521f5cb','EU62_inner_radius_mm':RIN,'lower_band_reused_unchanged':str(ROOT/'final/shank_lower_hollow.brep'),'bottom_width_mm':4.,'objects':params},indent=2))
 print('COMPOUND READY',flush=True)
