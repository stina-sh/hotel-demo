from pathlib import Path
import cadquery as cq,json,math,numpy as np,sys
from OCP.BRepTools import BRepTools
D=Path(__file__).resolve().parent;P=D.parents[1];sys.path.insert(0,str(P));from build_hybrid_shoulders import laws,smooth_c2
p=json.load(open(P/'shoulder_3.parameters.json'));w,g,ri,ro=laws(dict(p));source=D.parent/'open-underlap/shoulder_3.brep';s=cq.Shape.importBrep(str(source));BRepTools.Clean_s(s.wrapped)
start=42.75;end=64.;target=10.7;delta=w(start)-target;records=[]
for a in np.linspace(40,72,81):
 fade=1-float(smooth_c2((a-start)/(end-start)));outside=.004+max(0,a-end)**2*.015;y=w(a)-delta*fade+outside;z=ro(a)*math.cos(math.radians(a));records.append([float(a),float(y),float(z),float(w(a)),float(delta*fade)])
points=[cq.Vector(-25,r[1],r[2]) for r in records[::-1]]
# Extend the cutter above the head; all geometry below the low end remains inside the mask.
points+=[cq.Vector(-25,records[0][1],10.),cq.Vector(-25,records[0][1],12.)]
edge=cq.Edge.makeSpline(points);low=points[0];high=points[-1];bot=cq.Vector(-25,low.y,-30);top=cq.Vector(-25,high.y,30);lt=cq.Vector(-25,-30,30);lb=cq.Vector(-25,-30,-30)
wire=cq.Wire.assembleEdges([cq.Edge.makeLine(bot,low),edge,cq.Edge.makeLine(high,top),cq.Edge.makeLine(top,lt),cq.Edge.makeLine(lt,lb),cq.Edge.makeLine(lb,bot)]);mask=cq.Solid.extrudeLinear(wire,[],cq.Vector(50,0,0));assert mask.isValid();outer=cq.Shape.importBrep(str(P/'shoulder_3_outer.brep')).mirror('YZ').fix();original=cq.Shape.importBrep(str(P/'shoulder_3.brep'));BRepTools.Clean_s(outer.wrapped);BRepTools.Clean_s(original.wrapped);cavity=outer.cut(original).clean().fix();assert cavity.isValid() and len(cavity.Solids())==1
inner_wires=wire.offset2D(-.2,kind='arc');assert len(inner_wires)==1;inner_wire=inner_wires[0];assert cq.Face.makeFromWires(inner_wire).Area()<cq.Face.makeFromWires(wire).Area();inner_mask=cq.Solid.extrudeLinear(inner_wire,[],cq.Vector(50,0,0));assert inner_mask.isValid()
a=math.radians(42.75);plane=cq.Plane(origin=(0,0,0),xDir=(0,1,0),normal=(math.cos(a),0,math.sin(a)));endcut=cq.Workplane(plane).rect(100,100).extrude(100).val();new_outer=outer.cut(endcut).intersect(mask).clean().fix();new_cavity=cavity.cut(endcut).intersect(inner_mask).clean().fix();assert new_outer.isValid() and new_cavity.isValid();new_outer.exportBrep(str(D/'trimmed_outer.brep'));new_cavity.exportBrep(str(D/'trimmed_cavity.brep'));r=new_outer.cut(new_cavity).clean().fix();assert r.isValid() and len(r.Solids())==1;r.exportBrep(str(D/'shoulder_3.brep'));r=cq.Shape.importBrep(str(D/'shoulder_3.brep'));assert r.isValid();q=json.load(open(D.parent/'open-underlap/shoulder_3.parameters.json'));q.update(volume_mm3=r.Volume(),outer_underlap_target_y_mm=target,outer_underlap_fade_angle_range_deg=[start,end],outer_underlap_profile=records,cut_scope='Open head underlap; outer side follows client-derived shoulder flow with a C2 inward fade. The new side closure uses a true 0.2 mm normal 2D profile offset, while the original roof, floor and lower-body wall surfaces are retained.');(D/'shoulder_3.parameters.json').write_text(json.dumps(q,indent=2));print('PASS',r.Volume(),len(r.Faces()),flush=True)
with (D/'shoulders-preview.obj').open('w') as f:
 off=0
 for i in range(1,5):
  part=r if i==3 else cq.Shape.importBrep(str(P/f'shoulder_{i}.brep'));v,tri=part.tessellate(.03,.12);f.write('o shoulder_'+str(i)+'\n')
  for a in v:f.write(f'v {a.x} {a.y} {a.z}\n')
  for a in tri:f.write('f '+' '.join(str(x+1+off) for x in a)+'\n')
  off+=len(v)
