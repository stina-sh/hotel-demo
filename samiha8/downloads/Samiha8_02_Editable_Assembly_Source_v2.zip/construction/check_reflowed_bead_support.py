from pathlib import Path
import json,math,numpy as np,cadquery as cq,itertools
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN
D=Path(__file__).resolve().parent;P=D.parent;q=json.load(open(D/'crown_bead_plan_reflowed.json'));prov=json.load(open(P/'sized25_crown_deep.provenance.json'));pose={};classes=[BRepClass3d_SolidClassifier(cq.Shape.importBrep(str(P.parent/'canonical-galleries/leaf_scale1p7'/(name+'.brep'))).wrapped) for name in ['footplate','skirt']];sc=BRepClass3d_SolidClassifier(cq.Shape.importBrep(str(D/'S_terminal_fitted.brep')).wrapped)
for r in prov['objects']:
 p=r['replacement_gallery'];pose[(r['field'],r['setting'])]=(np.array(p['rigid_rotation_matrix']),np.array(p['translation_mm']))
shoulder_classes={f'shoulder{i}':BRepClass3d_SolidClassifier(cq.Shape.importBrep(str(P/'shoulder-fit'/f'shoulder_{i}.brep')).wrapped) for i in [2,3]}
def inside(owner,p):
 if owner[0].startswith('shoulder'):
  cl=shoulder_classes[owner[0]];cl.Perform(gp_Pnt(*map(float,p)),1e-7);return cl.State()==TopAbs_IN
 if owner[0]=='S':sc.Perform(gp_Pnt(*map(float,p)),1e-7);return sc.State()==TopAbs_IN
 A,b=pose[owner];p=(p-b)@A
 for cl in classes:
  cl.Perform(gp_Pnt(*map(float,p)),1e-7)
  if cl.State()==TopAbs_IN:return True
 return False
checks=[]
for i,bead in enumerate(q['beads']):
 c=np.array(bead['center']);a=math.atan2(c[0],c[2]);n=np.array([math.sin(a),0,math.cos(a)]);ex=np.array([math.cos(a),0,-math.sin(a)]);ey=np.array([0,1,0]);owners=sorted({(m['field'],m['setting']) for m in bead['members']});candidate=[]
 for v in bead.get('original_centers',[bead['pre_reflow_center']]):
  v=np.array(v);vn=v*np.array([1,0,1]);vn/=np.linalg.norm(vn)
  for depth in [.40,.36,.43]:candidate.append(v-vn*depth)
 for depth in [.4,.35,.44]:
  for u,y in [(0,0),(.08,0),(-.08,0),(0,.08),(0,-.08)]+list(itertools.product([-.18,-.1,.1,.18],repeat=2)):candidate.append(c-n*depth+ex*u+ey*y)
 found=None;support=[]
 for p in candidate:
  probes=[p]+[p+sgn*.008*np.eye(3)[axis] for axis in range(3) for sgn in [-1,1]]
  if not all(np.linalg.norm(v-c)<.4999 for v in probes):continue
  support=[owner for owner in owners if all(inside(owner,v) for v in probes)]
  if support:found=p;break
 checks.append({'bead':i,'accepted':found is not None,'witness_mm':found.tolist() if found is not None else None,'support_owners':support,'six_axis_probe_mm':.008})
 if found is None:print('NO_SUPPORT',i,bead['members'],flush=True)
 if i%30==0:print('CHECKED',i,flush=True)
result={'method':'Finite positive material-overlap proof: witness and six0.008mm axis neighbors inside a recorded gallery/S solid and radius0.5 sphere; native-derived exact CAD classifiers','beads':len(checks),'accepted':sum(c['accepted'] for c in checks),'failed':[c['bead'] for c in checks if not c['accepted']],'checks':checks};(D/'reflowed_bead_support_qa.json').write_text(json.dumps(result,indent=2));print('FINAL',result['accepted'],result['beads'],result['failed'])
