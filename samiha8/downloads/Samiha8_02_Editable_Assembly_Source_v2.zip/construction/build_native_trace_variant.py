import rhino3dm as r,numpy as np,math,json,hashlib,os
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parents[1];q=json.loads((D/'reference2_camera_and_trace.json').read_text());src=r.File3dm.Read(str(ROOT/'client-donors/10.3dm'));out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;out.Settings.ModelAbsoluteTolerance=.001
rr=np.array(q['right']);up=np.array(q['up']);di=np.array(q['direction']);fit=q['parameters'];ids=list(range(61,67));mesh=np.load(D/'native_leaf10.npz');records=[];ob=0;obj=open(D/'native_trace_crown.obj','w')
reference_heads={'left':[(233,207),(158,223),(179,260),(260,251),(210,295),(137,312),(99,277),(79,327)],'right':[(401,216),(509,252),(366,252),(471,288),(401,320),(480,374),(532,349),(546,423)]}
heads={'left':[(233,207,-10),(158,223,-30),(179,260,-14),(260,251,0),(210,295,0),(137,312,-18),(99,277,-50),(79,327,-60)],'right':[(401,216,12),(495,249,50),(369,257,-8),(462,283,45),(395,316,15),(470,367,40),(517,342,75),(532,409,75)]}
def sample(g):
 ps=[]
 for e in g.Edges:
  dom=e.Domain
  for tt in np.linspace(dom.T0,dom.T1,17):
   p=e.PointAt(float(tt));ps.append([p.X,p.Y,p.Z])
 return np.array(ps)
ps=sample(src.Objects[61].Geometry);centre=(ps.min(0)+ps.max(0))/2;th=math.atan2(centre[0],centre[2]);rot=np.array([[math.cos(-th),0,math.sin(-th)],[0,1,0],[-math.sin(-th),0,math.cos(-th)]]);local=(ps-centre)@rot.T;val,vec=np.linalg.eigh(local[:,:2].T@local[:,:2]);v=vec[:,-1];a=math.atan2(v[1],v[0]);Rhead=12.0
if os.environ.get('CLEAR_HEADS_ONLY'):
 heads['left']=heads['left'][:6];heads['right']=heads['right'][:7]
for side,entries in heads.items():
 layer=r.Layer();layer.Name=f'{side}_native_donor10_field';li=out.Layers.Add(layer)
 for number,(x,y,phideg) in enumerate(entries):
  ray=(x-fit[4])/fit[3]*rr-(y-fit[5])/fit[3]*up;aa=di[0]**2+di[2]**2;bb=2*(ray[0]*di[0]+ray[2]*di[2]);cc=ray[0]**2+ray[2]**2-Rhead**2;p=ray+(-bb+math.sqrt(bb*bb-4*aa*cc))/(2*aa)*di
  angle=math.atan2(p[0],p[2]);ex=np.array([math.cos(angle),0,-math.sin(angle)]);ey=np.array([0,1,0]);B=np.array([[rr@ex,rr@ey],[-up@ex,-up@ey]]);phi=math.radians(phideg);direction=np.linalg.solve(B,[math.cos(phi),math.sin(phi)]);dest=math.atan2(direction[1],direction[0]);turn=dest-a
  rz=np.array([[math.cos(turn),-math.sin(turn),0],[math.sin(turn),math.cos(turn),0],[0,0,1]]);ry=np.array([[math.cos(angle),0,math.sin(angle)],[0,1,0],[-math.sin(angle),0,math.cos(angle)]]);A=ry@rz@rot;b=p-A@centre;T=r.Transform.Identity()
  for i in range(3):
   for j in range(3):setattr(T,f'M{i}{j}',float(A[i,j]))
   setattr(T,f'M{i}3',float(b[i]))
  maxerr=0
  for idx in ids:
   g=src.Objects[idx].Geometry.Duplicate();g.Transform(T);at=r.ObjectAttributes();at.Name=f'{side}_{number:02d}_original10_object_{idx}';at.LayerIndex=li;out.Objects.Add(g,at)
   before=sample(src.Objects[idx].Geometry);after=sample(g);inv=(after-b)@A;maxerr=max(maxerr,float(np.linalg.norm(inv-before,axis=1).max()))
  vv=mesh['vertices']@A.T+b
  for w in vv:obj.write('v '+' '.join(map(str,w))+'\n')
  for tri in mesh['triangles']:obj.write('f '+' '.join(str(int(i)+1+ob) for i in tri)+'\n')
  ob+=len(vv)
  records.append({'field':side,'setting':number,'source_file':'10.3dm','source_sha256':hashlib.sha256((ROOT/'client-donors/10.3dm').read_bytes()).hexdigest(),'source_indices':ids,'source_object_ids':[str(src.Objects[i].Attributes.Id) for i in ids],'reference_pixel_center':reference_heads[side][number],'reference_identification_confidence':('high' if ((side=='left' and number<6) or (side=='right' and number<7)) else 'uncertain'),'target_pixel_center':[x,y],'manual_relayout_pixel_distance':float(np.linalg.norm(np.array([x,y])-reference_heads[side][number])),'target_pixel_long_axis_degrees':phideg,'head_center_mm':p.tolist(),'rigid_only':True,'scale':1.0,'matrix_rotation':A.tolist(),'translation_mm':b.tolist(),'inverse_rigid_edge_max_deviation_mm':maxerr})
layer=r.Layer();layer.Name='New_S_ribbon_from_two_traced_edges';li=out.Layers.Add(layer)
for o in r.File3dm.Read(str(D/'traced_S_ribbon.3dm')).Objects:
 at=r.ObjectAttributes();at.Name='Two_edge_traced_S_ribbon_crown_study';at.LayerIndex=li;out.Objects.Add(o.Geometry.Duplicate(),at)
for line in (D/'traced_S_ribbon.obj').read_text().splitlines():
 if line.startswith('f '):obj.write('f '+' '.join(str(int(i)+ob) for i in line.split()[1:])+'\n')
 else:obj.write(line+'\n')
obj.close();path=D/'native_trace_crown.3dm';assert out.Write(str(path),7);re=r.File3dm.Read(str(path));assert all(o.Geometry.IsValid and o.Geometry.IsSolid for o in re.Objects)
(D/'native_trace_crown.provenance.json').write_text(json.dumps({'status':'BEADLESS CROWN GEOMETRY STUDY; NOT A FINISHED RING OR MANUFACTURING RELEASE','method':'Native complete donor10 leaf settings rigidly oriented to manually identified visible reference heads. New ribbon uses both traced edges. No donor geometry stretched, cut, or replaced.','heads':len(records),'native_breps':len(re.Objects),'invalid':[],'open':[],'max_inverse_rigid_edge_deviation_mm':max(v['inverse_rigid_edge_max_deviation_mm'] for v in records),'objects':records,'unresolved':['Reference head identification includes partly occluded leaves and remains approximate.','No engineering claim for 25 mm width, EU62, 4 mm bottom, or gallery walls.','Donor setting rims alone do not supply the full deep peripheral shared skirt; new native skirts pending.','Ribbon-to-gallery and inter-setting contacts require validation.','1 mm beads omitted at this beadless visual gate.']},indent=2));print('Reopened valid closed Breps:',len(re.Objects))
