SAMIHA8 02 — EDITABLE NATIVE ASSEMBLY SOURCE

The top-level native reassembly is self-contained. It uses Python with rhino3dm 8.35.0; this package performs no downloads or installation.

Run: python assemble_design2.py

The result is Samiha8_02_Flowing_S_Rebuilt.3dm in Rhino 7 format, millimeters: 1,246 valid closed Breps, including 212 true 1 mm beads and 937 gallery flutes. The delivered core contains editable native geometry, layers and 13 setting groups. All rebuilt named geometry encodings are checked against the delivered model in the replay receipt. New object/file IDs are expected.

Edit components/qualified_ring_core.3dm directly in Rhino, or edit bead_plan.json and flute_instances.json before reassembly. Geometry changes require renewed dimensional, wall and contact checks. This is native Brep editability, not Rhino/MatrixGold command history or a manufacturing union.

construction/ contains the reference trace, placement and bead-planning source. These broader design scripts refer to the original project. construction/body_project/ is a portable subset for the final corrected shoulder, including the original qualified shoulder solids and the measured client-07 flow CSV. With the installed CadQuery/OCP, NumPy and SciPy environment, its build_flow_fitted_wall.py regenerates the revised CAD shoulder. The top-level native assembly needs only rhino3dm.

The latest shoulder keeps the original lower body and roof/floor surfaces, retracts the outer head behind the last gallery with a smooth flow-based curve, and closes that side with a true 0.2 mm normal profile offset. The head underlap remains intentionally open.
