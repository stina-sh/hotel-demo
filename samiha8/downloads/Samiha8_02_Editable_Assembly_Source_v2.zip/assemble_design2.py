"""Rebuild the native editable design2 from qualified native components.
Requires the official rhino3dm8.35.0 Python package; no downloads are performed.
"""
from pathlib import Path
import json,hashlib
import rhino3dm as r
ROOT=Path(__file__).resolve().parent
out=r.File3dm.Read(str(ROOT/'components/qualified_ring_core.3dm'))
source=r.File3dm.Read(str(ROOT/'components/canonical_leaf_flutes.3dm'))
layers={l.Name:i for i,l in enumerate(out.Layers)};groups={g.Name:i for i,g in enumerate(out.Groups)}
for rec in json.load(open(ROOT/'flute_instances.json')):
 T=r.Transform.Identity()
 for i in range(3):
  for j in range(3):setattr(T,f'M{i}{j}',rec['rotation'][i][j])
  setattr(T,f'M{i}3',rec['translation'][i])
 keep=set(rec['retained_rib_names'])
 for o in source.Objects:
  if o.Attributes.Name not in keep:continue
  geometry=o.Geometry.Duplicate();geometry.Transform(T);a=r.ObjectAttributes();a.Name=f'{rec["field"]}_{rec["setting"]:02d}_{o.Attributes.Name}';a.LayerIndex=layers['Native_0p13_decorative_gallery_fluting'];a.AddToGroup(groups[f'{rec["field"]}_setting_{rec["setting"]:02d}']);a.SetUserString('Role','Solid decorative flute; verified0.2mm hollow core unchanged');out.Objects.Add(geometry,a)
beads=json.load(open(ROOT/'bead_plan.json'))['beads']
for i,b in enumerate(beads):
 geometry=r.Sphere(r.Point3d(*b['center']),.5).ToBrep();a=r.ObjectAttributes();a.Name=f'True_1mm_bead_{i:03d}_{b["kind"]}';a.LayerIndex=layers['True_1mm_supported_beads'];a.SetUserString('Diameter_mm','1.0');a.SetUserString('RailMembership',json.dumps(b['members'],separators=(',',':')));out.Objects.Add(geometry,a)
path=ROOT/'Samiha8_02_Flowing_S_Rebuilt.3dm';assert out.Write(str(path),7);check=r.File3dm.Read(str(path));assert len(check.Objects)==1246;assert all(isinstance(o.Geometry,r.Brep) and o.Geometry.IsValid and o.Geometry.IsSolid for o in check.Objects)
receipt={'file':path.name,'native_breps':len(check.Objects),'valid_closed_breps':len(check.Objects),'mesh_objects':0,'units':str(check.Settings.ModelUnitSystem),'beads':len(beads),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'note':'New file/object IDs are expected. Compare named geometry encodings against the delivered model.'};(ROOT/'rebuild-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
