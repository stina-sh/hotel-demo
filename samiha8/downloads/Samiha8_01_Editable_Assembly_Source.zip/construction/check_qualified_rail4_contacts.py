"""Positive material witnesses for intended contacts between actual final-sized gallery solids."""
from pathlib import Path
import json,numpy as np,cadquery as cq,time
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.gp import gp_Trsf
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN
D=Path(__file__).resolve().parent;meta=json.loads((D/'sized25-settings/placements.json').read_text());nodes={}
def rigid(shape,M):
 t=gp_Trsf();t.SetValues(*[float(M[i][j]) for i in range(3) for j in range(4)]);return cq.Shape.cast(BRepBuilderAPI_Transform(shape.wrapped,t,True).Shape())
for rec in meta['groups']:
 if rec['setting']!='left_outer_lower':continue
 root=Path(rec['canonical_gallery_brep']).parent;P=np.array(rec['canonical_to_world_rigid']);parts=[];points=[]
 for name in ['footplate','skirt']:
  g=rigid(cq.Shape.importBrep(str(root/(name+'.brep'))),P);b=g.BoundingBox();parts.append({'shape':g,'cl':BRepClass3d_SolidClassifier(g.wrapped),'boundary':cq.Compound.makeCompound(g.Faces()),'min':np.array([b.xmin,b.ymin,b.zmin]),'max':np.array([b.xmax,b.ymax,b.zmax])})
  sam=json.loads((root/(name+'.wall-samples.json')).read_text())
  for q in sam:
   p=np.array(q['point_mm'])+np.array(q['inward_normal'])*.08;points.append((P@np.r_[p,1])[:3])
 nodes[rec['setting']]={'parts':parts,'points':np.array(points)}
for name in ['branch_4','lower_band']:
 root=D/'qualified-shank';g=cq.Shape.importBrep(str(root/(name+'.brep')));b=g.BoundingBox();sam=json.loads((root/(name+'.wall-samples.json')).read_text());points=[np.array(q['point_mm'])+np.array(q['inward_normal'])*.08 for q in sam];nodes[name]={'parts':[{'shape':g,'cl':BRepClass3d_SolidClassifier(g.wrapped),'boundary':cq.Compound.makeCompound(g.Faces()),'min':np.array([b.xmin,b.ymin,b.zmin]),'max':np.array([b.xmax,b.ymax,b.zmax])}],'points':np.array(points)}
def inside(part,p):
 if np.any(p<part['min']) or np.any(p>part['max']):return False
 part['cl'].Perform(cq.Vector(*p).toPnt(),1e-7);return part['cl'].State()==TopAbs_IN
pairs=[('branch_4','left_outer_lower'),('branch_4','lower_band')]
rows=[];probe=.004;offsets=[np.array([probe if k==axis else 0 for k in range(3)])*sgn for axis in range(3) for sgn in [-1,1]]
for an,bn in pairs:
 start=time.time();A,B=nodes[an],nodes[bn];found=[]
 for src,dst in [(A,B),(B,A)]:
  for p in src['points']:
   aa=next((x for x in src['parts'] if inside(x,p)),None);bb=next((x for x in dst['parts'] if inside(x,p)),None)
   if aa is None or bb is None:continue
   if not all(inside(x,p+off) for x in [aa,bb] for off in offsets):continue
   vertex=cq.Vertex.makeVertex(*p);dist=[vertex.distance(x['boundary']) for x in [aa,bb]]
   if min(dist)<probe:continue
   found.append({'point_mm':p.tolist(),'six_axis_probe_mm':probe,'boundary_clearances_mm':dist})
   if len(found)>=3:break
  if len(found)>=3:break
 row={'a':an,'b':bn,'positive_overlap_verified':bool(found),'strict_witness_count':len(found),'witnesses':found,'seconds':time.time()-start};rows.append(row);print(an,bn,len(found),flush=True);(D/'qualified-shank/rail4_strict_overlap_samples.json').write_text(json.dumps({'scope':'Finite strict positive-overlap witnesses in actual final-sized foot/skirt solids; no mesh Boolean operations. Every witness is strictly IN both closed components, has six .004mm neighboring probes IN both, and independent boundary clearance >=.004mm. Failure to find a sample is inconclusive until exact distance/contact followup.','pairs':rows},indent=2))

report={'checks':[{'target':r['b'],'positive_overlap':r['positive_overlap_verified'],'witnesses':r['witnesses']} for r in rows],'all_required_links_positive':all(r['positive_overlap_verified'] for r in rows)};(D/'qualified-shank/rail4_contact_qa.json').write_text(json.dumps(report,indent=2));assert report['all_required_links_positive']
