from pathlib import Path
import json,sys,subprocess,math,concurrent.futures
D=Path(__file__).resolve().parent;ROOT=D.parents[1];req=json.loads((D/'final_leaf_cap_requests.json').read_text());angle=math.asin(req['frame_rotation'][0][2]);results=[]
def run(row):
 name=row['setting'];out=D/'sized25-caps'/name;out.mkdir(parents=True,exist_ok=True)
 if (out/'cap.3dm').exists() and (out/'wall-qa.json').exists() and (out/'contact-and-cavity-qa.json').exists():
  w=json.loads((out/'wall-qa.json').read_text());c=json.loads((out/'contact-and-cavity-qa.json').read_text())
  if w.get('pass_finite_minimum_wall_check') and c.get('all_four_support_contacts_positive'):return {'name':name,'exit_code':0,'already_verified':True}
 commands=[
 [sys.executable,str(ROOT/'source/donor-preview/build_leaf_head_shell.py'),'--xy-scale',str(row['xy_scale']),'--z-scale',str(req['radial_z_scale']),'--z-pivot',str(req['z_pivot']),'--flat-rotation-y',str(angle),'--flat-translation-y',str(req['frame_y_translation']),'--output',str(out)],
 [sys.executable,str(ROOT/'source/donor-preview/check_leaf_head_walls.py'),str(out/'cap.brep'),'--output',str(out/'wall-qa.json')],
 [sys.executable,str(ROOT/'source/donor-preview/check_leaf_cap_contacts.py'),str(out)],
 [sys.executable,str(ROOT/'source/exporter/export_native.py'),str(out/'cap.brep'),str(out/'cap.3dm'),'--names-json',str(out/'components.json')]]
 for k,cmd in enumerate(commands):
  with open(out/f'step_{k}.log','w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:return {'name':name,'exit_code':r.returncode,'failed_step':k,'log':str(out/f'step_{k}.log')}
 return {'name':name,'exit_code':0}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 futures=[ex.submit(run,row) for row in req['requested_xy_scales']]
 for f in concurrent.futures.as_completed(futures):
  row=f.result();results.append(row);print(row,flush=True);(D/'sized25-caps/build-status.json').write_text(json.dumps(results,indent=2))
assert all(x['exit_code']==0 for x in results)
