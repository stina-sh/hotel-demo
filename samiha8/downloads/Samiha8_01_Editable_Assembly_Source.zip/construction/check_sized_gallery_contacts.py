"""Positive material witnesses for intended contacts between actual final-sized gallery solids."""
from pathlib import Path
import json,numpy as np,cadquery as cq,time
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.gp import gp_Trsf
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN
D=Path(__file__).resolve().parent;meta=json.loads((D/'sized25-settings/placements.json').read_text());nodes={}
def rigid(shape,M):
 t=gp_Trsf();t.SetValues(*[float(M[i][j]) for i in range(3) for j in range(4)]);return cq.Shape.cast(BRepBuilderAPI_Transform(shape.wrapped,t,True).Shape())
for rec in meta['groups']:
 root=Path(rec['canonical_gallery_brep']).parent;P=np.array(rec['canonical_to_world_rigid']);parts=[];points=[]
 for name in ['footplate','skirt']:
  g=rigid(cq.Shape.importBrep(str(root/(name+'.brep'))),P);b=g.BoundingBox();parts.append({'shape':g,'cl':BRepClass3d_SolidClassifier(g.wrapped),'boundary':cq.Compound.makeCompound(g.Faces()),'min':np.array([b.xmin,b.ymin,b.zmin]),'max':np.array([b.xmax,b.ymax,b.zmax])})
  sam=json.loads((root/(name+'.wall-samples.json')).read_text())
  for q in sam:
   p=np.array(q['point_mm'])+np.array(q['inward_normal'])*.08;points.append((P@np.r_[p,1])[:3])
 nodes[rec['setting']]={'parts':parts,'points':np.array(points)}
def inside(part,p):
 if np.any(p<part['min']) or np.any(p>part['max']):return False
 part['cl'].Perform(cq.Vector(*p).toPnt(),1e-7);return part['cl'].State()==TopAbs_IN
pairs=[('left_upper','left_inner_upper'),('left_inner_upper','left_middle'),('left_middle','left_lower'),('left_inner_upper','left_inner_lower'),('left_outer_lower','left_middle'),('right_inner_upper','right_upper'),('right_upper','right_outer'),('right_inner_upper','right_middle'),('right_inner_middle','right_middle'),('right_inner_middle','right_lower'),('right_lower','right_outer_lower'),('left_inner_upper','central_round_3'),('left_inner_lower','central_round_2'),('right_inner_upper','central_round_4'),('central_round_1','central_round_2'),('central_round_2','central_round_3'),('central_round_3','central_round_4'),('central_round_4','central_round_5')]
rows=[];probe=.004;offsets=[np.array([probe if k==axis else 0 for k in range(3)])*sgn for axis in range(3) for sgn in [-1,1]]
for an,bn in pairs:
 start=time.time();A,B=nodes[an],nodes[bn];found=[]
 for src,dst in [(A,B),(B,A)]:
  for p in src['points']:
   aa=next((x for x in src['parts'] if inside(x,p)),None);bb=next((x for x in dst['parts'] if inside(x,p)),None)
   if aa is None or bb is None:continue
   if not all(inside(x,p+off) for x in [aa,bb] for off in offsets):continue
   vertex=cq.Vertex.makeVertex(*p);dist=[vertex.distance(x['boundary']) for x in [aa,bb]]
   if min(dist)<probe:continue
   found.append({'point_mm':p.tolist(),'six_axis_probe_mm':probe,'boundary_clearances_mm':dist})
   if len(found)>=3:break
  if len(found)>=3:break
 row={'a':an,'b':bn,'positive_overlap_verified':bool(found),'strict_witness_count':len(found),'witnesses':found,'seconds':time.time()-start};rows.append(row);print(an,bn,len(found),flush=True);(D/'sized25-settings/inter_gallery_contact_qa.json').write_text(json.dumps({'scope':'Finite strict positive-overlap witnesses in actual final-sized foot/skirt solids; no mesh Boolean operations. Every witness is strictly IN both closed components, has six .004mm neighboring probes IN both, and independent boundary clearance >=.004mm. Failure to find a sample is inconclusive until exact distance/contact followup.','pairs':rows},indent=2))
