from pathlib import Path
import json,math,numpy as np,rhino3dm as r
from scipy.spatial import ConvexHull
D=Path(__file__).resolve().parent;old=json.loads((D/'design1_crown_v9.provenance.json').read_text());f=r.File3dm.Read(str(D/'design1_crown_v10.3dm'));meta=json.loads((D/'design1_crown_v10.provenance.json').read_text());q=1.7
heads={}
for rec in old['objects']:
 if rec.get('source_index') in [61,733]:heads[rec['name'].split('_original10')[0]]={'kind':rec['kind'],'old_head_centre':np.array(rec['target_head_centre_mm']),'source_record':rec}

def samples(g):
 pp=[]
 for e in g.Edges:
  d=e.Domain
  for t in np.linspace(d.T0,d.T1,33):
   p=e.PointAt(float(t));pp.append([p.X,p.Y,p.Z])
 return np.array(pp)
for name,a in heads.items():
 arrays=[]
 for ob,rec in zip(f.Objects,meta['objects']):
  if ob.Attributes.Name.startswith(name+'_') and rec.get('role')!='new_native_traced_sweep':arrays.append(samples(ob.Geometry))
 a['points']=np.concatenate(arrays)

def extent(k):
 mins=[];maxs=[]
 for name,a in heads.items():
  c=a['old_head_centre'];ys=(a['points'][:,1]-c[1])*q+c[1]*k;mins.append(ys.min());maxs.append(ys.max())
 return min(mins),max(maxs)
lo,hi=.5,2.5
for _ in range(70):
 k=(lo+hi)/2;mn,mx=extent(k)
 if mx-mn>24:hi=k
 else:lo=k
k=(lo+hi)/2;mn,mx=extent(k);shift=-(mn+mx)/2;print('Axial centre scale',k,'centre shift',shift,'gallery-body range',mn+shift,mx+shift)
results=[]
for phase_scale in [1.15,1.2,1.25,1.3,1.35]:
 entries=[];polys=[]
 for name,a in heads.items():
  c=a['old_head_centre'];theta=math.atan2(c[0],c[2]);newtheta=theta*phase_scale;R=12.7 if a['kind']=='leaf' else 12.5;dest=np.array([R*math.sin(newtheta),c[1]*k+shift,R*math.cos(newtheta)]);da=newtheta-theta;rot=np.array([[math.cos(da),0,math.sin(da)],[0,1,0],[-math.sin(da),0,math.cos(da)]]);A=q*rot;b=dest-A@c;T=np.eye(4);T[:3,:3]=A;T[:3,3]=b
  entry={'setting':name,'kind':a['kind'],'old_head_centre_mm':c.tolist(),'head_centre_mm':dest.tolist(),'uniform_local_study_scale':q,'old_phase':theta,'new_phase':newtheta,'phase_expansion':phase_scale,'axial_centre_scale':k,'axial_shift_mm':shift,'v10_to_sized_study':T.tolist()};entries.append(entry)
  if a['kind']=='leaf':
   ob=next(o for o in f.Objects if o.Attributes.Name==name+'_original10_object61');ps=samples(ob.Geometry)@A.T+b;uv=np.c_[np.arctan2(ps[:,0],ps[:,2])*12.7,ps[:,1]];h=ConvexHull(uv);polys.append((name,uv[h.vertices]))
 collisions=[]
 for i,(n,a) in enumerate(polys):
  for nn,b in polys[i+1:]:
   ed=np.vstack([np.roll(a,-1,axis=0)-a,np.roll(b,-1,axis=0)-b]);ax=np.c_[-ed[:,1],ed[:,0]];ax/=np.linalg.norm(ax,axis=1)[:,None];aa=a@ax.T;bb=b@ax.T;sep=max(np.max(aa.min(0)-bb.max(0)),np.max(bb.min(0)-aa.max(0)))
   if sep<.02:collisions.append({'a':n,'b':nn,'convex_unrolled_separation_mm':float(sep)})
 results.append({'phase_expansion':phase_scale,'leaf_cap_close_pairs':collisions,'placements':entries});print(phase_scale,collisions)
chosen=next(x for x in results if x['phase_expansion']==1.25);output={'status':'FINAL-SIZE PLACEMENT PLAN; .2MM NORMAL GEOMETRY MUST BE REBUILT AFTER LOCAL SIZING','body_axial_target_mm':24,'supported_bead_extrema_target_mm':25,'bead_diameter_mm':1,'leaf_head_radius_mm':12.7,'round_head_radius_mm':12.5,'uniform_local_study_scale':q,'phase_expansion':chosen['phase_expansion'],'axial_centre_scale':k,'axial_shift_mm':shift,'cap_proximity_studies':[{k:v for k,v in x.items() if k!='placements'} for x in results],'placements':chosen['placements']};(D/'sized25_placement_plan.json').write_text(json.dumps(output,indent=2))
