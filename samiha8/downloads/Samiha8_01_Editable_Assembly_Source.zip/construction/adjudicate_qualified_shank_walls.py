"""Retain standalone wall results and check interfaces/replay ambiguous exits explicitly."""
from pathlib import Path
import json,cadquery as cq,hashlib
from OCP.BRep import BRep_Tool
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
from OCP.TopAbs import TopAbs_IN,TopAbs_OUT
from OCP.gp import gp_Lin,gp_Dir
D=Path(__file__).resolve().parent/'qualified-shank';raw=json.loads((D/'wall-qa.json').read_text());shapes={r['part']:cq.Shape.importBrep(str(D/(r['part']+'.brep'))) for r in raw['parts']};classifiers={n:BRepClass3d_SolidClassifier(s.wrapped) for n,s in shapes.items()};boundaries={n:cq.Compound.makeCompound(s.Faces()) for n,s in shapes.items()};rows=[]
def state(name,p):
 classifiers[name].Perform(p.toPnt(),1e-7);return classifiers[name].State()
def buried(name,p):
 found=[]
 for n in shapes:
  if n==name or state(n,p)!=TopAbs_IN:continue
  clearance=cq.Vertex.makeVertex(*p.toTuple()).distance(boundaries[n]);probe=.004
  if clearance<probe:continue
  probes=[p+cq.Vector(*[sgn*probe if j==i else 0 for j in range(3)]) for i in range(3) for sgn in [-1,1]]
  if all(state(n,q)==TopAbs_IN for q in probes):found.append({'covering_part':n,'boundary_clearance_mm':clearance,'six_axis_strict_IN_probe_mm':probe})
 return found
for part in raw['parts']:
 name=part['part'];shape=shapes[name];thin=[];replays=[];ray=IntCurvesFace_ShapeIntersector();ray.Load(shape.wrapped,1e-7)
 for rec in part['under_nominal_samples']:
  p=cq.Vector(*rec['point_mm']);covered=buried(name,p);thin.append({**rec,'strict_burial_evidence':covered,'is_exposed_under_nominal':not bool(covered)})
 for rec in part['no_exit']:
  f=shape.Faces()[rec['face']];p=f.positionAt(rec['u'],rec['v']);sf=BRep_Tool.Surface_s(f.wrapped);prop=GeomLProp_SLProps(sf,rec['u'],rec['v'],1,1e-9);nn=prop.Normal();n=cq.Vector(nn.X(),nn.Y(),nn.Z());covered=buried(name,p)
  if state(name,p-n*.015)==TopAbs_IN:n=-n
  assert state(name,p+n*.015)==TopAbs_IN
  ray.Perform(gp_Lin(p.toPnt(),gp_Dir(n.x,n.y,n.z)),1e-5,50);hits=sorted(ray.WParameter(k) for k in range(1,ray.NbPnt()+1) if ray.WParameter(k)>1e-4);attempts=[];exit_hit=None
  for h in hits:
   a,b=state(name,p+n*(h-.00003)),state(name,p+n*(h+.00003));attempts.append({'analytic_hit_mm':h,'before':str(a),'after':str(b)})
   if a==TopAbs_IN and b==TopAbs_OUT:exit_hit=h;break
  replays.append({'sample':rec,'point_mm':p.toTuple(),'unchanged_analytic_exit_mm':exit_hit,'explicit_classification_probe_mm':.00003,'strict_burial_evidence':covered,'attempts':attempts,'resolved':bool(covered) or (exit_hit is not None and exit_hit>=.2-1e-5)})
 passed=part['valid'] and part['closed_solids']==1 and not part['xor_rejections'] and all(f['samples']>0 for f in part['faces']) and all(not r['is_exposed_under_nominal'] for r in thin) and all(r['resolved'] for r in replays)
 row={'part':name,'sha256':hashlib.sha256((D/(name+'.brep')).read_bytes()).hexdigest(),'original_standalone_sample_count':part['sample_count'],'original_standalone_minimum_mm':part['minimum_mm'],'original_wall_receipt_retained':str(D/'wall-qa.json'),'under_nominal_adjudications':thin,'no_exit_replays':replays,'pass_exposed_finite_wall_checks_with_recorded_interfaces':passed};rows.append(row);print(name,passed,flush=True)
report={'scope':'Finite sampled normal walls of this four-part shank assembly, not a global minimum-wall proof. Standalone under-nominal cap/rim rays are treated as internal interfaces only where the sample has strict IN classification in another closed part, six 0.004 mm neighboring IN probes and >=0.004 mm boundary clearance. No raw samples or geometry were altered. Ambiguous exits are replayed with unchanged analytic hit distances and explicit +/-0.00003 mm classification probes, distinct from unchanged 0.00001 mm wall allowance.','nominal_wall_mm':.2,'numerical_wall_allowance_mm':1e-5,'parts':rows,'all_pass':all(r['pass_exposed_finite_wall_checks_with_recorded_interfaces'] for r in rows)};(D/'assembly-wall-adjudication.json').write_text(json.dumps(report,indent=2));assert report['all_pass']
