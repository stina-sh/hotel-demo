from pathlib import Path
import rhino3dm as r,numpy as np,json,math,hashlib
D=Path(__file__).resolve().parent;ROOT=D.parents[1];OUT=D/'sized25-settings';OUT.mkdir(exist_ok=True);original=r.File3dm.Read(str(ROOT/'client-donors/10.3dm'));old=json.loads((D/'design1_crown_v9.provenance.json').read_text());plan=json.loads((D/'sized25_placement_plan.json').read_text());out=r.File3dm();out.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;out.Settings.ModelAbsoluteTolerance=.001;rows=[];groups=[]
def multiply(ts):
 M=np.eye(4)
 for a in ts:M=np.array(a)@M
 return M
def tr(M):
 t=r.Transform.Identity()
 for i in range(4):
  for j in range(4):setattr(t,f'M{i}{j}',float(M[i,j]))
 return t
def base_C(fr,xy,zs,pivot):
 a=-fr['source_polar_angle'];C=np.eye(4);C[:3,:3]=[[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]];C[1,3]=-fr['centre'][1];S=np.diag([xy,xy,zs,1.]);S[2,3]=pivot*(1-zs);return S@C
for place in plan['placements']:
 name=place['setting'];kind=place['kind'];base=next(x for x in old['objects'] if x.get('source_index')==(61 if kind=='leaf' else 733) and x['name'].split('_original10')[0]==name);desired=np.array(place['v10_to_sized_study'])@multiply(base['transform_matrices']);capdir=D/'sized25-caps'/name if kind=='leaf' else ROOT/'rebuild-v3/canonical-galleries/round_cap_scale1p7';galdir=D/'sized25-galleries'/name if kind=='leaf' else ROOT/'rebuild-v3/canonical-galleries/round_scale1p7';cb=json.loads((capdir/'build-qa.json').read_text());gb=json.loads((galdir/'build-qa.json').read_text());C=np.array(cb['source_to_canonical_matrix']) if kind=='leaf' else base_C(gb['frame'],1.7,1.7,11.);P=desired@np.linalg.inv(C);u,s,v=np.linalg.svd(P[:3,:3]);before=P[:3,:3].copy();P[:3,:3]=u@v;corr=float(np.max(np.abs(before-P[:3,:3])));assert corr<1e-6;supportM=P@C;li_layer=r.Layer();li_layer.Name=name;li=out.Layers.Add(li_layer);group_records=[]
 def add(g,label,receipt):
  assert g.IsValid and g.IsSolid;at=r.ObjectAttributes();at.Name=name+'_'+label;at.LayerIndex=li;out.Objects.Add(g,at);row={'name':at.Name,'setting':name,'kind':kind,'native_valid':g.IsValid,'native_solid':g.IsSolid,'faces':len(g.Faces),**receipt};rows.append(row);group_records.append(row)
 capfile=capdir/'cap.3dm';f=r.File3dm.Read(str(capfile));assert len(f.Objects)==1
 for k,ob in enumerate(f.Objects):
  g=ob.Geometry.Duplicate();g.Transform(tr(P));add(g,'hollow_native_cap',{'role':'cap','canonical_file':str(capfile),'canonical_index':k,'rigid_transform':P.tolist(),'normal_wall_mm':.2,'wall_receipt':str(capdir/'wall-qa.json'),'support_receipt':str(capdir/('contact-and-cavity-qa.json' if kind=='leaf' else 'support-contact-qa.json'))})
 supports=[62,63,64,65] if kind=='leaf' else[751,752,753,754]
 for idx in supports:
  g=original.Objects[idx].Geometry.Duplicate();g.Transform(tr(supportM));add(g,f'original10_support_{idx}',{'role':'support','source_file':'10.3dm','source_index':idx,'source_object_id':str(original.Objects[idx].Attributes.Id),'source_transform':supportM.tolist(),'source_geometry_retained_under_recorded_local_sizing':True})
 galfile=galdir/'gallery.3dm';f=r.File3dm.Read(str(galfile));assert len(f.Objects)==2
 for k,ob in enumerate(f.Objects):
  g=ob.Geometry.Duplicate();g.Transform(tr(P));add(g,ob.Attributes.Name,{'role':'gallery','canonical_file':str(galfile),'canonical_index':k,'rigid_transform':P.tolist(),'normal_wall_mm':.2,'wall_receipt':str(galdir/'wall-qa.json'),'support_receipt':str(galdir/'build-qa.json')})
 wall=json.loads((capdir/'wall-qa.json').read_text());cap_pass=wall.get('pass_finite_minimum_wall_check',wall.get('pass_finite_wall_checks',False));groups.append({'setting':name,'kind':kind,'head_centre_mm':place['head_centre_mm'],'target_phase':place['new_phase'],'canonical_cap_brep':str(capdir/'cap.brep'),'canonical_gallery_brep':str(galdir/'gallery.brep'),'canonical_rim_top_brep':str(galdir/('retained_expanded_top.brep' if kind=='leaf' else 'retained_top.brep')),'canonical_to_world_rigid':P.tolist(),'source_to_world_supports':supportM.tolist(),'source_support_indices':supports,'rigid_matrix_rounding_correction_max':corr,'cap_wall_check_pass':cap_pass,'source_controlled_support_directory':str(ROOT/'rebuild-v3/canonical-galleries'),'placement':place})
p=OUT/'settings_native.3dm';assert out.Write(str(p),7);re=r.File3dm.Read(str(p));assert len(re.Objects)==133 and all(o.Geometry.IsValid and o.Geometry.IsSolid for o in re.Objects);report={'status':'FINAL-SIZED NATIVE SETTINGS; FULL-RING INTEGRATION AND FINAL QA PENDING','native_objects':len(re.Objects),'leaf_heads':14,'round_heads':5,'body_axial_target_mm':24,'sphere_extrema_target_mm':25,'bead_diameter_mm':1,'remaining_cap_wall_flags':[x['setting'] for x in groups if not x['cap_wall_check_pass']],'groups':groups,'objects':rows};(OUT/'placements.json').write_text(json.dumps(report,indent=2));print(p,len(re.Objects),report['remaining_cap_wall_flags'])
