from pathlib import Path
import sys,json,argparse,subprocess,math
import cadquery as cq
from OCP.BRep import BRep_Tool
from OCP.BRepProj import BRepProj_Projection
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace,BRepBuilderAPI_MakeEdge
from OCP.BRepOffsetAPI import BRepOffsetAPI_MakeThickSolid
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.gp import gp_Dir,gp_Pnt,gp_Vec
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
from OCP.Geom import Geom_TrimmedCurve
D=Path(__file__).resolve().parent;ROOT=D.parents[1];sys.path.insert(0,str(ROOT/'source/donor-preview'))
from build_canonical_gallery import first_native_face,canonical,frame,positive,max_tol,volume,leaf_skirt,overlap_witnesses,mesh_obj

def expanded_leaf_skirt(top,wall,depth,overlap):
 edges=[]
 for e in top.outerWire().Edges():
  c=BRep_Tool.Curve_s(e.wrapped,0.,0.).Copy()
  while isinstance(c,Geom_TrimmedCurve):c=c.BasisCurve().Copy()
  assert hasattr(c,'NbPoles'),type(c)
  for i in range(1,c.NbPoles()+1):p=c.Pole(i);c.SetPole(i,gp_Pnt(p.X(),p.Y(),0))
  a,b=BRep_Tool.Range_s(e.wrapped);ee=BRepBuilderAPI_MakeEdge(c,a,b).Edge();ee.Orientation(e.wrapped.Orientation());edges.append(cq.Edge(ee))
 flat=cq.Wire.assembleEdges(edges);insets=flat.offset2D(-wall,'intersection');assert len(insets)==1;projection=BRepProj_Projection(insets[0].wrapped,top.wrapped,gp_Dir(0,0,1));assert projection.IsDone();inner=cq.Wire(projection.Current());projection.Next();assert not projection.More();sf=BRep_Tool.Surface_s(top.wrapped);mk=BRepBuilderAPI_MakeFace(sf,top.outerWire().wrapped,True);inner.wrapped.Reverse();mk.Add(inner.wrapped);annulus=cq.Face(mk.Face());assert annulus.isValid();return positive(cq.Shape.cast(BRepPrimAPI_MakePrism(annulus.wrapped,gp_Vec(0,0,-depth),False,False).Shape()).translate((0,0,-overlap)))

def run(name):
 plan=json.loads((D/'gallery_expansion_plan.json').read_text());rec=next(x for x in plan['source_groups'] if x['setting_name']==name);request=json.loads((D/'final_leaf_cap_requests.json').read_text());qscale=request['radial_z_scale'];pivot=request['z_pivot'];s=rec['tangent_xy_scale']*qscale;factor=rec['outer_xy_factor'];out=D/'sized25-galleries'/name;out.mkdir(parents=True,exist_ok=True)
 raw,err=first_native_face(ROOT/'rebuild-v3/canonical-galleries/leaf_scale1p0/source.faces');fr=frame('leaf');fr['source_polar_angle']=-math.asin(request['frame_rotation'][0][2]);fr['centre'][1]=-request['frame_y_translation'];base=canonical(raw,fr,1.);xy=cq.Matrix([[s,0,0,0],[0,s,0,0],[0,0,qscale,pivot*(1-qscale)],[0,0,0,1]]);top=base.transformGeometry(xy);oldinner=top.innerWires()[0];big=top.transformGeometry(cq.Matrix([[factor,0,0,0],[0,factor,0,0],[0,0,1,0],[0,0,0,1]]));surf=BRep_Tool.Surface_s(big.wrapped);full=cq.Face(BRepBuilderAPI_MakeFace(surf,big.outerWire().wrapped,True).Face());proj=BRepProj_Projection(oldinner.wrapped,full.wrapped,gp_Dir(0,0,1));assert proj.IsDone();inner=proj.Current();proj.Next();assert not proj.More();mk=BRepBuilderAPI_MakeFace(surf,big.outerWire().wrapped,True);mk.Add(inner);nt=cq.Face(mk.Face());assert nt.isValid()
 if nt.normalAt().z<0:nt.wrapped.Reverse()
 thick=BRepOffsetAPI_MakeThickSolid();thick.MakeThickSolidBySimple(nt.wrapped,-.2);foot=positive(cq.Shape.cast(thick.Shape()));skirt=expanded_leaf_skirt(nt,.2,.9,.05);parts=[('Donor10_expanded_footplate_0p2',foot),('Donor10_expanded_skirt_0p2',skirt)]
 for label,shape in parts:assert shape.isValid() and len(shape.Solids())==1 and max_tol(shape)<.001,(name,label,max_tol(shape))
 contact=overlap_witnesses(nt,foot,skirt,.2);assert contact['accepted']>=8,(name,contact['accepted']);supports=[]
 for idx in [62,63,64,65]:
  q=canonical(cq.Shape.importBrep(str(ROOT/f'rebuild-v3/canonical-galleries/support{idx}_controlled.brep')),fr,1.).transformGeometry(xy);com=q.intersect(foot);dist=BRepExtrema_DistShapeShape(q.wrapped,foot.wrapped);dist.Perform();item={'source_support':idx,'common_valid':com.isValid(),'common_volume_mm3':volume(com),'distance_mm':dist.Value()};supports.append(item);assert item['common_valid'] and item['common_volume_mm3']>1e-7,item
 foot.exportBrep(str(out/'footplate.brep'));skirt.exportBrep(str(out/'skirt.brep'));nt.exportBrep(str(out/'retained_expanded_top.brep'));compound=cq.Compound.makeCompound([foot,skirt]);compound.exportBrep(str(out/'gallery.brep'));mesh_obj(parts,out/'gallery.obj');(out/'components.json').write_text(json.dumps({'objects':[{'name':n} for n,s in parts]}));qa={'status':'CONTROLLED DONOR-DERIVED OUTER GALLERY EXPANSION; NOT AN EXACT SOURCE IMPORT','source_gallery':66,'setting_name':name,'source_canonical_frame':fr,'setting_xy_scale':s,'radial_height_scale':qscale,'z_pivot':pivot,'outer_xy_factor':factor,'native_inner_xy_footprint_preserved':True,'native_inner_z_reprojected':True,'normal_wall_requested_mm':.2,'skirt_depth_mm':.9,'skirt_top_drop_mm':.05,'parts':[{'name':n,'valid':a.isValid(),'solids':len(a.Solids()),'volume_mm3':volume(a),'max_topological_tolerance_mm':max_tol(a)} for n,a in parts],'footplate_skirt_contact':contact,'source_support_contacts':supports,'all_four_prong_contacts_positive':True,'crown_contact_checks_pending':True};(out/'build-qa.json').write_text(json.dumps(qa,indent=2))
 with open(out/'native-export.log','w') as log:subprocess.run([sys.executable,str(ROOT/'source/exporter/export_native.py'),str(out/'gallery.brep'),str(out/'gallery.3dm'),'--names-json',str(out/'components.json')],stdout=log,stderr=subprocess.STDOUT,check=True)
 with open(out/'wall-check.log','w') as log:subprocess.run([sys.executable,str(ROOT/'source/donor-preview/check_canonical_gallery.py'),str(out),'--dense'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'READY',flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('name');args=ap.parse_args();run(args.name)
