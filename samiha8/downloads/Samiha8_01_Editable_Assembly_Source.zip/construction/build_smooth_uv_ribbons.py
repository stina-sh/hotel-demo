from pathlib import Path
import sys,json,math,numpy as np
import cadquery as cq
from scipy.interpolate import splprep,splev
from OCP.Geom import Geom_CylindricalSurface
from OCP.Geom2dAPI import Geom2dAPI_Interpolate
from OCP.TColgp import TColgp_HArray1OfPnt2d
from OCP.gp import gp_Pnt2d,gp_Pnt,gp_Dir,gp_Ax3
from OCP.GCE2d import GCE2d_MakeSegment
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge,BRepBuilderAPI_MakeWire,BRepBuilderAPI_MakeFace
from OCP.BRepOffsetAPI import BRepOffsetAPI_MakeThickSolid
from OCP.BRepLib import BRepLib
D=Path(__file__).resolve().parent;ROOT=D.parents[1];sys.path.insert(0,str(ROOT/'source/donor-preview'))
from build_canonical_gallery import positive,max_tol,mesh_obj,volume
plan=json.loads((D/'sized25_placement_plan.json').read_text());old=json.loads((D/'traced_ribbons_v9.provenance.json').read_text());R=11.5;OUT=D/'sized25-ribbons-final';OUT.mkdir(exist_ok=True);surf=Geom_CylindricalSurface(gp_Ax3(gp_Pnt(0,0,0),gp_Dir(0,1,0),gp_Dir(0,0,-1)),R);parts=[];rows=[]
def curve(p):
 a=TColgp_HArray1OfPnt2d(1,len(p))
 for i,q in enumerate(p,1):a.SetValue(i,gp_Pnt2d(q[0]/R+math.pi,q[1]))
 m=Geom2dAPI_Interpolate(a,False,1e-9);m.Perform();assert m.IsDone();return m.Curve()
def segment(a,b):return GCE2d_MakeSegment(gp_Pnt2d(a[0]/R+math.pi,a[1]),gp_Pnt2d(b[0]/R+math.pi,b[1])).Value()
def crossing_count(poly):
 a=poly;b=np.roll(poly,-1,axis=0);count=0
 for i in range(len(poly)):
  for j in range(i+2,len(poly)):
   if i==0 and j==len(poly)-1:continue
   ab=b[i]-a[i];cd=b[j]-a[j];cross=lambda x,y:x[0]*y[1]-x[1]*y[0]
   if cross(ab,a[j]-a[i])*cross(ab,b[j]-a[i])<-1e-12 and cross(cd,a[i]-a[j])*cross(cd,b[i]-a[j])<-1e-12:count+=1
 return count
for number,rec in enumerate(old,1):
 xyz=np.array(rec['world_centreline_points']);uv=np.c_[np.arctan2(xyz[:,0],xyz[:,2])*plan['phase_expansion']*R,xyz[:,1]*plan['axial_centre_scale']+plan['axial_shift_mm']];success=False
 for smooth in [.05,.2,.6,1.2,2.0,3.0]:
  tck,params=splprep(uv.T,s=smooth,k=3);tt=np.linspace(0,1,121);pp=np.array(splev(tt,tck)).T;dd=np.array(splev(tt,tck,der=1)).T;normal=np.c_[-dd[:,1],dd[:,0]];normal/=np.linalg.norm(normal,axis=1)[:,None];width=2.35-.25*np.abs(np.linspace(-1,1,len(pp)))**2;left=pp-normal*width[:,None]*.5;right=pp+normal*width[:,None]*.5;poly=np.vstack([left,right[::-1]])
  if crossing_count(poly):continue
  crvs=[curve(left),segment(left[-1],right[-1]),curve(right[::-1]),segment(right[0],left[0])];mw=BRepBuilderAPI_MakeWire()
  for c in crvs:
   me=BRepBuilderAPI_MakeEdge(c,surf,c.FirstParameter(),c.LastParameter());assert me.IsDone();mw.Add(me.Edge())
  if not mw.IsDone():continue
  mf=BRepBuilderAPI_MakeFace(surf,mw.Wire(),True);top=cq.Face(mf.Face());BRepLib.BuildCurves3d_s(top.wrapped,1e-7)
  if not top.isValid():continue
  p=top.Center()
  if top.normalAt(p).dot(cq.Vector(p.x,0,p.z))<0:top.wrapped.Reverse()
  mk=BRepOffsetAPI_MakeThickSolid();mk.MakeThickSolidBySimple(top.wrapped,-.2);shape=positive(cq.Shape.cast(mk.Shape()));print('attempt',number,smooth,shape.isValid(),len(shape.Solids()),max_tol(shape),flush=True)
  if not(shape.isValid() and len(shape.Solids())==1 and max_tol(shape)<.001):continue
  vv,_=shape.tessellate(.035,.12);vs=np.array([v.toTuple() for v in vv]);assert np.max(np.abs(vs))<18;sub=OUT/f'ribbon_{number}';sub.mkdir(exist_ok=True);shape.exportBrep(str(sub/'footplate.brep'));top.exportBrep(str(sub/'top_surface.brep'));parts.append((f'Smooth_opposed_ribbon_{number}',shape));fitted=np.array(splev(params,tck)).T;rows.append({'ribbon':number,'radius_mm':R,'normal_wall_mm':.2,'curve_smoothing_parameter':smooth,'source_landmark_uv_max_adjustment_mm':float(np.max(np.linalg.norm(fitted-uv,axis=1))),'source_unrolled_landmarks':uv.tolist(),'smooth_left_unrolled':left.tolist(),'smooth_right_unrolled':right.tolist(),'closed_valid_solid':True,'faces':len(shape.Faces()),'max_topology_tolerance_mm':max_tol(shape),'volume_mm3':volume(shape),'sampled_bounds':[vs.min(0).tolist(),vs.max(0).tolist()],'shoulder_end_fairing_pending':True});success=True;print(rows[-1]['sampled_bounds'],flush=True);break
 assert success,number
cq.Compound.makeCompound([g for n,g in parts]).exportBrep(str(OUT/'ribbons.brep'));mesh_obj(parts,OUT/'ribbons.obj');(OUT/'components.json').write_text(json.dumps({'objects':[{'name':n} for n,g in parts]}));(OUT/'build-qa.json').write_text(json.dumps({'status':'SMOOTH SIZED NORMAL-WALL CROWN RIBBONS; END FAIRING PENDING','method':'Reference-derived centreline landmarks faired in the cylindrical development to remove self-crossing trim loops, with a controlled polished width and exact normal cylinder offset','pieces':rows},indent=2))
