from pathlib import Path
import json,hashlib,argparse
D=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--rail4-qa',type=Path,required=True);a=p.parse_args();edges=[]
def edge(x,y,path,evidence):edges.append({'a':x,'b':y,'receipt':str(path),'evidence':evidence})
p1=D/'sized25-settings/inter_gallery_contact_qa.json'
for r in json.loads(p1.read_text())['pairs']:
 if r['positive_overlap_verified']:edge(r['a'],r['b'],p1,'strict positive overlap with six 0.004 mm probes and independent boundary clearance')
p2=D/'sized25-settings/upper_round_final_ribbon_witnesses.json'
for r in json.loads(p2.read_text())['pairs']:
 if r['positive_overlap_verified']:edge(r['a'],r['b'],p2,'strict positive overlap with six 0.004 mm probes and independent boundary clearance')
p3=D/'end-fairing/independent-qa/collar-matched/strict-witnesses.json'
for r in json.loads(p3.read_text())['checks']:
 assert r['pass_contact'];edge(r['a'],r['b'].replace('left_outer_lower_gallery','left_outer_lower'),p3,'strict positive overlap on final trimmed ribbon/continuation boundaries')
p4=D/'positive-faired-shank/gallery_and_band_contact_qa.json'
for r in json.loads(p4.read_text())['pairs']:
 if r['rail'] in [1,3]:
  assert r['positive_overlap'];edge('gallery_rail_'+str(r['rail']),r['target'],p4,'valid positive-volume exact CAD common')
q=json.loads(a.rail4_qa.read_text())
assert q['all_required_links_positive']
for r in q['checks']:edge('gallery_rail_4',r['target'],a.rail4_qa,'strict positive material overlap on repaired rail 4')
nodes=[g['setting'] for g in json.loads((D/'sized25-settings/placements.json').read_text())['groups']]+['gallery_rail_1','gallery_rail_3','gallery_rail_4','lower_band','ribbon_1_trimmed','ribbon_2_trimmed','ribbon_1_end_1_continuation','ribbon_2_end_0_continuation','ribbon_2_end_1_continuation'];adj={n:set() for n in nodes}
for e in edges:adj[e['a']].add(e['b']);adj[e['b']].add(e['a'])
remaining=set(nodes);components=[]
while remaining:
 seed=next(iter(remaining));seen={seed};stack=[seed]
 while stack:
  n=stack.pop()
  for m in adj[n]-seen:seen.add(m);stack.append(m)
 remaining-=seen;components.append(sorted(seen))
q={'scope':'Structural component graph at logical setting level. Each setting internally qualifies cap/support/gallery and foot/skirt contacts separately; beads and flutes are independently verified attachments. This graph proves positive material connectivity, not fused topology or manufacturing certification.','structural_node_count':len(nodes),'positive_contact_edge_count':len(edges),'components':components,'single_connected_structure':len(components)==1,'edges':edges};(D/'structural_contact_graph.json').write_text(json.dumps(q,indent=2));print(q['structural_node_count'],q['positive_contact_edge_count'],q['components']);assert q['single_connected_structure']
