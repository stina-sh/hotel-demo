#!/usr/bin/env python3
"""True normal-offset hollow source61 head, explicit trimmed intersection topology.
Preserves the source outer top/side surfaces. Reconstructs the underside rim and
inner offset faces; controlled geometry, not an exact native source import.
"""
import cadquery as cq,numpy as np,json,math,argparse,hashlib
from pathlib import Path
from OCP.BRep import BRep_Tool,BRep_Builder
from OCP.Geom import Geom_OffsetSurface
from OCP.GeomInt import GeomInt_IntSS
from OCP.GeomAPI import GeomAPI_IntCS,GeomAPI_ProjectPointOnCurve
from OCP.GeomLib import GeomLib
from OCP.gp import gp_Pnt
from OCP.TColStd import TColStd_Array1OfReal
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge,BRepBuilderAPI_MakeWire,BRepBuilderAPI_MakeFace,BRepBuilderAPI_Sewing,BRepBuilderAPI_MakeSolid
from OCP.ShapeAnalysis import ShapeAnalysis_FreeBounds
from OCP.BRepLib import BRepLib
from OCP.TopAbs import TopAbs_FORWARD,TopAbs_REVERSED
from build_canonical_gallery import ROOT,frame,max_tol,volume,mesh_obj
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--scale',type=float,default=1.7);p.add_argument('--xy-scale',type=float);p.add_argument('--z-scale',type=float);p.add_argument('--z-pivot',type=float,default=11.);p.add_argument('--flat-rotation-y',type=float);p.add_argument('--flat-translation-y',type=float);p.add_argument('--wall',type=float,default=.2);p.add_argument('--output',type=Path,required=True);args=p.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True);construction=out/'construction_reference';construction.mkdir(exist_ok=True);fr=frame('leaf');xy=args.xy_scale if args.xy_scale is not None else args.scale;zs=args.z_scale if args.z_scale is not None else args.scale;angle=args.flat_rotation_y if args.flat_rotation_y is not None else -fr['source_polar_angle'];yt=args.flat_translation_y if args.flat_translation_y is not None else -fr['centre'][1];c,ss=math.cos(angle),math.sin(angle);matrix=[[xy*c,0,xy*ss,0],[0,xy,0,xy*yt],[-zs*ss,0,zs*c,args.z_pivot*(1-zs)],[0,0,0,1]]
original_path=ROOT/'rebuild-v3/canonical-galleries/support61_controlled.brep';original=cq.Shape.importBrep(str(original_path)).transformGeometry(cq.Matrix(matrix));outer_faces=original.Faces()[:3];outer=cq.Shell.makeShell(outer_faces);free=cq.Shape.cast(ShapeAnalysis_FreeBounds(outer.wrapped,1e-5,False,False).GetClosedWires()).Wires();assert len(free)==1
bottom=cq.Face.makeNSidedSurface(free[0].Edges(),[],tol3d=1e-6,maxDeg=12,maxSegments=32);envshell=cq.Shell.makeShell(outer_faces+[bottom]);envelope=cq.Solid(BRepBuilderAPI_MakeSolid(envshell.wrapped).Solid()).fix();BRepLib.OrientClosedSolid_s(envelope.wrapped);assert envelope.isValid() and max_tol(envelope)<.001;envelope.exportBrep(str(construction/'outer_envelope.brep'));extension_witnesses=[]
def extend_v(base,h=.5):
 assert base.NbVPoles()==4 and base.VDegree()==3 and base.NbVKnots()==2
 old=base.Copy();a=-h;b=1+2*h
 for i in range(1,base.NbUPoles()+1):
  p=[]
  for j in range(1,5):
   x=base.Pole(i,j);w=base.Weight(i,j);p.append(np.array([x.X()*w,x.Y()*w,x.Z()*w,w]))
  c0=p[0];c1=3*(p[1]-p[0]);c2=3*(p[2]-2*p[1]+p[0]);c3=p[3]-3*p[2]+3*p[1]-p[0];d0=c0+c1*a+c2*a*a+c3*a*a*a;d1=b*(c1+2*c2*a+3*c3*a*a);d2=b*b*(c2+3*c3*a);d3=b*b*b*c3;qq=[d0,d0+d1/3,d0+2*d1/3+d2/3,d0+d1+d2+d3]
  for j,q in enumerate(qq,1):base.SetPole(i,j,gp_Pnt(*(q[:3]/q[3])));base.SetWeight(i,j,float(q[3]))
 v0,v1=old.VKnot(1),old.VKnot(2);arr=TColStd_Array1OfReal(1,2);arr.SetValue(1,v0-h*(v1-v0));arr.SetValue(2,v1+h*(v1-v0));base.SetVKnots(arr)
 err=0;u0,u1,_,_=old.Bounds()
 for x in np.linspace(0,1,17):
  for y in np.linspace(0,1,17):
   u=u0+x*(u1-u0);v=v0+y*(v1-v0);err=max(err,old.Value(u,v).Distance(base.Value(u,v)))
 extension_witnesses.append(err);assert err<1e-10
 return base

surfaces=[]
for i,f in enumerate(outer_faces):
 basis=BRep_Tool.Surface_s(f.wrapped).Copy()
 if i in [1,2]:basis=extend_v(basis)
 offset=args.wall if f.wrapped.Orientation()==TopAbs_REVERSED else -args.wall
 surfaces.append(Geom_OffsetSurface(basis,offset))
surfaces.append(BRep_Tool.Surface_s(envelope.Faces()[3].wrapped))
ints={};allerr=[]
for a,b in [(0,1),(0,2),(1,2),(1,3),(2,3)]:
 inter=GeomInt_IntSS();inter.Perform(surfaces[a],surfaces[b],1e-8,True,True,True);assert inter.IsDone();allerr.append(inter.TolReached3d());ints[a,b]=inter
 assert inter.NbLines()==(2 if (a,b)==(1,2) else 1)
vertices=[];tips=[]
for i in [1,2]:
 c=ints[1,2].Line(i);values=[]
 for si in [0,3]:
  cs=GeomAPI_IntCS(c,surfaces[si]);assert cs.IsDone() and cs.NbPoints()==1;values.append((cs.Point(1),cs.Parameters(1)[2]))
 tips.append(values);vertices.extend(x[0] for x in values)
# Metadata: curve, pcurves per support surface, and common 3D parameter interval.
curves={}
for key,a,b,target in [('top1',0,1,0),('top2',0,2,0),('base1',1,3,1),('base2',2,3,1)]:
 it=ints[a,b];c=it.Line(1);pars=[]
 for j in [0,1]:
  pr=GeomAPI_ProjectPointOnCurve(tips[j][target][0],c);assert pr.NbPoints() and pr.LowerDistance()<2e-6;pars.append(pr.LowerDistanceParameter())
 curves[key]=(c,{a:it.LineOnS1(1),b:it.LineOnS2(1)},min(pars),max(pars))
for j in [0,1]:
 it=ints[1,2];pars=[x[1] for x in tips[j]];curves['tip'+str(j)]=(it.Line(j+1),{1:it.LineOnS1(j+1),2:it.LineOnS2(j+1)},min(pars),max(pars))
def wire(si,keys,want_ccw=True):
 es=[]
 for key in keys:
  c,pcs,lo,hi=curves[key];pc=pcs[si];edge=BRepBuilderAPI_MakeEdge(pc,surfaces[si],lo,hi).Edge();BRepLib.BuildCurve3d_s(edge,1e-8);w=cq.Edge(edge)
  for v in w.Vertices():BRep_Builder().UpdateVertex(v.wrapped,1e-6)
  es.append((w,pc,lo,hi,False,key))
 ordered=[es.pop(0)]
 while es:
  p=ordered[-1][0].startPoint() if ordered[-1][4] else ordered[-1][0].endPoint();best=min([(p.sub(z[0].startPoint()).Length,j,False) for j,z in enumerate(es)]+[(p.sub(z[0].endPoint()).Length,j,True) for j,z in enumerate(es)])
  assert best[0]<2e-6,best
  _,j,rev=best;e,pc,lo,hi,_,key=es.pop(j)
  if rev:e.wrapped.Reverse()
  ordered.append((e,pc,lo,hi,rev,key))
 coords=[]
 for e,pc,lo,hi,rev,key in ordered:
  ts=np.linspace(hi,lo,33) if rev else np.linspace(lo,hi,33)
  coords.extend((pc.Value(float(t)).X(),pc.Value(float(t)).Y()) for t in ts)
 area=sum(p[0]*q[1]-q[0]*p[1] for p,q in zip(coords,coords[1:]+coords[:1]))/2
 mk=BRepBuilderAPI_MakeWire()
 for e,*_ in ordered:mk.Add(e.wrapped)
 assert mk.IsDone();w=mk.Wire()
 if (area>0)!=want_ccw:w.Reverse()
 return w
inner=[]
for si,keys in [(0,['top1','top2']),(1,['top1','tip0','base1','tip1']),(2,['top2','tip0','base2','tip1'])]:
 w=wire(si,keys);mk=BRepBuilderAPI_MakeFace(surfaces[si],w,True);assert mk.IsDone();face=cq.Face(mk.Face());print('innerface',si,face.isValid(),face.Area(),max_tol(face),flush=True);inner.append(face)
source=envelope;base=source.Faces()[3];orientation=base.wrapped.Orientation();forward=base.copy();forward.wrapped.Orientation(TopAbs_FORWARD);mk=BRepBuilderAPI_MakeFace(surfaces[3],forward.outerWire().wrapped,True);mk.Add(wire(3,['base1','base2'],False));baseannulus=cq.Face(mk.Face());baseannulus.wrapped.Orientation(orientation);print('annulus',baseannulus.isValid(),baseannulus.Area(),max_tol(baseannulus),flush=True);baseannulus.exportBrep(str(construction/"unfixed_underside_rim.brep"))
sew=BRepBuilderAPI_Sewing(1e-4)
for face in source.Faces()[:3]+inner+[baseannulus]:sew.Add(face.wrapped)
sew.Perform();shell=cq.Shape.cast(sew.SewedShape());print('sewn',shell.isValid(),len(shell.Shells()),len(shell.Faces()),sew.NbFreeEdges(),flush=True);assert len(shell.Shells())==1 and sew.NbFreeEdges()==0
solid=cq.Solid(BRepBuilderAPI_MakeSolid(shell.Shells()[0].wrapped).Solid()).fix();BRepLib.OrientClosedSolid_s(solid.wrapped);print('solid',solid.isValid(),len(solid.Faces()),volume(solid),max_tol(solid),flush=True);solid.exportBrep(str(out/"cap.brep"))

assert solid.isValid() and len(solid.Solids())==1 and max_tol(solid)<.001
reopened=cq.Shape.importBrep(str(out/'cap.brep'));assert reopened.isValid() and len(reopened.Solids())==1
mesh_obj([('Donor61_true_normal_hollow_cap',solid)],out/'cap.obj')
(out/'components.json').write_text(json.dumps({'objects':[{'name':'Donor61_true_normal_hollow_cap_0p2'}]},indent=2))
q=dict(label='CONTROLLED SOURCE61 HOLLOW CAP REBUILD; actual outer top and side surfaces retained',source_native_file='client-donors/10.3dm',source_native_object=61,source_controlled_import=str(original_path),source_import_receipt=str(original_path)+'.json',xy_scale=xy,z_scale=zs,z_pivot=args.z_pivot,flat_rotation_y=angle,flat_translation_y=yt,source_to_canonical_matrix=matrix,nominal_normal_offset_mm=args.wall,outer_faces_retained=[0,1,2],new_inner_offset_faces=3,new_underside_annular_rim=True,underside_method='New rim on a controlled C0 filling of the original lower outer boundary; opening trimmed by exact offset-wall intersections',exact_polynomial_support_extension_witness_max_mm=max(extension_witnesses),intersection_tolerance_max_mm=max(allerr),max_topology_tolerance_mm=max_tol(solid),valid=True,reopened_valid=True,precise_volume_mm3=volume(solid),precise_volume_roundtrip_delta=abs(volume(solid)-volume(reopened)),limits='Nominal0.2 normal-offset shell surfaces; roof/side junctions and pointed ends may be thicker. No universal-thickness claim. Wall, open-cavity, support-contact and native QA required separately.')
(out/'build-qa.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
