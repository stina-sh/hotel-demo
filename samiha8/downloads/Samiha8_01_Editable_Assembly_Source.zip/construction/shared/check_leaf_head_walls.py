#!/usr/bin/env python3
"""Finite normal walls from retained original outer leaf-head faces."""
from pathlib import Path
import json,argparse,cadquery as cq
from OCP.BRep import BRep_Tool
from OCP.BRepClass import BRepClass_FaceClassifier
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
from OCP.TopAbs import TopAbs_IN,TopAbs_ON,TopAbs_OUT
from OCP.gp import gp_Lin,gp_Dir,gp_Pnt2d
from build_canonical_gallery import ROOT,canonical,frame,max_tol
p=argparse.ArgumentParser();p.add_argument('shape',type=Path);p.add_argument('--scale',type=float);p.add_argument('--output',type=Path,required=True);p.add_argument('--exit-probe-mm',type=float,default=1e-5,help='Strict IN/OUT classification probe around unchanged analytic ray hit; record separately from wall allowance');a=p.parse_args();assert 0<a.exit_probe_mm<=.001;s=cq.Shape.importBrep(str(a.shape));meta_path=a.shape.parent/'build-qa.json';meta=json.loads(meta_path.read_text()) if meta_path.exists() else {};base=cq.Shape.importBrep(str(ROOT/'rebuild-v3/canonical-galleries/support61_controlled.brep'));original=base.transformGeometry(cq.Matrix(meta['source_to_canonical_matrix'])) if meta else canonical(base,frame('leaf'),a.scale);cl=BRepClass3d_SolidClassifier(s.wrapped);ray=IntCurvesFace_ShapeIntersector();ray.Load(s.wrapped,1e-7);ray_max=max(2.,s.BoundingBox().DiagonalLength+1.)
def state(p):cl.Perform(p.toPnt(),1e-7);return cl.State()
def inside(p):return state(p)==TopAbs_IN
samples=[];rows=[];reject=[]
references=original.Faces()[:3]+[f for f in s.Faces() if f.geomType()=='OFFSET']
for fi,f in enumerate(references):
 u0,u1,v0,v1=f._uvBounds();surface=BRep_Tool.Surface_s(f.wrapped);boundary=cq.Compound.makeCompound(f.Edges())
 for fu in [.04,.1,.2,.35,.5,.65,.8,.9,.96]:
  for fv in [.08,.2,.35,.5,.65,.8,.92]:
   u=u0+(u1-u0)*fu;v=v0+(v1-v0)*fv
   if BRepClass_FaceClassifier(f.wrapped,gp_Pnt2d(u,v),1e-8).State() not in [TopAbs_IN,TopAbs_ON]:continue
   point=f.positionAt(u,v)
   if cq.Vertex.makeVertex(*point.toTuple()).distance(boundary)<1e-4:continue
   pr=GeomLProp_SLProps(surface,u,v,1,1e-9);nn=pr.Normal();n=cq.Vector(nn.X(),nn.Y(),nn.Z());plus,minus=inside(point+n*.015),inside(point-n*.015)
   if plus==minus:reject.append(dict(face=fi,u=u,v=v,reason='both_inside' if plus else 'both_outside'));continue
   if minus:n=-n
   ray.Perform(gp_Lin(point.toPnt(),gp_Dir(n.x,n.y,n.z)),1e-5,ray_max);hits=sorted(ray.WParameter(k) for k in range(1,ray.NbPnt()+1) if ray.WParameter(k)>1e-4);h=None
   for hh in hits:
    if state(point+n*(hh-a.exit_probe_mm))==TopAbs_IN and state(point+n*(hh+a.exit_probe_mm))==TopAbs_OUT:h=hh;break
   samples.append(dict(face=fi,role='outer_top' if fi==0 else 'outer_side' if fi<3 else 'inner_offset',u=u,v=v,point_mm=point.toTuple(),inward_normal=n.toTuple(),thickness_mm=h,exit_classification_probe_mm=a.exit_probe_mm))
 vals=[r['thickness_mm'] for r in samples if r['face']==fi and r['thickness_mm'] is not None];row=dict(face=fi,samples=len(vals),minimum_mm=min(vals,default=None),maximum_mm=max(vals,default=None));rows.append(row);print(row,flush=True)
q=dict(shape=str(a.shape),ray_max_mm=ray_max,exit_classification_probe_mm=a.exit_probe_mm,wall_minimum_numerical_allowance_mm=1e-5,xy_scale=meta.get('xy_scale',a.scale),z_scale=meta.get('z_scale',a.scale),valid=s.isValid(),solid_count=len(s.Solids()),max_topological_tolerance_mm=max_tol(s),scope='Finite material-normal rays from retained original outer top/side faces and all new inner normal-offset faces; trim-edge and actual-boundary XOR filters. Roof/side intersections and tips can be thicker.',faces=rows,samples=samples,rejections=reject,under_nominal=[r for r in samples if r['thickness_mm'] is not None and r['thickness_mm']<.2-1e-5],no_exit=[r for r in samples if r['thickness_mm'] is None]);q['minimum_mm']=min(r['thickness_mm'] for r in samples if r['thickness_mm'] is not None);q['maximum_mm']=max(r['thickness_mm'] for r in samples if r['thickness_mm'] is not None);q['pass_finite_minimum_wall_check']=bool(q['valid'] and q['solid_count']==1 and q['max_topological_tolerance_mm']<.001 and not q['under_nominal'] and not q['no_exit'] and all(x['samples'] for x in rows));a.output.write_text(json.dumps(q,indent=2));assert q['pass_finite_minimum_wall_check']
