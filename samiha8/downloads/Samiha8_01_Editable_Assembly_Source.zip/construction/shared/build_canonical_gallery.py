#!/usr/bin/env python3
"""Controlled donor-derived thin gallery, retaining source annular top and outer rim.
No exact-import claim. Native source/trim geometry is retained; inner skirt is a new
normal 0.2 mm offset. Scale is local about (0,0,11), never whole-ring scaling.
"""
from pathlib import Path
import sys,json,math,argparse,subprocess,hashlib
import cadquery as cq
from faces_to_mesh import Reader,surface,curve,build_face
from OCP.BRep import BRep_Tool
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.TopAbs import TopAbs_IN
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge,BRepBuilderAPI_MakeFace
from OCP.BRepOffsetAPI import BRepOffsetAPI_MakeThickSolid
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
from OCP.BRepProj import BRepProj_Projection
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.GeomAPI import GeomAPI_ProjectPointOnCurve
from OCP.gp import gp_Pnt,gp_Dir,gp_Vec
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent

def volume(s):
 p=GProp_GProps();err=BRepGProp.VolumeProperties_s(s.wrapped,p,1e-10,False,False);return p.Mass()
def positive(s):
 if volume(s)<0:s.wrapped.Reverse()
 return s
def max_tol(s):return max([BRep_Tool.Tolerance_s(v.wrapped) for v in s.Vertices()]+[BRep_Tool.Tolerance_s(e.wrapped) for e in s.Edges()])
def frame(kind):
 head=61 if kind=='leaf' else 750
 code="""import rhino3dm as r,json,math,sys
s=r.File3dm.Read(sys.argv[1]);p=[]
for e in s.Objects[int(sys.argv[2])].Geometry.Edges:
 a,b=e.Domain.T0,e.Domain.T1
 for i in range(33):
  q=e.PointAt(a+(b-a)*i/32);p.append((q.X,q.Y,q.Z))
c=[(min(z[k] for z in p)+max(z[k] for z in p))/2 for k in range(3)]
print(json.dumps({'source_head':int(sys.argv[2]),'centre':c,'source_polar_angle':math.atan2(c[0],c[2])}))
"""
 return json.loads(subprocess.check_output([str(ROOT/'venv/bin/python'),'-c',code,str(ROOT/'client-donors/10.3dm'),str(head)]))
def canonical(s,f,scale):return s.rotate((0,0,0),(0,1,0),-math.degrees(f['source_polar_angle'])).translate((0,-f['centre'][1],0)).translate((0,0,-11)).scale(scale).translate((0,0,11))
def first_native_face(path):
 r=Reader(path);r.expect('NATIVEFACES');assert r.i()==2;r.expect('O');oi,nf=r.i(),r.i();r.expect('F');fi,rev,nl=r.i(),r.i(),r.i();mapping=r.i();s,err=surface(r);assert mapping==1;loops=[]
 for _ in range(nl):
  r.expect('L');typ,nt=r.i(),r.i();items=[]
  for _ in range(nt):r.expect('T');tt,v0,v1=r.i(),r.i(),r.i();items.append((tt,curve(r)))
  loops.append((typ,items))
 return cq.Face(build_face(s,loops,rev)),err

def leaf_skirt(top,wall,depth,overlap):
 # Flatten the actual rational outer-edge XY coordinates exactly. Because the
 # intended side walls are vertical extrusions, a planar normal offset is their
 # true normal wall offset. Project the new inset back to the donor top support.
 edges=[]
 for e in top.outerWire().Edges():
  c=BRep_Tool.Curve_s(e.wrapped,0.,0.).Copy()
  for i in range(1,c.NbPoles()+1):p=c.Pole(i);c.SetPole(i,gp_Pnt(p.X(),p.Y(),0))
  a,b=BRep_Tool.Range_s(e.wrapped);ee=BRepBuilderAPI_MakeEdge(c,a,b).Edge();ee.Orientation(e.wrapped.Orientation());edges.append(cq.Edge(ee))
 flat=cq.Wire.assembleEdges(edges);inner=flat.offset2D(-wall,'intersection');assert len(inner)==1
 assert inner[0].BoundingBox().xlen<flat.BoundingBox().xlen
 projection=BRepProj_Projection(inner[0].wrapped,top.wrapped,gp_Dir(0,0,1));assert projection.IsDone();inset=cq.Wire(projection.Current());projection.Next();assert not projection.More()
 sf=BRep_Tool.Surface_s(top.wrapped);mk=BRepBuilderAPI_MakeFace(sf,top.outerWire().wrapped,True);inset.wrapped.Reverse();mk.Add(inset.wrapped);annulus=cq.Face(mk.Face());assert annulus.isValid()
 return positive(cq.Shape.cast(BRepPrimAPI_MakePrism(annulus.wrapped,gp_Vec(0,0,-depth),False,False).Shape()).translate((0,0,-overlap)))
def round_skirt(top,wall,depth,overlap):
 shell=cq.Shape.cast(BRepPrimAPI_MakePrism(top.outerWire().translate((0,0,-overlap)).wrapped,gp_Vec(0,0,-depth),False,False).Shape())
 mk=BRepOffsetAPI_MakeThickSolid();mk.MakeThickSolidBySimple(shell.wrapped,wall);return positive(cq.Shape.cast(mk.Shape()))
def overlap_witnesses(top,plate,skirt,wall):
 classifiers=[BRepClass3d_SolidClassifier(s.wrapped) for s in (plate,skirt)]
 def inside(cl,p):cl.Perform(p.toPnt(),1e-7);return cl.State()==TopAbs_IN
 rows=[];rejected=0
 for ei,e in enumerate(top.outerWire().Edges()):
  for f in [.08,.16,.24,.32,.40,.48,.56,.64,.72,.80,.88,.94]:
   p=e.positionAt(f);t=e.tangentAt(f);n=cq.Vector(-t.y,t.x,0).normalized()
   if n.dot(cq.Vector(-p.x,-p.y,0))<0:n=-n
   q=p+n*(wall*.5)+cq.Vector(0,0,-wall*.6)
   offsets=[cq.Vector(0,0,0)]+[cq.Vector(*(d if i==axis else 0 for i in range(3))) for axis in range(3) for d in [-.015,.015]]
   if all(inside(cl,q+d) for cl in classifiers for d in offsets):rows.append(dict(edge=ei,fraction=f,point_mm=q.toTuple(),six_axis_neighbor_distance_mm=.015))
   else:rejected+=1
 return dict(method='Strict IN classification in both solids for witness centre plus six axis neighbors at 0.015 mm; finite evidence of positive overlap, not Boolean volume or a complete interface proof',accepted=len(rows),rejected=rejected,witnesses=rows)
def edge_fidelity(a,b):
 def curves(s):return [(BRep_Tool.Curve_s(e.wrapped,0.,0.),BRep_Tool.Range_s(e.wrapped)) for e in s.Edges()]
 ca,cb=curves(a),curves(b);err=0;ns=0;failed=0
 for froms,tos in [(ca,cb),(cb,ca)]:
  for c,(aa,zz) in froms:
   for k in range(257):
    p=c.Value(aa+(zz-aa)*k/256);d=[]
    for cc,(lo,hi) in tos:
     d.extend([p.Distance(cc.Value(lo)),p.Distance(cc.Value(hi))])
     try:
      pr=GeomAPI_ProjectPointOnCurve(p,cc,lo,hi)
      if pr.NbPoints():d.append(pr.LowerDistance())
     except Exception:failed+=1
    err=max(err,min(d));ns+=1
 return dict(bidirectional_edge_locus_sample_max_mm=err,samples=ns,projection_exceptions=failed)
def mesh_obj(parts,path):
 with open(path,'w') as out:
  base=1
  for name,s in parts:
   vs,ts=s.tessellate(.006,.12);out.write('o '+name+'\n')
   for v in vs:out.write('v %.12g %.12g %.12g\n'%v.toTuple())
   for t in ts:out.write('f '+' '.join(str(base+i) for i in t)+'\n')
   base+=len(vs)
def run(kind,scale,depth,wall,overlap,out):
 out.mkdir(parents=True,exist_ok=True);idx=66 if kind=='leaf' else 733;src=ROOT/'client-donors/10.3dm';facefile=out/'source.faces';subprocess.run([str(HERE/'native_face_reader'),str(src),str(facefile),str(idx)],check=True)
 raw,err=first_native_face(facefile);fr=frame(kind);top=canonical(raw,fr,scale)
 b=BRepOffsetAPI_MakeThickSolid();b.MakeThickSolidBySimple(top.wrapped,-wall);plate=positive(cq.Shape.cast(b.Shape()))
 skirt=(leaf_skirt if kind=='leaf' else round_skirt)(top,wall,depth,overlap)
 parts=[('Donor_'+kind+'_footplate_0p2',plate),('Donor_'+kind+'_deep_hollow_skirt_0p2',skirt)]
 qa=dict(label='CONTROLLED DONOR-DERIVED REBUILD, NOT EXACT SOURCE IMPORT',kind=kind,source_file=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),source_gallery=idx,source_head=fr['source_head'],source_supports=[62,63,64,65] if kind=='leaf' else [751,752,753,754],frame=fr,transformation_order=['rotate Y by negative source_polar_angle about origin','translate Y by negative centre[1]',f'uniform local scale {scale} about (0,0,11)'],local_scale=scale,wall_mm=wall,skirt_vertical_depth_mm=depth,skirt_top_drop_mm=overlap,source_surface_witness_error=err,method='Source exact annular top face retained and normal-thickened. Skirt outer wall is exact vertical extrusion of source outer rim. Leaf inner wall uses actual-rim XY normal offset with proper sharp-tip intersections, projected onto source top support; round uses simple normal shell offset.',parts=[])
 angle=-fr['source_polar_angle'];c=math.cos(angle);ss=math.sin(angle)
 qa['source_to_canonical_matrix']=[[scale*c,0,scale*ss,0],[0,scale,0,-scale*fr['centre'][1]],[-scale*ss,0,scale*c,11*(1-scale)],[0,0,0,1]]
 old=canonical(cq.Shape.importBrep(str(ROOT/f'rebuild-v3/native-preview/donor10_gallery{idx}_controlled.brep')).Faces()[0],fr,scale);qa['top_edge_fidelity_to_original_native_3d_edges']=edge_fidelity(top,old)
 if qa['top_edge_fidelity_to_original_native_3d_edges']['bidirectional_edge_locus_sample_max_mm']>.001:raise RuntimeError('Donor top edge fidelity exceeds declared .001 mm')
 for name,s in parts:
  if not s.isValid() or len(s.Solids())!=1 or max_tol(s)>.001:raise RuntimeError(f'{name}: invalid, not solid, or tolerance exceeds .001')
  p=out/(('footplate' if s is plate else 'skirt')+'.brep');s.exportBrep(str(p));re=cq.Shape.importBrep(str(p));assert re.isValid() and len(re.Solids())==1
  qa['parts'].append(dict(name=name,file=str(p),valid=True,reopened_valid=True,volume_mm3=volume(s),volume_roundtrip_delta=abs(volume(s)-volume(re)),max_topological_tolerance_mm=max_tol(s),faces=len(s.Faces())))
 qa['footplate_skirt_contact']=overlap_witnesses(top,plate,skirt,wall)
 assert qa['footplate_skirt_contact']['accepted']>=8
 if kind=='round':
  contact=plate.intersect(skirt);qa['footplate_skirt_contact'].update(boolean_common_valid=contact.isValid(),common_solids=len(contact.Solids()),volume_mm3=volume(contact),boolean_positive_volume=bool(contact.isValid() and len(contact.Solids()) and volume(contact)>1e-5))
  if not qa['footplate_skirt_contact']['boolean_positive_volume']:qa['footplate_skirt_contact']['boolean_limit']='Boolean common returned inconclusive/empty result despite strict interior-overlap witnesses; no positive Boolean-volume claim'
 else:qa['footplate_skirt_contact']['boolean_limit']='OCCT Boolean common crashed on this valid thin-face pair; no Boolean-volume claim. Separate components retained.'
 compound=cq.Compound.makeCompound([plate,skirt]);compound.exportBrep(str(out/'gallery.brep'));top.exportBrep(str(out/'retained_top.brep'));mesh_obj(parts,out/'gallery.obj');(out/'components.json').write_text(json.dumps({'objects':[{'name':n} for n,s in parts]},indent=2));(out/'build-qa.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa),flush=True)
 return qa
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('kind',choices=['leaf','round']);p.add_argument('--scale',type=float,default=1.7);p.add_argument('--depth',type=float,default=.9);p.add_argument('--wall',type=float,default=.2);p.add_argument('--top-drop',type=float,default=.05);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run(a.kind,a.scale,a.depth,a.wall,a.top_drop,a.output)
