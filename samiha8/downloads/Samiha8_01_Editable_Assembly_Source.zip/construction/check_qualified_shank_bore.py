from pathlib import Path
import json,math,cadquery as cq,hashlib
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
D=Path(__file__).resolve().parent;R=62/(2*math.pi);axis=cq.Edge.makeLine((0,-30,0),(0,30,0));rows=[]
for name in ['lower_band','branch_1','branch_3','branch_4']:
 p=D/'qualified-shank'/(name+'.brep');g=cq.Shape.importBrep(str(p));op=BRepExtrema_DistShapeShape(g.wrapped,axis.wrapped);op.Perform();assert op.IsDone();q=op.PointOnShape1(1);row={'part':name,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'minimum_distance_to_bore_axis_mm':op.Value(),'nearest_material_point_mm':[q.X(),q.Y(),q.Z()],'bore_radius_mm':R,'margin_mm':op.Value()-R,'pass_0p001_mm':op.Value()>=R-.001};rows.append(row);print(row,flush=True)
(D/'qualified-shank/bore-axis-distance-qa.json').write_text(json.dumps({'method':'OCCT closest-distance calculation from each native-derived CAD solid to the axialY line spanning all componentY values','EU62_bore_diameter_mm':2*R,'parts':rows,'all_pass_0p001_mm':all(r['pass_0p001_mm'] for r in rows),'scope':'Final qualified shank parts, referenced by exact geometry hashes'},indent=2))
