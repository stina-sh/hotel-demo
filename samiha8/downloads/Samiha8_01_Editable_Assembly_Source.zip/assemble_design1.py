"""Portable editable native assembly. No network access or mesh-based CAD."""
from pathlib import Path
import argparse,hashlib,json
import rhino3dm as r
D=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--allow-edits',action='store_true',help='Skip frozen geometry equality after deliberate edits; prior QA no longer carries forward.');args=parser.parse_args()
f=r.File3dm();f.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;f.Settings.ModelAbsoluteTolerance=.001

def add(geometry,name,layer):
 assert isinstance(geometry,r.Brep) and geometry.IsValid and geometry.IsSolid,name
 at=r.ObjectAttributes();at.Name=name;at.LayerIndex=layer;f.Objects.Add(geometry,at)
def layer(name):
 a=r.Layer();a.Name=name;return f.Layers.Add(a)
for family,relative in [('Settings','components/settings.3dm'),('FairedPolishedRibbons','components/fairing.3dm'),('HollowShank','components/shank.3dm')]:
 source=r.File3dm.Read(str(D/relative));assert source is not None
 layers={i:layer(family+'_'+a.Name) for i,a in enumerate(source.Layers)}
 if not layers:layers[0]=layer(family)
 for o in source.Objects:add(o.Geometry.Duplicate(),family+'_'+o.Attributes.Name,layers.get(o.Attributes.LayerIndex,next(iter(layers.values()))))
plan=json.loads((D/'grain_plan.json').read_text());grain_layer=layer('Grains')
for i,b in enumerate(plan['beads']):add(r.Sphere(r.Point3d(*b['center']),plan['diameter_mm']/2).ToBrep(),f'Grains_Grain_1mm_{i:03d}',grain_layer)
flute_layer=layer('GalleryFlutes');plan=json.loads((D/'flute_instances.json').read_text());cache={}
for s in plan['settings']:
 file=s['canonical_ribs']
 if file not in cache:cache[file]=r.File3dm.Read(str(D/file))
 source=cache[file];t=r.Transform.Identity()
 for i in range(3):
  for j in range(4):setattr(t,f'M{i}{j}',s['world_transform'][i][j])
 for i in s['retained_ribs']:
  g=source.Objects[i].Geometry.Duplicate();g.Transform(t);add(g,f"GalleryFlutes_{s['setting']}_flute_{i:03d}",flute_layer)
out=D/'Samiha8_01_Opposed_Wings_25mm_EU62.3dm';assert f.Write(str(out),7);re=r.File3dm.Read(str(out));assert all(isinstance(o.Geometry,r.Brep) and o.Geometry.IsValid and o.Geometry.IsSolid for o in re.Objects)
def digest(g):return hashlib.sha256(json.dumps(g.Encode(),sort_keys=True,separators=(',',':')).encode()).hexdigest()
expected=json.loads((D/'expected_geometry_digests.json').read_text());actual=[{'name':o.Attributes.Name,'sha256':digest(o.Geometry)} for o in re.Objects];mismatches=[i for i,(a,b) in enumerate(zip(actual,expected['objects'])) if a!=b];matches=len(actual)==len(expected['objects']) and not mismatches
receipt={'file':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'native_objects':len(re.Objects),'all_native_valid_closed':True,'mesh_objects':0,'units':'millimeters','rhino3dm_version':r.__version__,'frozen_geometry_exact_match':matches,'mismatch_indices':mismatches,'edits_allowed':args.allow_edits,'original_qualification_carries_forward':matches};(D/'rebuild-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
if not args.allow_edits:assert matches,'Frozen source reproduction changed native geometry or object order'
