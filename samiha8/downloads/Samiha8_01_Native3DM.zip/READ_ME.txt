Samiha8 design 1: Opposed Wings

Extract Samiha8_01_Opposed_Wings_25mm_EU62.3dm, then open that native Rhino 7 millimetre file in your CAD application. The ZIP changes no geometry.
Native SHA-256: 54db508124ae179c4c2a4a103eb5e552d9c28b7006a36d0562e202100cfaf70d

Editable, separate contacting BREP solids. See the catalog review notes for dimensions and finite checks. No MatrixGold runtime or manufacturing certification is claimed.
