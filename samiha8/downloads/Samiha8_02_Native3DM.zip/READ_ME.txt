Samiha8 design 2: Flowing S

Extract Samiha8_02_Flowing_S_25mm_EU62.3dm, then open that native Rhino 7 millimetre file in your CAD application. The ZIP changes no geometry.
Native SHA-256: 4a35096e5d9fcf6d31cde05213633a2b214fba4d0d22c85d143af6618f74298b

Editable, separate contacting BREP solids. See the catalog review notes for dimensions and finite checks. No MatrixGold runtime or manufacturing certification is claimed.
