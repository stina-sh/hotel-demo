SAMIHA 7 NATIVE ASSEMBLY REPLAY

What this package does
Reassembles the reviewed native geometry from the three original designer 3DM files and the supplied validated replacement components. Settings and ornament shapes are taken from the original native files with their recorded rigid placements. New beads use analytic spheres where the recorded native encoding is reproducible directly. Rebuilt skins, hollow galleries and the lower hollow insert come from validated native components.

This is a tested assembly replay, not a claim that every experimental offset/Boolean operation has been reproduced from scratch in a clean MatrixGold session. The outputs remain CAD review variants, with the same exceptions and production limitations as the catalog.

Requirements
Python 3 and rhino3dm 8.35.0. The replay was tested using that version. Original 6.3dm,7.3dm and 10.3dm are required; their SHA-256 checksums are pinned in assembly-replay.json. The script refuses a source mismatch and refuses to overwrite an existing output.

Run from this package directory
python reassemble_review_variants.py --originals /path/to/originals --output /path/to/new-output-folder

The originals folder must contain 6.3dm,7.3dm and 10.3dm. No original file is changed. Each output is written as a Rhino 7/native archive 70 file with millimetre units and then reopened.

Verification
The script checks every output object's encoded native geometry hash and UUID against the frozen reviewed assembly. It reports native validity, open/nonmanifold object counts and file checksums in replay-validation.json. The complete file checksum is not expected to equal the supplied review file: serialization metadata can differ. The per-object geometry checks are the exact-replay criterion.

Scope limits
- Source files are not included here; use the original designer files already supplied for this task
- Native geometry is preserved/reassembled; MatrixGold construction history is not recreated
- This does not perform a manufacturing Boolean union, create drains/vents, approve print/cast wall limits, or fix inherited open/nonmanifold source geometry
- Inspect the catalog's final QA notes and production exceptions before using the models
