#!/usr/bin/env python3
"""Replay the checked native assembly; never modify input originals.

Requires rhino3dm 8.35.0. This script reuses validated native replacement
components. It does not rerun the separate experimental OCCT offset pipeline.
Geometry hashes are checked after native archive70 output is reopened.
"""
import argparse,hashlib,json,uuid
from pathlib import Path
import rhino3dm as r

def file_sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def geometry_sha(g):return hashlib.sha256(json.dumps(g.Encode(),sort_keys=True).encode()).hexdigest()

def replay(bundle,originals,output):
 spec=json.loads((bundle/'assembly-replay.json').read_text());sources={}
 for key,q in spec['sources'].items():
  p=originals/q['filename']
  if file_sha(p)!=q['sha256']:raise ValueError(f'Original checksum mismatch: {p.name}')
  sources[key]=r.File3dm.Read(str(p))
 cf=r.File3dm.Read(str(bundle/'validated-native-components.3dm'))
 if file_sha(bundle/'validated-native-components.3dm')!=spec['component_archive_sha256']:raise ValueError('Component archive checksum mismatch')
 output.mkdir(parents=True,exist_ok=True);reports=[]
 for item in spec['models']:
  dest=output/item['output_filename']
  if dest.exists():raise FileExistsError(f'Refusing overwrite: {dest}')
  doc=r.File3dm();doc.Settings.ModelUnitSystem=r.UnitSystem.Millimeters;doc.Settings.ModelAbsoluteTolerance=.001;doc.Settings.ModelRelativeTolerance=.01
  layers={}
  for q in item['objects']:
   role=q['role'];layer=q['layer']
   if layer not in layers:
    l=r.Layer();l.Name=layer;layers[layer]=doc.Layers.Add(l)
   if q['kind']=='source':
    g=sources[str(item['model'])].Objects[q['source_index']].Geometry.Duplicate()
    if q['translation']!=[0,0,0]:assert g.Translate(r.Vector3d(*q['translation']))
   elif q['kind']=='sphere':g=r.Sphere(r.Point3d(*q['center']),q['radius']).ToBrep()
   elif q['kind']=='component':g=cf.Objects[q['component_index']].Geometry.Duplicate()
   else:raise ValueError(q['kind'])
   if geometry_sha(g)!=q['expected_geometry_sha256']:raise ValueError(f'Prewrite geometry mismatch {item["model"]}:{q["output_index"]}')
   a=r.ObjectAttributes();a.Id=uuid.UUID(q['output_uuid']);a.Name=q['name'];a.LayerIndex=layers[layer]
   for k,v in q['user_strings']:a.SetUserString(k,v)
   doc.Objects.AddBrep(g,a)
  for k,v in item['document_strings']:doc.Strings[k]=v
  assert doc.Write(str(dest),7);check=r.File3dm.Read(str(dest));bad=[]
  for q,o in zip(item['objects'],check.Objects):
   if geometry_sha(o.Geometry)!=q['expected_geometry_sha256'] or str(o.Attributes.Id)!=q['output_uuid']:bad.append(q['output_index'])
  assert len(check.Objects)==len(item['objects']) and not bad
  reports.append({'model':item['model'],'output':dest.name,'native_object_count':len(check.Objects),'all_geometry_hashes_match':True,'all_output_uuids_match':True,'all_native_valid':all(o.Geometry.IsValid for o in check.Objects),'open_object_count':sum(not o.Geometry.IsSolid for o in check.Objects),'nonmanifold_object_count':sum(not o.Geometry.IsManifold for o in check.Objects),'archive_version':check.ArchiveVersion,'output_sha256':file_sha(dest),'scope':'Exact native component/ornament geometry replay; not a fresh offset recomputation or manufacturing release.'})
 (output/'replay-validation.json').write_text(json.dumps(reports,indent=2));return reports

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--originals',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();print(json.dumps(replay(a.bundle,a.originals,a.output),indent=2))
